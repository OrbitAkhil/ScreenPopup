﻿using NLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Web;
using Tsapi;

namespace CallDistrubutionApp
{
    public sealed class Simulator
    {
        private static NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        [DllImport("TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool MonitorStart(string AgentId,string DEvId);

        [DllImport("TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool OpenConnection();

        private static Simulator instance = null;
        private static readonly object padlock = new object();
        private const int WM_USER = 0x0400;
        private const int WM_TSAPI_EVENT = WM_USER + 99;
        private Acs.EsrDelegate eventReaction;
        private Queue<string> logQueue = new Queue<string>();
        private const int logMax = 2000;
        internal IntPtr Handle { get; set; }
        internal bool configured = false;
        private string serverId;
        private string loginId;
        private string password;
        private string applicationName;
        private string apiVer;
        private Acs.ACSHandle_t acsHandle;
        private Acs.PrivateData_t privData;
        private Csta.CSTAMonitorCrossRefID_t monitorCrossRefId;
       
        Simulator()
        {
            try
            {
                if (ConfigurationManager.AppSettings["ServerID"] != "" ||
                    ConfigurationManager.AppSettings["ServerID"] != "AVAYA#Switch_Connection#Service_Type#AE_Service")
                {
                    ConfigurationManager.AppSettings["ServerID"] = GetServerId();
                }
                this.configured = true;
                try { this.serverId = ConfigurationManager.AppSettings["ServerID"]; }
                catch { this.configured = false; }
                try { this.loginId = ConfigurationManager.AppSettings["TSAPI login"]; }
                catch { this.configured = false; }
                try { this.password = ConfigurationManager.AppSettings["TSAPI Password"]; }
                catch { this.configured = false; }
                try { this.applicationName = ConfigurationManager.AppSettings["ApplicationName"]; }
                catch { this.configured = false; }
                try { this.apiVer = ConfigurationManager.AppSettings["ApiVersion"]; }
                catch { this.configured = false; }
            }
            catch
            {
                this.configured = false;
            }
        }

        public static Simulator Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (padlock)
                    {
                        if (instance == null)
                        {
                            instance = new Simulator();
                        }
                    }
                }
                return instance;
            }
        }


       
        private string GetServerId()
        {
            var enumServerHandler = new EnumServerHandler();
            Acs.EnumServerNamesCB callback = new Acs.EnumServerNamesCB(enumServerHandler.acsEnumServerNamesCallbackHandler);
            Acs.acsEnumServerNames(Acs.StreamType_t.ST_CSTA, callback, 0);
            // Log("[acsEnumServerNames Test] server = " + enumServerHandler.serverName);
            if (enumServerHandler.serverName != string.Empty)
            {
                return enumServerHandler.serverName;
            }
            else
            {
                return ConfigurationManager.AppSettings["ServerID"];
            }
        }

        public bool OpenStream()
        {
            this.acsHandle = new Acs.ACSHandle_t();
            var invokeIdType = Acs.InvokeIDType_t.LIB_GEN_ID;
            var invokeId = new Acs.InvokeID_t();
            var streamType = Acs.StreamType_t.ST_CSTA;

            Acs.ServerID_t serverId = this.serverId;
            Acs.LoginID_t loginId = this.loginId;
            Acs.Passwd_t passwd = this.password;
            Acs.AppName_t appName = this.applicationName;
            Acs.Level_t acsLevelReq = Acs.Level_t.ACS_LEVEL1;
            Acs.Version_t apiVer = this.apiVer;

            ushort sendQSize = 0;
            ushort sendExtraBufs = 0;
            ushort recvQSize = 0;
            ushort recvExtraBufs = 0;
            //var currentDevice = extensionNo;
            // Get supportedVersion string
            string requestedVersion = "3-10";
            System.Text.StringBuilder supportedVersion = new System.Text.StringBuilder();
            Acs.RetCode_t attrc = Att.attMakeVersionString(requestedVersion, supportedVersion);
            // Set PrivateData request
            this.privData = new Acs.PrivateData_t();
            this.privData.vendor = "VERSION";
            this.privData.data = new byte[Att.ATT_MAX_PRIVATE_DATA];
            this.privData.data[0] = Acs.PRIVATE_DATA_ENCODING;
            for (int i = 0; i < supportedVersion.Length; i++)
            {
                privData.data[i + 1] = (byte)supportedVersion[i];
            }
            privData.length = Att.ATT_MAX_PRIVATE_DATA;
            Acs.RetCode_t retCode = Acs.acsOpenStream(out this.acsHandle,
                                                          invokeIdType,
                                                          invokeId,
                                                          streamType,
                                                          ref serverId,
                                                          ref loginId,
                                                          ref passwd,
                                                          ref appName,
                                                          acsLevelReq,
                                                          ref apiVer,
                                                          sendQSize,
                                                          sendExtraBufs,
                                                          recvQSize,
                                                          recvExtraBufs,
                                                          this.privData);
            Csta.EventBuffer_t evtBuf = new Csta.EventBuffer_t();
            ushort eventBufSize = Csta.CSTA_MAX_HEAP;
            ushort numEvents = 0;

            retCode = Acs.acsGetEventBlock(this.acsHandle,
                                     evtBuf,
                                     ref eventBufSize,
                                     this.privData,
                                     out numEvents);
            if (evtBuf.evt.eventHeader.eventClass.eventClass != 2 || evtBuf.evt.eventHeader.eventType.eventType != 2)
            {
                return true;
            }
            

            return false;

            
        }

        private void ESRCallback(uint esrParam)
        {
            //AbortStream();
           // Tsapi.Acs.ACSHandle_t acsHandle = (Tsapi.Acs.ACSHandle_t)esrParam;
            Notify(this.acsHandle);
        }

        public void AbortStream()
        {
            Acs.acsCloseStream(this.acsHandle, new Acs.InvokeID_t(), null);
        }

        public void ReOpenStream()
        {
            OpenConnection();
            this.OpenStream();

            //Start Monitoring
            //var loggedInUsers = new LoginRepository().GetActiveAgents();
            //foreach (var user in loggedInUsers)
            //{
            //    MonitorStart(user.AgentId.ToString(), user.ExtensionNo.ToString());
            //}
        }

        public void MonitorDevice(string device)
        {
            if (device.ToString().Length == 0 || device.ToString().Length > 5) { return; }
            Csta.DeviceID_t currentDevice = device.ToString();
            var filter = new Csta.CSTAMonitorFilter_t();
            Acs.RetCode_t retCode = Csta.cstaMonitorDevice(this.acsHandle, new Acs.InvokeID_t(), ref currentDevice, ref filter, this.privData);
            if (retCode._value < 0) return;
            ushort eventBufferSize = Csta.CSTA_MAX_HEAP;
            this.privData.length = Att.ATT_MAX_PRIVATE_DATA;
            var eventBuf = new Csta.EventBuffer_t();
            ushort numEvents;
            retCode = Acs.acsGetEventBlock(this.acsHandle, eventBuf, ref eventBufferSize, this.privData, out numEvents);
            if (retCode._value < 0) return;
            if (eventBuf.evt.eventHeader.eventClass.eventClass == Csta.CSTACONFIRMATION && eventBuf.evt.eventHeader.eventType.eventType == Csta.CSTA_MONITOR_CONF)
            {
                this.monitorCrossRefId = eventBuf.evt.cstaConfirmation.monitorStart.monitorCrossRefID;
                Debug.WriteLine("Monitoring device " + currentDevice + ", CrossRefID=" + this.monitorCrossRefId);
                //MessageBox.Show("cstaMonitorDevice succeded. Look into the log for details");
            }
            else
                Debug.WriteLine("cstaMonitorDevice Failed. Error was: " + eventBuf.evt.cstaConfirmation.universalFailure.error);
        }

        public void SetAgentState(string agentId,string extensionNo, Csta.AgentMode_t agentMode, Att.ATTWorkMode_t workMode)
        {
            //if (!streamCheckbox.Checked || deviceTextBox.Text.Length == 0 || deviceTextBox.Text.Length > 5 || !streamCheckbox.Checked) { return; }
            Csta.DeviceID_t currentDevice = extensionNo;

            Csta.AgentID_t agent = agentId;
            int reasonCode = 0;
            bool enablePending = true;
            Csta.AgentGroup_t agentGroup = new Csta.AgentGroup_t();
            Csta.AgentPassword_t agentPass = "";

            Acs.RetCode_t retCode = Att.attV6SetAgentState(this.privData, workMode, reasonCode, enablePending);
            //Log("attV6SetAgentState result = " + retCode._value);

            retCode = Csta.cstaSetAgentState(this.acsHandle, new Acs.InvokeID_t(), ref currentDevice, agentMode, agent, agentGroup, agentPass, this.privData);
            //this.Log("cstaSetAgentState result = " + retCode._value);
            if (retCode._value < 0) return;

            ushort eventBufferSize = Csta.CSTA_MAX_HEAP;
            this.privData.length = Att.ATT_MAX_PRIVATE_DATA;
            var eventBuf = new Csta.EventBuffer_t();
            ushort numEvents;
            retCode = Acs.acsGetEventBlock(this.acsHandle, eventBuf, ref eventBufferSize, this.privData, out numEvents);
            //this.Log("acsGetEventBlock result = " + retCode._value);
            if (retCode._value < 0)
            {
                if (retCode._value == Acs.ACSERR_BADHDL)
                {
                    ReOpenStream();
                }
                return;
            }

            if (eventBuf.evt.eventHeader.eventClass.eventClass == Csta.CSTACONFIRMATION && eventBuf.evt.eventHeader.eventType.eventType == Csta.CSTA_SET_AGENT_STATE_CONF)
            {
                Att.ATTEvent_t attEvt = new Att.ATTEvent_t();
                retCode = Att.attPrivateData(this.privData, attEvt);
                //Debug.WriteLine("attPrivateData retCode = " + retCode._value);
                //if (attEvt.eventType.eventType == Att.ATT_SET_AGENT_STATE_CONF)
                //MessageBox.Show(string.Format("cstaSetAgentState {0} succeded. Pending? {1}", agentMode, attEvt.setAgentState.isPending));
                //else
                //MessageBox.Show("Got wrong ATT Event... " + attEvt.eventType.eventType);
            }
            else
            {
                //MessageBox.Show("cstaSetAgentState Failed. Error was: " + eventBuf.evt.cstaConfirmation.universalFailure.error);
            }

        }
       
        public bool MakeCall(string callerNumber,string calledNumber)
        {
            if (callerNumber.Length == 0 || callerNumber.Length > 5) { return false; }

            var invokeId = new Acs.InvokeID_t();
            Csta.DeviceID_t callingDevice = callerNumber;

            Csta.DeviceID_t calledDevice = calledNumber;

            var u2uString = "Hello, I AM test u2u string";
            var u2uInfo = new Att.ATTUserToUserInfo_t();
            // fixed u2u size
            int u2uSize = Att.ATT_MAX_UUI_SIZE;
            u2uInfo.length = (short)u2uString.Length;
            u2uInfo.type = Att.ATTUUIProtocolType_t.UUI_IA5_ASCII;
            u2uInfo.value = Encoding.ASCII.GetBytes(u2uString);
            Array.Resize(ref u2uInfo.value, u2uSize);
            Csta.DeviceID_t destRouteOrSplit;
            destRouteOrSplit = null;
            //if (deviceSelectDialog.destRouteOrSplitTextBox.Text == string.Empty)

            //else
            //    destRouteOrSplit = deviceSelectDialog.destRouteOrSplitTextBox.Text;

            //if (deviceSelectDialog.normalCallRadio.Checked)
            Att.attV6MakeCall(this.privData, ref destRouteOrSplit, false, ref u2uInfo);
            //else if (deviceSelectDialog.directAgentCallRadio.Checked)
            //    Att.attV6DirectAgentCall(this.privData, ref destRouteOrSplit, false, ref u2uInfo);
            //else if (deviceSelectDialog.supervisorAssistCallRadio.Checked)
            //     Att.attV6SupervisorAssistCall(this.privData, ref destRouteOrSplit, ref u2uInfo);

            Acs.RetCode_t retCode = Csta.cstaMakeCall(this.acsHandle, invokeId, ref callingDevice, ref calledDevice, this.privData);
            Debug.WriteLine("cstaMakeCall result = " + retCode._value);

            var evtBuf = new Csta.EventBuffer_t();
            ushort eventBufSize = Csta.CSTA_MAX_HEAP;
            ushort numEvents;
            retCode = Acs.acsGetEventBlock(this.acsHandle,
                                          evtBuf,
                                          ref eventBufSize,
                                          privData,
                                          out numEvents);

            if (retCode._value < 0)
            {
                if (retCode._value == Acs.ACSERR_BADHDL)
                {
                    ReOpenStream();
                }
                return false;
            }

            if (evtBuf.evt.eventHeader.eventClass.eventClass == Csta.CSTACONFIRMATION && evtBuf.evt.eventHeader.eventType.eventType == Csta.CSTA_MAKE_CALL_CONF)
            {
                Att.ATTEvent_t attEvt = new Att.ATTEvent_t();
                retCode = Att.attPrivateData(this.privData, attEvt);
                Debug.WriteLine("attPrivateData retCode = " + retCode._value);
                if (attEvt.eventType.eventType == Att.ATT_MAKE_CALL_CONF)
                    return true;
                //MessageBox.Show(String.Format("Make Call from {0} to {1} is successfull! Ucid of new call = {2}", callingDevice.ToString(), calledDevice.ToString(), attEvt.consultationCall.ucid));
                else
                    return false; //MessageBox.Show("Got wrong ATT Event... " + attEvt.eventType.eventType);
            }
            else
            {
                return false;// MessageBox.Show("cstaMakeCall Failed. Error was: " + evtBuf.evt.cstaConfirmation.universalFailure.error);
            }


        }

        public bool ClearCall(string callerNumber)
        {
            if (callerNumber.Length == 0 || callerNumber.Length > 5) { return false; }
            Csta.DeviceID_t currentDevice = callerNumber;
            Csta.ConnectionID_t[] conns = GetCurrentConnections(callerNumber);

            if (conns == null || conns.Length == 0)
            {
                //MessageBox.Show("No active calls");
                return false;
            }
            Csta.EventBuffer_t eventBuf = Csta.clearCall(this.acsHandle, conns[0]);
            if (eventBuf.evt.eventHeader.eventClass.eventClass == Csta.CSTACONFIRMATION &&
                eventBuf.evt.eventHeader.eventType.eventType == Csta.CSTA_CLEAR_CALL_CONF)
                return true;//MessageBox.Show("Call Clear succeded!");
            else
                return false; //MessageBox.Show("Call Clear failed. Error was: " + eventBuf.evt.cstaConfirmation.universalFailure.error);

        }

        public bool HoldCall(string callerNumber)
        {
            if (string.IsNullOrEmpty(callerNumber) || callerNumber.Length > 5) { return false; }

            Csta.ConnectionID_t[] conns = GetCurrentConnections(callerNumber);

            if (conns == null || conns.Length == 0)
            {
                // MessageBox.Show("No active calls");
                return false;
            }

            var invokeId = new Acs.InvokeID_t();

            Acs.RetCode_t retCode = Csta.cstaHoldCall(this.acsHandle, invokeId, conns[0], false, null);
            Debug.WriteLine("cstaHoldCall result = " + retCode._value);

            var evtBuf = new Csta.EventBuffer_t();
            ushort eventBufSize = Csta.CSTA_MAX_HEAP;
            ushort numEvents;
            retCode = Acs.acsGetEventBlock(this.acsHandle,
                                          evtBuf,
                                          ref eventBufSize,
                                          privData,
                                          out numEvents);

            if (retCode._value < 0)
            {
                if (retCode._value == Acs.ACSERR_BADHDL)
                {
                    ReOpenStream();
                }
                return false;
            }

            if (evtBuf.evt.eventHeader.eventClass.eventClass == Csta.CSTACONFIRMATION && evtBuf.evt.eventHeader.eventType.eventType == Csta.CSTA_HOLD_CALL_CONF)
            {
                return true;// MessageBox.Show("cstaHoldCall Succeded");
            }
            else
            {
                return false; //MessageBox.Show("cstaHoldCall Failed. Error was: " + evtBuf.evt.cstaConfirmation.universalFailure.error);
            }
            
        }

        public bool AnswerCall(string callerNumber)
        {
            if (string.IsNullOrEmpty(callerNumber) || callerNumber.Length > 5) { return false; }
            Csta.ConnectionID_t[] conns = GetCurrentConnections(callerNumber);
            if (conns == null || conns.Length == 0)
            {
                //MessageBox.Show("No active calls");
                return false;
            }
            var invokeId = new Acs.InvokeID_t();
            Acs.RetCode_t retCode = Csta.cstaAnswerCall(this.acsHandle, invokeId, conns[0], null);

            Debug.WriteLine("cstaAnswerCall result = " + retCode._value);

            var evtBuf = new Csta.EventBuffer_t();
            this.privData.length = Att.ATT_MAX_PRIVATE_DATA;
            ushort eventBufSize = Csta.CSTA_MAX_HEAP;
            ushort numEvents;
            retCode = Acs.acsGetEventBlock(this.acsHandle,
                                          evtBuf,
                                          ref eventBufSize,
                                          privData,
                                          out numEvents);
            if (retCode._value < 0)
            {
                if (retCode._value == Acs.ACSERR_BADHDL)
                {
                    ReOpenStream();
                }
                return false;
            }

            if (evtBuf.evt.eventHeader.eventClass.eventClass == Csta.CSTACONFIRMATION && evtBuf.evt.eventHeader.eventType.eventType == Csta.CSTA_ANSWER_CALL_CONF)
                return true;
            // MessageBox.Show("cstaAnswerCall Succeded");
            else
                return false;
            //MessageBox.Show("cstaAnswerCall Failed. Error was: " + evtBuf.evt.cstaConfirmation.universalFailure.error);

        }

        public bool TransferCall(string callerNumber)
        {
            if (string.IsNullOrEmpty(callerNumber) || callerNumber.Length > 5) { return false; }
            Csta.DeviceID_t currentDevice = callerNumber;
            Csta.ConnectionID_t[] conns = GetCurrentConnections(callerNumber);

            if (conns == null || conns.Length == 0)
            {
                //MessageBox.Show("No active calls");
                return false;
            }

            Acs.RetCode_t retCode = Csta.cstaTransferCall(this.acsHandle, new Acs.InvokeID_t(), conns[1], conns[0], this.privData);

            ushort eventBufferSize = Csta.CSTA_MAX_HEAP;
            this.privData.length = Att.ATT_MAX_PRIVATE_DATA;
            var eventBuf = new Csta.EventBuffer_t();
            ushort numEvents;
            retCode = Acs.acsGetEventBlock(this.acsHandle, eventBuf, ref eventBufferSize, this.privData, out numEvents);
            //this.Log("acsGetEventBlock result = " + retCode._value);
            if (retCode._value < 0)
            {
                if (retCode._value == Acs.ACSERR_BADHDL)
                {
                    ReOpenStream();
                }
                return false;
            }

            if (eventBuf.evt.eventHeader.eventClass.eventClass == Csta.CSTACONFIRMATION && eventBuf.evt.eventHeader.eventType.eventType == Csta.CSTA_TRANSFER_CALL_CONF)
            {
                Att.ATTEvent_t attEvt = new Att.ATTEvent_t();
                retCode = Att.attPrivateData(this.privData, attEvt);
                Debug.WriteLine("attPrivateData retCode = " + retCode._value);
                if (attEvt.eventType.eventType == Att.ATT_TRANSFER_CALL_CONF)
                    return true; //MessageBox.Show("TransferCall Succeded. New call UCID = " + attEvt.transferCall.ucid);
                else
                    return false; //MessageBox.Show("Got wrong ATT Event... " + attEvt.eventType.eventType);
            }
            else
            {
                return false; // MessageBox.Show("TransferCall Failed. Error was: " + eventBuf.evt.cstaConfirmation.universalFailure.error);
            }
        }

        public bool CheckAgentLoggedIn(string agentId)
        {
            Csta.DeviceID_t agentId_t = agentId;
            Csta.DeviceID_t split_t = string.Empty;
            // Prepare ATT request
            Acs.RetCode_t retCode = Att.attQueryAgentState(this.privData, ref split_t);
            if (retCode._value < 0)
            {
                //Log("ATT error during attQueryAgentState. Error = " + retCode._value);
                //   return false;
            }

            bool isStreamReOpen = false;
            // Make CSTA call
            while (!isStreamReOpen)
            {
                retCode = Csta.cstaQueryAgentState(this.acsHandle, new Acs.InvokeID_t(), ref agentId_t, this.privData);
                if (retCode._value < 0)
                {
                    if (retCode._value == Acs.ACSERR_BADHDL)
                    {
                        logger.Info("Re-Open stream during check Agent log-in");
                        ReOpenStream();
                        isStreamReOpen = false;
                        // CheckAgentLoggedIn(agentId);
                    }

                }
                else
                    isStreamReOpen = true;
            }
            // Get CSTA results
            ushort eventBufferSize = Csta.CSTA_MAX_HEAP;
            this.privData.length = Att.ATT_MAX_PRIVATE_DATA;
            var eventBuf = new Csta.EventBuffer_t();
            ushort numEvents;
            retCode = Acs.acsGetEventBlock(this.acsHandle, eventBuf, ref eventBufferSize, this.privData, out numEvents);
            // this.Log("acsGetEventBlock result = " + retCode._value);
            if (retCode._value < 0)
            {
                return false;
            }
            if (eventBuf.evt.eventHeader.eventClass.eventClass != Csta.CSTACONFIRMATION)
            {
                // Log("cstaQueryAgentState failed. Error = " + eventBuf.evt.cstaConfirmation.universalFailure.error);
                return false;
            }

            if (eventBuf.evt.cstaConfirmation.queryAgentState.agentState == Csta.AgentState_t.AG_NULL)
            {
                //Log("AgentID status:" + eventBuf.evt.cstaConfirmation.queryAgentState.agentState);
                return false;
            }

            return true;
        }

        #region Private Methods
        private Csta.ConnectionID_t[] GetCurrentConnections(string callerNumber)
        {
            if (!this.configured)
            {
                Debug.WriteLine("Application is not configured");
                //this.mainTabs.SelectTab(configTab);
                return null;
            }
            if (callerNumber.Length == 0 || callerNumber.Length > 5) { return null; }
            Csta.DeviceID_t currentDevice = callerNumber;
            Acs.InvokeID_t invokeId = new Acs.InvokeID_t();
            Acs.RetCode_t retCode = Csta.cstaSnapshotDeviceReq(this.acsHandle,
                                                 invokeId,
                                                 ref currentDevice,
                                                 privData);
            if (retCode._value < 0)
            {
                //MessageBox.Show("cstaSnapshotDeviceReq error: " + retCode);
                return null;
            }
            var evtBuf = new Csta.EventBuffer_t();
            this.privData.length = Att.ATT_MAX_PRIVATE_DATA;
            ushort eventBufSize = Csta.CSTA_MAX_HEAP;
            ushort numEvents;
            retCode = Acs.acsGetEventBlock(this.acsHandle,
                                          evtBuf,
                                          ref eventBufSize,
                                          privData,
                                          out numEvents);

            if (retCode._value != Acs.ACSPOSITIVE_ACK)
            {
                //MessageBox.Show("acsGetEventBlock error: " + retCode);
                return null;
            }
            if (evtBuf.evt.eventHeader.eventClass.eventClass != Csta.CSTACONFIRMATION || evtBuf.evt.eventHeader.eventType.eventType != Csta.CSTA_SNAPSHOT_DEVICE_CONF)
            {
                if (evtBuf.evt.eventHeader.eventClass.eventClass == Csta.CSTACONFIRMATION && evtBuf.evt.eventHeader.eventType.eventType == Csta.CSTA_UNIVERSAL_FAILURE_CONF)
                {
                    return null;
                    //MessageBox.Show("Snapshot device failed. Error: " + evtBuf.evt.cstaConfirmation.universalFailure.error);
                }
                return null;
            }
            int callCount = evtBuf.evt.cstaConfirmation.snapshotDevice.snapshotData.count;
            Csta.ConnectionID_t[] conns = new Csta.ConnectionID_t[callCount];
            for (int i = 0; i < callCount; i++)
            {
                var snapDeviceInfoArray = (Csta.CSTASnapshotDeviceResponseInfo_t[])evtBuf.auxData["snapDeviceInfo"];
                conns[i] = snapDeviceInfoArray[i].callIdentifier;
            }
            return conns;
        }

        private void EventReactionHandler(uint esrparam)
        {
            //if (this.InvokeRequired)
            //{
            //    this.BeginInvoke(new MethodInvoker(delegate
            //    {
            //        string logMsg = "[acsSetESR Test] Event detected. acsHandle = " + esrparam;
            //        //this.logTextBox.AppendText(logMsg); 
            //        //Log(logMsg);
            //    }));
            //}
            Debug.WriteLine("[acsSetESR Test] Event detected. acsHandle = " + esrparam);
        }

        private void Notify(Acs.ACSHandle_t acsHandle)
        {
            ushort numevents = 1;
            ushort bufsize = Csta.CSTA_MAX_HEAP;
            var tmpPrivateData = new Acs.PrivateData_t();
            tmpPrivateData.length = Att.ATT_MAX_PRIVATE_DATA;
            var evtBuf = new Csta.EventBuffer_t();
            // flush the event
            while (numevents > 0)
            {
                var retCode = Acs.acsGetEventBlock(acsHandle, evtBuf, ref bufsize, tmpPrivateData, out numevents);
                if (retCode._value != Acs.ACSPOSITIVE_ACK)
                {
                    if (retCode._value == Acs.ACSERR_BADHDL)
                    {
                        //Log(" The ACS Handle is invalid");
                        continue;
                    } // end of if 
                    else if (retCode._value == Acs.ACSERR_UBUFSMALL)
                    {
                      //  Log(" Passed event buffer size is smaller than the size of the " +
                        //    " next available event for this ACS Stream.");

                        bufsize = (ushort)(bufsize + 500);
                        // The usEventBufSize variable has been reset by the TSAPI Client 
                        // Library to the size of the next message on the ACS              
                        // stream. The application should call acsGetEventBlock( ) 
                        // again with a larger buffer. The ACS event still present 
                        // on the Client Library queue.

                        continue;
                    }// end of else if	
                    else if (retCode._value == Acs.ACSERR_NOMESSAGE)
                    {
                        // The acsGetEventPoll()method return this value to indicate
                        // there were no events available in the Client library queue.
                        //Log(" No events available at this time.");
                        continue;
                    }
                    else
                    {
                       // Log(string.Format(" acsGetEventBlock()/acsGetEventPoll() failed with unknown error {0}.", retCode._value));
                        break;
                    }
                }// end of if 
                else
                {
                    switch (evtBuf.evt.eventHeader.eventClass.eventClass)
                    {
                        case Acs.ACSCONFIRMATION:
                            {
                                switch (evtBuf.evt.eventHeader.eventType.eventType)
                                {
                                    case Acs.ACS_OPEN_STREAM_CONF:
                                        {
                                            if (evtBuf.evt.eventHeader.eventClass.eventClass != 2 || evtBuf.evt.eventHeader.eventType.eventType != 2)
                                            {
                                              //  Log("Could not open stream. ErrorCode = " + evtBuf.evt.acsConfirmation.failureEvent.error);
                                            }
                                            else
                                            {
                                                // Confirmation event received for some other open 
                                                // stream request.
                                             //   Log(" A confirmation event received for an unknown open stream request.");
                                            }
                                            break;
                                        }
                                    case Acs.ACS_CLOSE_STREAM_CONF:
                                        {
                                            if (evtBuf.evt.eventHeader.eventClass.eventClass != Acs.ACSCONFIRMATION || evtBuf.evt.eventHeader.eventType.eventType != Acs.ACS_CLOSE_STREAM_CONF)
                                            {
                                                if (evtBuf.evt.eventHeader.eventClass.eventClass == Acs.ACSCONFIRMATION
                                                    && evtBuf.evt.eventHeader.eventType.eventType == Acs.ACS_UNIVERSAL_FAILURE_CONF)
                                                {
                                                  //  Log("Clear call failed. Error: " + evtBuf.evt.cstaConfirmation.universalFailure.error);
                                                }
                                            }
                                            else
                                            {
                                                // Confirmation event received for some other close 
                                                // stream request.
                                             //   Log(" A confirmation event received for an unknown close stream request.");
                                            }

                                            break;
                                        }
                                    case Acs.ACS_UNIVERSAL_FAILURE_CONF:
                                        {
                                            // Checking for the Failure of Open Stream request
                                            Acs.ACSUniversalFailure_t nError = evtBuf.evt.acsConfirmation.failureEvent.error;
                                         //   Log(" ACS_UNIVERSAL_FAILURE_CONF event received");
                                 
                                            break;
                                        }
                                }
                                break;

                            }
                        case Csta.CSTACONFIRMATION:
                            {
                                switch (evtBuf.evt.eventHeader.eventType.eventType)
                                {
                                    case Csta.CSTA_MONITOR_CONF:
                                        {
                              
                                            break;
                                        }
                                    case Csta.CSTA_UNIVERSAL_FAILURE_CONF:
                                        {
                                            // Checking for the Failure of Monitor Request
                                            var nError = evtBuf.evt.cstaConfirmation.universalFailure.error;
                                           // Log(" ACS_UNIVERSAL_FAILURE_CONF event received");
                       
                                            break;
                                        }
                                    case Csta.CSTA_MONITOR_STOP_CONF:
                                        {
                                            // Matching the invokeID received in this event with invokeId
                                            // received from invoked cstaMonitorDevice method.
                                            //if (g_nStopMonitorInvokeID ==
                                            //    evtBuf.evt.cstaConfirmation.invokeID.ToString())
                                            //{
                                            //    // Sets event object to signaled state.
                                            //    //SetEvent(g_hMonitorStopConfEvent);
                                            //    Log(" Monitor deactivated successfully... ");
                                            //}
                                            //else
                                            //{
                                            //    // Confirmation event received for some other stop monitor 
                                            //    // device request.
                                            //    Log(" A confirmation event received for an unknown stop monitor device request.");
                                            //}
                                            break;
                                        }
                                    case Csta.CSTA_MAKE_CALL_CONF:
                                        {
                                            //if (g_nMakeCallInvokeID == evtBuf.evt.cstaConfirmation.invokeID.ToString())
                                            //{
                                            //    //SetEvent(g_hMakeCllConfEvent);
                                            //    Log("Make Call successfully...");
                                            //}
                                            //else
                                            //{
                                            //    Log("Make call event unsuccessful");
                                            //}
                                            break;
                                        }
                                    default:
                                        {
                                            // Other application should add more cases as per need. 
                                            //Log("CSTA Confirmation event received" +
                                            //    " with unknown event type.Event Type: " + evtBuf.evt.eventHeader.eventType.eventType);
                                            break;
                                        }
                                }
                                break;
                            }
                        case Csta.CSTAUNSOLICITED:
                            {
                                switch (evtBuf.evt.eventHeader.eventType.eventType)
                                {

                                    case Csta.CSTA_SERVICE_INITIATED:
                                        {
                                           // Log(" A Service Initiated event is received. ");
                                            break;
                                        }
                                    case Csta.CSTA_DELIVERED:
                                        {
                                            // Delivered event received

                                            // To store the connection state
                                            Csta.LocalConnectionState_t connectionState;

                                            connectionState = evtBuf.evt.cstaUnsolicited.delivered.localConnectionInfo;
                                            Csta.CSTAEventCause_t eventCause; // To store the event cause
                                            eventCause = evtBuf.evt.cstaUnsolicited.delivered.cause;
                                            // check the connection state and cause for the event
                                            //if (connectionState == csAlerting && eventCause == ecNewCall)
                                            long lcallID = evtBuf.evt.cstaUnsolicited.delivered.
                                                    connection.callID;
                                            string szCallingDeviceID = evtBuf.evt.cstaUnsolicited.delivered.callingDevice.dev.deviceID.ToString();
                                            string alertingDevice = evtBuf.evt.cstaUnsolicited.delivered.alertingDevice.dev.deviceID.ToString();
                                            string staticDevice = evtBuf.evt.cstaUnsolicited.delivered.calledDevice.dev.deviceID.ToString();
                                            string PP = evtBuf.evt.cstaUnsolicited.established.answeringDevice.dev.deviceID.ToString();

                                            if (eventCause == Csta.CSTAEventCause_t.EC_REDIRECTED)
                                            {
                                                //  Log(" Incoming call detected");

                                                // Retrieving the information associated with this event

                                                if ((alertingDevice.Length > 4) && (szCallingDeviceID.ToString().Length > 6))
                                                {
                                                  //  InsertRecord(lcallID, szCallingDeviceID, alertingDevice);
                                                  //  Log(" An incoming Call with CallID " + lcallID + " received" +
                                                     //       " from " + szCallingDeviceID + " to " + alertingDevice + " on " + staticDevice + " :" + PP);
                                                }
                                                else
                                                {
                                                   // Log(" Duplicate Call with CallID " + lcallID + " received" +
                                                        //     " from " + szCallingDeviceID + " to " + alertingDevice + " on " + staticDevice + " :" + PP);
                                                }

                                            } // End of if
                                            else if (eventCause == Csta.CSTAEventCause_t.EC_NEW_CALL)
                                            {
                                               // Log(" New Call with CallID " + lcallID + " received" +
                                                     //       " from " + szCallingDeviceID + " to " + alertingDevice + " on " + staticDevice + " :" + PP);
                                            }
                                            break;
                                        }
                                    case Csta.CSTA_ESTABLISHED:
                                        {
                                            Csta.LocalConnectionState_t connectionState;

                                           // connectionState = evtBuf.evt.cstaUnsolicited.connectionCleared.localConnectionInfo;
                                          //  Csta.CSTAEventCause_t eventCause; // To store the event cause
                                          //  eventCause = evtBuf.evt.cstaUnsolicited.connectionCleared.cause;
                                            // check the connection state and cause for the event
                                            //if (connectionState == csAlerting && eventCause == ecNewCall)
                                            // Retrieving the information associated with this event
                                            long lcallID = evtBuf.evt.cstaUnsolicited.established.establishedConnection.callID;
                                            string szCallingDeviceID = evtBuf.evt.cstaUnsolicited.established.callingDevice.dev.deviceID.ToString();
                                            string alertingDevice = evtBuf.evt.cstaUnsolicited.established.answeringDevice.dev.deviceID.ToString();
                                            string staticDevice = evtBuf.evt.cstaUnsolicited.established.callingDevice.dev.deviceID.ToString();

                                           // Log(" Call Establish with CallID " + lcallID + " received" +
                                           //                " from " + szCallingDeviceID + " to " + alertingDevice + " on " + staticDevice);
                                            break;
                                        }
                                    case Csta.CSTA_CONNECTION_CLEARED:
                                        {
                                            Csta.LocalConnectionState_t connectionState;

                                            //connectionState = evtBuf.evt.cstaUnsolicited.connectionCleared.localConnectionInfo;
                                           // Csta.CSTAEventCause_t eventCause; // To store the event cause
                                          //  eventCause = evtBuf.evt.cstaUnsolicited.connectionCleared.cause;
                                            // check the connection state and cause for the event
                                            //if (connectionState == csAlerting && eventCause == ecNewCall)
                                            // Retrieving the information associated with this event
                                          //  long lcallID = evtBuf.evt.cstaUnsolicited.connectionCleared.droppedConnection.callID;
                                          //  string szCallingDeviceID = evtBuf.evt.cstaUnsolicited.connectionCleared.droppedConnection.deviceID.ToString();

                                          //  UpdateRecord(lcallID, szCallingDeviceID);

                                            //Log(" Connection cleared event is recieved with callId " + lcallID + " from " + szCallingDeviceID);
                                            break;
                                        }
                                    case Csta.CSTA_CALL_CLEARED:
                                        {
                                            // Delivered event received

                                            // To store the connection state
                                            Csta.LocalConnectionState_t connectionState;

                                            connectionState = evtBuf.evt.cstaUnsolicited.callCleared.localConnectionInfo;
                                            Csta.CSTAEventCause_t eventCause; // To store the event cause
                                            eventCause = evtBuf.evt.cstaUnsolicited.callCleared.cause;
                                            // check the connection state and cause for the event
                                            //if (connectionState == csAlerting && eventCause == ecNewCall)
                                            // Retrieving the information associated with this event
                                            long lcallID = evtBuf.evt.cstaUnsolicited.callCleared.clearedCall.callID;
                                            string szCallingDeviceID = evtBuf.evt.cstaUnsolicited.callCleared.clearedCall.deviceID.ToString();

                                          //  UpdateRecord(lcallID, szCallingDeviceID);

                                         //   Log(" Call cleared event is recived. ");
                                            break;
                                        }
                                    default:
                                        {
                                            // Other application should add more cases as per need. 
                                            //Log(" An event of type CSTAUNSOLICITED is received with unknown event class. Event Type: " + evtBuf.evt.eventHeader.eventType.eventType);
                                            break;
                                        }
                                }
                                break;
                            }
                        default:
                            {
                                // Other application should add more cases as per need. 
                                //Log("An event of type CSTAUNSOLICITED is received with unknown event class. Event Type: " + evtBuf.evt.eventHeader.eventType);
                                break;
                            }
                    }
                }
                //switch (evtBuf.evt.eventHeader.eventType.eventType)
                //{
                //    case Csta.CSTA_SERVICE_INITIATED:
                //        {
                //            logMsg = ("CSTA_SERVICE_INITIATED: Cause:" + evtBuf.evt.cstaUnsolicited.serviceInitiated.cause + ", CallId:" + evtBuf.evt.cstaUnsolicited.serviceInitiated.initiatedConnection.callID + ", State:" + evtBuf.evt.cstaUnsolicited.serviceInitiated.localConnectionInfo);
                //        }
                //        break;
                //}
            }

            
            //Notify(acsHandle);
        }

        #endregion

    } 
}