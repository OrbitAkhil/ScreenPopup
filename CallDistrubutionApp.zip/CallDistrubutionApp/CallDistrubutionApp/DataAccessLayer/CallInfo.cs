﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace CallDistrubutionApp.DataAccessLayer
{
    public class CallInfo : ICrud<ICommand>
    {
        public bool Insert(ICommand obj)
        {
            return obj.Execute();
        }

        public bool Update(ICommand obj)
        {
            return obj.Execute();
        }

        public bool Delete(ICommand obj)
        {
            return obj.Execute();
        }

        public  DataSet Select(ICommand obj)
        {
            return obj.SelectData();
        }

        public object GetScalerRecord(ICommand obj)
        {
            return obj.GetScalerRecord();
        }
    }
}