﻿using CallDistrubutionApp.DataAccessLayer;
using NLog;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CallDistrubutionApp
{
    public partial class Form1 : Form
    {
        private static NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        System.Timers.Timer timeDelay;
        public Form1()
        {
            InitializeComponent();
            timeDelay = new System.Timers.Timer();
            timeDelay.Interval = 60000;
            timeDelay.Elapsed += new System.Timers.ElapsedEventHandler(timeDelay_Elapsed); 
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timeDelay.Enabled = true;
            logger.Info("Call distribution service is started");

            Simulator.Instance.OpenStream();
        }

        void timeDelay_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                var objCall = new CallInfo();
                var cmd = new CommandBuilder();

                cmd.CommandText = "Select Count(*) from tbl_AutoDial_Premium_Call where IsAllocated='N' ";
                int callCount = Convert.ToInt32(objCall.GetScalerRecord(cmd));
                if(callCount > 0)
                {
                    cmd = new CommandBuilder();
                    cmd.CommandText = "Select AgentId,ExtensionNo,LoginType from tbl_AutoDial_Login where LoginStatus='D' order by LoginDateTime";
                    var ds = objCall.Select(cmd);
                    if(ds.Tables[0].Rows.Count>0)
                    {
                        foreach (DataRow dr in ds.Tables[0].Rows)
                        {
                            int agentId = Convert.ToInt32(dr["AgentId"]);
                            int extensionNo = Convert.ToInt32(dr["ExtensionNo"]);
                        
                            cmd = new CommandBuilder();
                            cmd.CommandText = "select count(*) from tbl_AutoDial_Call_Diversion where AgentId='"+ agentId +"' and ExtensionNo='"+ extensionNo +"' and CallStatus NOT IN ('I','S')";
                            int agentCallCount = Convert.ToInt32(objCall.GetScalerRecord(cmd));
                            
                            if(agentCallCount == 0)
                            {
                                
                                string premiumCallerName = string.Empty;
                                int premiumCallerId = 0;
                                string premiumCallerNumber = string.Empty;
                                int recordId = 0;
                                cmd = new CommandBuilder();
                                cmd.CommandText = "select top 1  CallerId,CallerName,CallerNumber,Id from tbl_AutoDial_Premium_Call where IsAllocated='N' Order By CreatedOn desc ";
                                var ds_PremiumCall = objCall.Select(cmd);
                                if (ds_PremiumCall.Tables[0].Rows.Count > 0)
                                {
                                    var dr_PremiumCall = ds_PremiumCall.Tables[0].Rows[0];
                                    recordId = Convert.ToInt32(dr_PremiumCall["Id"]);
                                    premiumCallerId = Convert.ToInt32(dr_PremiumCall["CallerId"]);
                                    premiumCallerName = Convert.ToString(dr_PremiumCall["CallerName"]);

                                    if (Convert.ToString(dr_PremiumCall["CallerNumber"]).StartsWith("0"))
                                        premiumCallerNumber = "90" + Convert.ToString(dr_PremiumCall["CallerNumber"]).TrimStart('0');
					                else
                                        premiumCallerNumber = "90" + Convert.ToString(dr_PremiumCall["CallerNumber"]);
                                }

                                if (recordId>0)
                                { 
                                    Simulator.Instance.SetAgentState(agentId.ToString(), extensionNo.ToString(), Tsapi.Csta.AgentMode_t.AM_READY, Tsapi.Att.ATTWorkMode_t.WM_AUX_WORK);

                                    var agentState = Simulator.Instance.GetAgentState(agentId.ToString(), extensionNo.ToString());
                                    if (agentState == Tsapi.Att.ATTWorkMode_t.WM_AUX_WORK)
                                    {
                                        cmd = new CommandBuilder();
                                        cmd.CommandText = "Insert into tbl_AutoDial_Call_Diversion(CallerId,CallerName,CallStatus,CallerMobile,AgentId,ExtensionNo,DropOutId) values (" + premiumCallerId + ",'" + premiumCallerName + "','A','" + premiumCallerNumber + "'," + agentId + ",'" + extensionNo + "'," + recordId + ")";
                                        objCall.Insert(cmd);

                                        cmd = new CommandBuilder();
                                        cmd.CommandText = "Update tbl_AutoDial_Premium_Call set IsAllocated = 'Y' where IsAllocated = 'N' and Id=" + recordId + " ";
                                        objCall.Update(cmd);
                                    }
                                }
                            }
                        }
                    }
                }
               // cmd.SpName = "sp_AllocateDropCaseToActiveAgents";

               // objCall.Update(cmd);
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            timeDelay.Enabled = false;
            logger.Info("Call distribution service is stopped");
            Simulator.Instance.AbortStream();
        }


    }
}
