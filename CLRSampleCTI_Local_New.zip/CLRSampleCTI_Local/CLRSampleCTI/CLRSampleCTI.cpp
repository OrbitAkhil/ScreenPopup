// CLRSampleCTI.cpp : main project file.

#include "stdafx.h"
#include <iostream>
#include <fstream>
#include <conio.h>
#include <tchar.h>
#include <map>
#include <Windows.h>
#include <TlHelp32.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <sql.h>
#include <string>
using namespace std;

#include "ACS.H"
#include "CSTA.H"
#include "ATTPRIV.H"

using namespace System;
CSTAMonitorCrossRefID_t g_lMonitorCrossRefID1;

// To store InvokeID for open stream request
int g_nOpenStreamInvokeID = 0;
// To store InvokeID for close stream request
int g_nCloseStreamInvokeID = 0;
// To store InvokeID for start monitor device request
int g_nStartMonitorInvokeID1 = 0;

// To store InvokeID for stop monitor device request
int g_nStopMonitorInvokeID1 = 0;


// To store InvokeID for Make Call request
int g_nMakeCallInvokeID = 0;

// Handle object used to wait for acsOpenStreamConf Event
HANDLE g_hOpenStreamConfEvent;
// Handle object used to wait for acsCloseStreamConf Event
HANDLE g_hCloseStreamConfEvent;
// Handle object used to wait for MonitorDeviceConf Event
HANDLE g_hMonitorDeviceConfEvent;
// Handle object used to wait for MonitorStopConf Event
HANDLE g_hMonitorStopConfEvent;
// Handle object used to wait for Make Call Event
HANDLE g_hMakeCllConfEvent;

Version_t g_szPrivateDataVersion;
ATTPrivateData_t privateData;
// Count for the available service names
static int nServicesCount = 0;

// Data structure to store service name
map<int, char*> serviceNameMap;
typedef pair <int, char*> serviceNamePair;


bool OpenACSStream(ACSHandle_t* a_pAcsHandle);
// Method to monitor a device
void MonitorDevice(ACSHandle_t* a_pAcsHandle);

// Method to Make Call
void MakeCall(ACSHandle_t* a_pAcsHandle);

// Method to stop monitoring
void StopMonitor(ACSHandle_t* a_pAcsHandle);

// Method to Close an ACS stream
void CloseStream(ACSHandle_t* a_pAcsHandle);

// Method to Abort an ACS Stream
void AbortStream(ACSHandle_t* a_pAcsHandle);

void InsertSQL(string CallId, string Caller, string Extn);

// Callback function that will be called when an event
// is available in Client library event queue
void __stdcall ESRCallback(unsigned long esrParam);

// Method to that retrieve the events from Client library event queue
// and process each event.
void Notify(ACSHandle_t* a_pAcsHandle);

// Initializes application variables
bool InitApplication();

// Print error messages and exit the application
void PrintErrorAndExit(ACSHandle_t* a_pAcsHandle);

// Enumerate service names registered with TSAPI Service.
void EnumerateServiceNames();

void InsertRecord(SQLINTEGER callerId, SQLCHAR custMobile[100], SQLCHAR extensionNo[20], SQLCHAR ucid[50], SQLCHAR userEnterCode[50])
{
	SQLRETURN ret;
#define SQL_RESULT_LEN 240
#define SQL_RETURN_CODE_LEN 1000
	//define handles and variables
	SQLHANDLE sqlConnHandle;
	SQLHANDLE sqlStmtHandle;
	SQLHANDLE sqlEnvHandle;
	SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];
	//initializations
	sqlConnHandle = NULL;
	sqlStmtHandle = NULL;
	//allocations
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle))
		goto COMPLETED;
	//output

	cout << "Attempting connection to SQL Server...";
	cout << "\n";
	//connect to SQL Server  
	//I am using a trusted connection and port 14808
	//it does not matter if you are using default or named instance
	//just make sure you define the server name and the port
	//You have the option to use a username/password instead of a trusted connection
	//but is more secure to use a trusted connection

	switch (SQLDriverConnect(sqlConnHandle,
		NULL,
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=10.130.120.14,52431;UID=indigo_user;PWD=Interglobe001;Database=IndigoPopUp;",
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=master;UID=username;PWD=password;",
		(SQLWCHAR*)L"Driver={SQL Server};Server=172.18.13.35,52431;UID=PMS;PWD=Pnterglobe100;Database=IndigoDB_DEV;",
		SQL_NTS,
		retconstring,
		1024,
		NULL,
		SQL_DRIVER_NOPROMPT)) {
	case SQL_SUCCESS:
		cout << "Successfully connected to SQL Server";
		cout << "\n";
		break;
	case SQL_SUCCESS_WITH_INFO:
		cout << "Successfully connected to SQL Server";
		cout << "\n";
		break;
	case SQL_INVALID_HANDLE:
		cout << "Could not connect to SQL Server";
		cout << "\n";
		goto COMPLETED;
	case SQL_ERROR:
		cout << "Could not connect to SQL Server";
		cout << "\n";
		goto COMPLETED;
	default:
		break;
	}
	//if there is a problem connecting then exit application
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle))
		goto COMPLETED;
	//output
	/*cout << "\n";
	cout << "Executing T-SQL query...";
	cout << "\n";*/

	ret = SQLPrepare(sqlStmtHandle, (SQLTCHAR*)_T("{call sp_AddNewCallTest(?,?,?,?,?,?,?)}"), SQL_NTS);
	if (!SQL_SUCCEEDED(ret)) {
		printf("Could not create prepared statement\n");
		SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
		SQLFreeHandle(SQL_HANDLE_DBC, sqlStmtHandle);
		SQLFreeHandle(SQL_HANDLE_ENV, sqlStmtHandle);
		SQLFreeHandle(SQL_HANDLE_ENV, sqlStmtHandle);
		SQLFreeHandle(SQL_HANDLE_ENV, sqlStmtHandle);
		SQLFreeHandle(SQL_HANDLE_ENV, sqlStmtHandle);
		exit(EXIT_FAILURE);
	}
	else {
		//printf("Created prepared statement.\n");
	}

	SQLCHAR custName[100] = "Caller23";
	SQLCHAR callStatus[2] = "A";

	SQLLEN strFieldLen = SQL_NTS;
	SQLLEN custIDLen = 0;
	SQLLEN extensionLen = 0;
	// Bind the data arrays to the parameters in the prepared SQL 
	// statement
	ret = SQLBindParameter(sqlStmtHandle, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER,
		0, 0, &callerId, 0, &custIDLen);

	ret = SQLBindParameter(sqlStmtHandle, 2, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		100, 0, (SQLPOINTER)custName, 0, &strFieldLen);

	ret = SQLBindParameter(sqlStmtHandle, 3, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		20, 0, (SQLPOINTER)extensionNo, 0, &strFieldLen);


	ret = SQLBindParameter(sqlStmtHandle, 4, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		2, 0, (SQLPOINTER)callStatus, 0, &strFieldLen);


	ret = SQLBindParameter(sqlStmtHandle, 5, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		100, 0, (SQLPOINTER)custMobile, 0, &strFieldLen);
	ret = SQLBindParameter(sqlStmtHandle, 6, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		50, 0, (SQLPOINTER)ucid, 0, &strFieldLen);
	ret = SQLBindParameter(sqlStmtHandle, 7, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		50, 0, (SQLPOINTER)userEnterCode, 0, &strFieldLen);


	// Execute the prepared statement.
	//printf("Running prepared statement...");
	ret = SQLExecute(sqlStmtHandle);
	if (!SQL_SUCCEEDED(ret)) {
		printf("not successful!\n");
		goto COMPLETED;
	}
	else {
		printf("successful.\n");
		goto COMPLETED;
	}

	//close connection and free resources
COMPLETED:
	SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
	SQLDisconnect(sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
	//pause the console window - exit when key is pressed
}

void UpdateRecord(SQLINTEGER callerId, SQLCHAR extensionNo[20])
{
	SQLRETURN ret;
#define SQL_RESULT_LEN 240
#define SQL_RETURN_CODE_LEN 1000
	//define handles and variables
	SQLHANDLE sqlConnHandle;
	SQLHANDLE sqlStmtHandle;
	SQLHANDLE sqlEnvHandle;
	SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];
	//initializations
	sqlConnHandle = NULL;
	sqlStmtHandle = NULL;
	//allocations
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle))
		goto COMPLETED;
	//output

	cout << "Attempting connection to SQL Server...";
	cout << "\n";
	//connect to SQL Server  
	//I am using a trusted connection and port 14808
	//it does not matter if you are using default or named instance
	//just make sure you define the server name and the port
	//You have the option to use a username/password instead of a trusted connection
	//but is more secure to use a trusted connection

	switch (SQLDriverConnect(sqlConnHandle,
		NULL,
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=10.130.120.14,52431;UID=indigo_user;PWD=Interglobe001;Database=IndigoPopUp;",
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=master;UID=username;PWD=password;",
		(SQLWCHAR*)L"Driver={SQL Server};Server=172.18.13.31;UID=indigo_user;PWD=Globe@12#$%;Database=IndigoDB;",
		SQL_NTS,
		retconstring,
		1024,
		NULL,
		SQL_DRIVER_NOPROMPT)) {
	case SQL_SUCCESS:
		cout << "Successfully connected to SQL Server";
		cout << "\n";
		break;
	case SQL_SUCCESS_WITH_INFO:
		cout << "Successfully connected to SQL Server";
		cout << "\n";
		break;
	case SQL_INVALID_HANDLE:
		cout << "Could not connect to SQL Server";
		cout << "\n";
		goto COMPLETED;
	case SQL_ERROR:
		cout << "Could not connect to SQL Server";
		cout << "\n";
		goto COMPLETED;
	default:
		break;
	}
	//if there is a problem connecting then exit application
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle))
		goto COMPLETED;
	//output
	/*cout << "\n";
	cout << "Executing T-SQL query...";
	cout << "\n";*/
	//where CallerId = ? AND ExtensionNo=?
	ret = SQLPrepare(sqlStmtHandle, (SQLTCHAR*)L"update tbl_Call_Diversion set CallStatus = 'C',CallEndDateTime=GETDATE() where CallerId = ?", SQL_NTS);
	if (!SQL_SUCCEEDED(ret)) {
		printf("Could not create prepared statement\n");
		SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
		exit(EXIT_FAILURE);
	}
	else {
		//printf("Created prepared statement.\n");
	}

	SQLLEN custIDLen = 0;
	SQLLEN extensionLen = 0;
	SQLLEN strFieldLen = SQL_NTS;
	// Bind the data arrays to the parameters in the prepared SQL 
	// statement
	ret = SQLBindParameter(sqlStmtHandle, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER,
		0, 0, &callerId, 0, &custIDLen);
	/*ret = SQLBindParameter(sqlStmtHandle, 2, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
	20, 0, (SQLPOINTER)extensionNo, 0, &strFieldLen);*/

	// Execute the prepared statement.
	//printf("Running prepared statement...");
	ret = SQLExecute(sqlStmtHandle);
	if (!SQL_SUCCEEDED(ret)) {
		printf("not successful!\n");
		goto COMPLETED;
	}
	else {
		printf("successful.\n");
		goto COMPLETED;
	}

	//close connection and free resources
COMPLETED:
	SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
	SQLDisconnect(sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
	//pause the console window - exit when key is pressed
}


void UpdateEstablishedDateTime(SQLINTEGER callerId, SQLCHAR extensionNo[20])
{
	SQLRETURN ret;
#define SQL_RESULT_LEN 240
#define SQL_RETURN_CODE_LEN 1000
	//define handles and variables
	SQLHANDLE sqlConnHandle;
	SQLHANDLE sqlStmtHandle;
	SQLHANDLE sqlEnvHandle;
	SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];
	//initializations
	sqlConnHandle = NULL;
	sqlStmtHandle = NULL;
	//allocations
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle))
		goto COMPLETED;
	//output

	cout << "Attempting connection to SQL Server...";
	cout << "\n";
	//connect to SQL Server  
	//I am using a trusted connection and port 14808
	//it does not matter if you are using default or named instance
	//just make sure you define the server name and the port
	//You have the option to use a username/password instead of a trusted connection
	//but is more secure to use a trusted connection

	switch (SQLDriverConnect(sqlConnHandle,
		NULL,
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=10.130.120.14,52431;UID=indigo_user;PWD=Interglobe001;Database=IndigoPopUp;",
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=master;UID=username;PWD=password;",
		(SQLWCHAR*)L"Driver={SQL Server};Server=172.18.13.31;UID=indigo_user;PWD=Globe@12#$%;Database=IndigoDB;",
		SQL_NTS,
		retconstring,
		1024,
		NULL,
		SQL_DRIVER_NOPROMPT)) {
	case SQL_SUCCESS:
		cout << "Successfully connected to SQL Server";
		cout << "\n";
		break;
	case SQL_SUCCESS_WITH_INFO:
		cout << "Successfully connected to SQL Server";
		cout << "\n";
		break;
	case SQL_INVALID_HANDLE:
		cout << "Could not connect to SQL Server";
		cout << "\n";
		goto COMPLETED;
	case SQL_ERROR:
		cout << "Could not connect to SQL Server";
		cout << "\n";
		goto COMPLETED;
	default:
		break;
	}
	//if there is a problem connecting then exit application
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle))
		goto COMPLETED;
	//output
	/*cout << "\n";
	cout << "Executing T-SQL query...";
	cout << "\n";*/
	//where CallerId = ? AND ExtensionNo=?
	ret = SQLPrepare(sqlStmtHandle, (SQLTCHAR*)L"update tbl_Call_Diversion set CallStatus='E',CallEstablishedDateTime=GETDATE() where CallerId = ? and ExtensionNo = ?", SQL_NTS);
	if (!SQL_SUCCEEDED(ret)) {
		printf("Could not create prepared statement\n");
		SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
		exit(EXIT_FAILURE);
	}
	else {
		//printf("Created prepared statement.\n");
	}

	SQLLEN custIDLen = 0;
	SQLLEN extensionLen = 0;
	SQLLEN strFieldLen = SQL_NTS;
	// Bind the data arrays to the parameters in the prepared SQL 
	// statement
	ret = SQLBindParameter(sqlStmtHandle, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER,
		0, 0, &callerId, 0, &custIDLen);
	ret = SQLBindParameter(sqlStmtHandle, 2, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
	20, 0, (SQLPOINTER)extensionNo, 0, &strFieldLen);
	// Execute the prepared statement.
	//printf("Running prepared statement...");
	ret = SQLExecute(sqlStmtHandle);
	if (!SQL_SUCCEEDED(ret)) {
		printf("not successful!\n");
		goto COMPLETED;
	}
	else {
		printf("successful.\n");
		goto COMPLETED;
	}

	//close connection and free resources
COMPLETED:
	SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
	SQLDisconnect(sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
	//pause the console window - exit when key is pressed
}
ConnectionID_t* GetCurrentConnections(ACSHandle_t* a_pAcsHandle, char callingDevice[64]);
void MakeCall(ACSHandle_t* a_pAcsHandle, char callingDevice[64], char calledDevice[64]);
void ClearCall(ACSHandle_t* a_pAcsHandle, char callingDevice[64]);
void HoldCall(ACSHandle_t* a_pAcsHandle, char callingDevice[64]);

uintptr_t _beginthread(
	void(__cdecl *start_address)(void *),
	unsigned stack_size,
	void *arglist
	);

int main(array<System::String ^> ^args)
{
	// Maximum wait time interval for receiving an event
	const int APP_DEF_WAIT_TIMEOUT = 5000; // Five seconds

	InitApplication();

	// Store handle of the ACS stream
	ACSHandle_t* pAcsHandle = new ACSHandle_t;

	if (OpenACSStream(pAcsHandle))
	{
		// Wait until we receive a confirmation event for 
		// acsOpenStream() request

		if (WaitForSingleObject(g_hOpenStreamConfEvent, APP_DEF_WAIT_TIMEOUT)
			== WAIT_OBJECT_0)
		{
			MonitorDevice(pAcsHandle);

			// Wait until we receive a confirmation event for 
			// cstaMonitorConf() request
			if (WaitForSingleObject(g_hMonitorDeviceConfEvent, APP_DEF_WAIT_TIMEOUT)
				== WAIT_OBJECT_0)
			{
				do
				{
					// This loop run until user press X or x on console, till that  
					// time we will continue receiving monitor event.
					cout << endl
						<< " Monitoring is on, Do you want to stop monitoring now?"
						<< endl << " Please press x or X to stop the Monitor or any other"
						" key to continue monitoring..." << endl;
					char chInputChar = _getche();
					if (chInputChar == 'X' || chInputChar == 'x')
					{
						break;
					}
					else if (chInputChar == 'M' || chInputChar == 'm')
					{
						MakeCall(pAcsHandle, "2004", "909958574015");
					}
					else if (chInputChar == 'E' || chInputChar == 'e')
					{
						ClearCall(pAcsHandle, "2004");
					}
					else
					{
						// Continue with loop
					}
				} while (true);// loop ends when user press X or x

				// Stop the Monitor request
				cout << endl << " Trying to Stop the Monitor...." << endl << endl;
				StopMonitor(pAcsHandle);

				// Wait until we receive a confirmation event for 
				// cstaMonitorStopConf() request

				if (WaitForSingleObject(g_hMonitorStopConfEvent, APP_DEF_WAIT_TIMEOUT)
					== WAIT_OBJECT_0)
				{
					cout << " Application has received monitor closed"
						" confirmation event." << endl;
				}// end of if
				else
				{
					cout << " Error: MonitorStopConfEvent event not received"
						" in set time limit." << endl;
					PrintErrorAndExit(pAcsHandle);
				}
			}// end of if
			else
			{
				cout << " Error: MonitorDeviceConfEvent event not received"
					" in set time limit." << endl;
				PrintErrorAndExit(pAcsHandle);
			}

		}// end of if 
		else
		{
			cout << " Error: OpenStreamConfEvent event not received"
				" in set time limit." << endl;
			PrintErrorAndExit(pAcsHandle);
		}

		// Close the ACS stream

		cout << " Trying to close the stream...." << endl << endl;

		// Close the opened stream
		CloseStream(pAcsHandle);

		if (WaitForSingleObject(g_hCloseStreamConfEvent, APP_DEF_WAIT_TIMEOUT)
			== WAIT_OBJECT_0)
		{
			cout << " Application has received close"
				" stream confirmation event." << endl;
		}// end of if
		else
		{
			cout << " Error: CloseStreamConfEvent event not received"
				" in set time limit." << endl;
			PrintErrorAndExit(pAcsHandle);
		}
	}
	else
	{
		// when the application reaches here then that means 
		// the application is not able to send request for Opening the Stream
		cout << " Error: Failed to open stream.... ";
	}
	delete pAcsHandle;
	return 0;
}

bool InitApplication()
{
	// The CreateEvent function creates or opens a named or unnamed 
	// event object.
	g_hOpenStreamConfEvent = CreateEvent(0, TRUE, FALSE, 0);
	g_hCloseStreamConfEvent = CreateEvent(0, TRUE, FALSE, 0);
	g_hMonitorDeviceConfEvent = CreateEvent(0, TRUE, FALSE, 0);
	g_hMakeCllConfEvent = CreateEvent(0, TRUE, FALSE, 0);
	g_hMonitorStopConfEvent = CreateEvent(0, TRUE, FALSE, 0);
	return true;
}

void __stdcall ESRCallback(unsigned long esrParam)
{
	ACSHandle_t* acsHandle = (ACSHandle_t*)esrParam;

	Notify(acsHandle);
}

void PrintErrorAndExit(ACSHandle_t* a_pAcsHandle)
{
	cout << " Due to the error occured, the application will close now,"
		" please retry after some time." << endl;

	// As we are closing the application in an error condition
	// we should abort the ACS stream using acsAbortStream method
	// which will free the resource immediately.

	cout << " Trying to abort the stream...." << endl << endl;

	// Abort the opened stream
	AbortStream(a_pAcsHandle);

	exit(-1);
}

bool OpenACSStream(ACSHandle_t* a_pAcsHandle)
{
	// constants will be used in acsOpenStream method.
	const int SEND_QUEUE_SIZE = 0;
	const int RECEIVE_QUEUE_SIZE = 0;
	const int SEND_EXTRA_BUF_SIZE = 5;
	const int RECEIVE_EXTRA_BUF_SIZE = 5;
	const int MINIMUM_LENGTH = 3;

	// Store the Return code of the method
	RetCode_t nRetCode;
	// To hold the advertised service name
	ServerID_t szServiceName;
	// To hold CTI user login ID
	LoginID_t szLoginID;
	// To hold CTI user password
	Passwd_t szPassword;
	// To hold authentication information
	ACSAuthInfo_t authInfo;

	strcpy_s(szServiceName, "AVAYA#IGTGGN2AVPCM2#CSTA#IGTGGN2AAES2");

	nRetCode = acsQueryAuthInfo((ServerID_t*)szServiceName, &authInfo);
	if (nRetCode != ACSPOSITIVE_ACK)
	{
		cout << " Error: acsQueryAuthInfo method failed.";
	}
	// Default login ID for this application
	strcpy_s(szLoginID, "phonon");
	// Default password for this application
	strcpy_s(szPassword, "phonon@123");

	AppName_t szAppName = "DeviceMonitor"; // Can be empty string

	Version_t szApiVersion = "TS1-2";

	InvokeID_t lInvokeID = 0;

	

	// Set the vendor field to 'VERSION'
	strcpy_s(privateData.vendor, "VERSION");
	privateData.data[0] = PRIVATE_DATA_ENCODING;

	// A special function is used to convert version string into the format 
	// required by the acsOpenStream function.
	strcpy_s(g_szPrivateDataVersion, "7");

	// Setting the formatted PDV version starting from second byte in the data 
	// field.
	if ((attMakeVersionString(g_szPrivateDataVersion, &(privateData.data[1])))
	> 0)
	{

		privateData.length = (unsigned short)strlen(&privateData.data[1]) + 2;
	}
	else
	{
		exit(-1);
	}

	bool bIsSuccess = false;
	while (!bIsSuccess)
	{
		nRetCode = acsOpenStream(a_pAcsHandle,
			LIB_GEN_ID,	// Library takes the control for generating InvokeID.
			lInvokeID,	// This param is ignored when the 2nd parameter is LIB_GEN_ID
			ST_CSTA,		// requesting CSTA stream type.
			&szServiceName,	// CTI Link name "AVAYA#SWITCH1#CSTA#SERVERNAME1" 
			&szLoginID,	    // CTI user login ID
			&szPassword,	// CTI user password
			&szAppName,	    // name of the application
			ACS_LEVEL1,	    // LIB Version, will be ignored 
			&szApiVersion,	// API Version
			SEND_QUEUE_SIZE,// send queue size using default 0
			SEND_EXTRA_BUF_SIZE, // send extra buf size
			RECEIVE_QUEUE_SIZE, // receive queue size using default 0
			RECEIVE_EXTRA_BUF_SIZE,	// receive extra bufs
			(PrivateData_t *)&privateData // buffer for Private Data
			);

		if (nRetCode > 0) // acsOpenStream returned successfully
		{
			// storing invoke ID for future use
			cout << "Open Connection Successfully";
			g_nOpenStreamInvokeID = (int)nRetCode;
			cout << a_pAcsHandle;
			bIsSuccess = true; // Stop the loop
		}
		else if (nRetCode < 0) // acsOpenStream failed
		{
			switch (nRetCode)
			{
			case ACSPOSITIVE_ACK:
			{
									// The function is successful
									bIsSuccess = true; // Stop the loop
									break;
			}
			case ACSERR_APIVERDENIED:
			{	// This return value indicates that the API Version requested is
										// invalid and not supported by the existing API Client Library.

										cout << endl << " Error: acsOpenStream method failed to"
											" open stream.." << endl;
										// Requesting user to enter TSAPI version again.
										cout << " Error: API Version is incorrect. Trying again." << endl;

										bIsSuccess = false; // Continue the loop
										break;
			}
			case ACSERR_BADPARAMETER:
			{	// One or more parameters invalid.
										// Validate supplied parameter with the help of 
										// TSAPI Exerciser tool.
										break;
			}
			default:
			{
					   // Some unhandled error occured
					   const int SLEEP_TIME = 3000;
					   cout << endl
						   << " Error: acsOpenStream method failed to open stream..";
					   cout << endl << " Error code: " << nRetCode;
					   Sleep(SLEEP_TIME);
					   return false;
			}
			}
		}
		else // case when nRetCode == 0
		{
			// Not possible as LIB_GEN_ID is used in this example.
		}
	}

	nRetCode = acsSetESR(*a_pAcsHandle, ESRCallback, (unsigned long)a_pAcsHandle,
		FALSE);

	// Verification for the positive response
	if (nRetCode != ACSPOSITIVE_ACK)
	{
		cout << " ERROR: acsSetESR() method return with an error.";

		if (nRetCode == ACSERR_BADHDL)
		{
			cout << " ulAcsHandle being used is not a valid handle" << endl;
		}
		else
		{
			cout << " acsSetESR() failed with unknown error. " << endl;
			cout << " Error code: " << nRetCode;
		}

	}
	return true;
}

void MonitorDevice(ACSHandle_t* a_pAcsHandle)
{
	// Set the DeviceID of the Deivce to be monitored
	DeviceID_t FirstVDN = "15111"; // Default device ID	

	// Store the return code of the method
	RetCode_t nRetCode = 0;

	CSTAMonitorFilter_t filter;	// Store the Monitor Filter setting	

	filter.call = cfQueued; // Settting filter for Call Queued event.

	// The Agent Filter is supported only for ACD Split devices.
	filter.agent = 0; // We are using a extension device in this example

	// The Feature Filter and Maintenance Filter are not supported.
	filter.feature = 0;
	filter.maintenance = 0;

	filter.privateFilter = 0;

	nRetCode = cstaMonitorCallsViaDevice(*a_pAcsHandle, 0, &FirstVDN, &filter, NULL);
	if (nRetCode < 0)	{ cout << " Failed to monitor device ID: " << FirstVDN << endl;		cout << " Error code: " << nRetCode; }
	else	{ g_nStartMonitorInvokeID1 = nRetCode; }


}

void StopMonitor(ACSHandle_t* a_pAcsHandle)
{
	// Store the Return code of the method
	RetCode_t nRetCode;
	nRetCode = cstaMonitorStop(*a_pAcsHandle, 0, g_lMonitorCrossRefID1, 0);
	if (nRetCode < 0)	{ cout << " Failed to stop monitor" << endl;	cout << " Error Code :" << nRetCode; return; }
	else 	{ g_nStopMonitorInvokeID1 = nRetCode; }


}

void AbortStream(ACSHandle_t* a_pAcsHandle)
{
	// acsAbortStream(): Request to abort an ACS stream. No confirmation event
	//		will be provided for this method.
	// @a_pAcsHandle: Handle returned from the acsOpenStream() method
	// @privateData: - Presently this parameter is ignored so please pass NULL
	//					in this parameter for acsAbortStream() method

	RetCode_t nRetCode = acsAbortStream(*a_pAcsHandle, NULL);

	// Checking for the negative response
	if (nRetCode < 0)
	{
		if (nRetCode == ACSERR_BADHDL)
		{
			cout << " Abort:The ACS Handle is invalid " << endl << endl;
		}
		else
		{
			cout << " acsAbortStream() failed with unknown error. " << endl;
			cout << " Error code: " << nRetCode;
		}
	}
	else
	{
		cout << " ACS Stream aborted successfully... " << endl << endl;
	}
}

void CloseStream(ACSHandle_t* a_pAcsHandle)
{
	// acsCloseStream(): Request to close an ACS stream. A confirmation event
	//		will be provided for this method.
	// @a_pAcsHandle: Handle returned from the acsOpenStream() method
	// @invokeID: Setting it to zero as Library generated ID is used in this
	//		example.
	// @privateData: - Presently this parameter is ignored so please pass NULL
	//					in this parameter for acsCloseStream() method
	RetCode_t nRetCode = acsCloseStream(*a_pAcsHandle, 0, NULL);

	// Checking for the negative response
	if (nRetCode < 0)
	{
		// Vrifying for the ACS handle
		if (nRetCode == ACSERR_BADHDL)
		{
			// This error indicates the ACS handle passed in acsCloseStream method
			// is invalid. Please check valid handle value passed to acsCloseSream
			// method. The handle could be invalid because the stream associated 
			// with it, is already closed or the TSAPI Client library could not find 
			// the associated stream. In this case the application will not receive
			// an ACSCloseStreamConfEvent. 

			cout << " Close:The ACS Handle is invalid" << endl;
		}
		else
		{
			cout << " acsCloseStream() failed with unknown error. " << endl;
			cout << " Error code: " << nRetCode;
		}
	}
	else
	{
		cout << " ACS Stream close request sent successfully... " << endl;
		g_nCloseStreamInvokeID = nRetCode;
	}
}

void Notify(ACSHandle_t* a_pAcsHandle)
{
	// A boolean variable which will be true if event is successfully
	// retrieved otherwise false.
	bool isEventRetrived = false;
	//Buffer Size 
	const int APP_DEF_DEFAULT_BUFFER_SIZE = 12288;
	// CSTA event buffer size
	unsigned short usEventBufSize = APP_DEF_DEFAULT_BUFFER_SIZE;
	CSTAEvent_t *cstaEvent = NULL;
	unsigned short usNumEvents = 1;

	while (!isEventRetrived || (usNumEvents > 0 && usEventBufSize > 0))
	{
		// To hold the error cause
		int nError;
		// ATT service request private data buffer that store
		// private data coming with event.
		ATTPrivateData_t privateData;

		// Setting the private data length same as the size of
		// data field of ATTPrivateData_t structure.
		privateData.length = sizeof(privateData.data);

		// For the next iterations need to free the memory
		// before reallocating new memory.
		if (NULL != cstaEvent)
		{
			//Free the buffer memory
			free(cstaEvent);
		}

		// Reallocate buffer in case any failure detected in 
		// retrieving event earlier.
		cstaEvent = (CSTAEvent_t*)malloc((SIZE_T)usEventBufSize);

		// To store method return value
		RetCode_t nRetCode;

#ifdef BLOCKING_MODE
		{
			nRetCode = acsGetEventPoll(*a_pAcsHandle,
				(void *)cstaEvent,
				&usEventBufSize,
				(PrivateData_t *)&privateData,
				&usNumEvents);
		}
#else
		{
			//Parameter description same as acsGetEventBlock.
			nRetCode = acsGetEventBlock(*a_pAcsHandle,
				(void *)cstaEvent,
				&usEventBufSize,
				(PrivateData_t *)&privateData,
				&usNumEvents);

		}
#endif
		if (nRetCode != ACSPOSITIVE_ACK)
		{
			if (nRetCode == ACSERR_BADHDL)
			{
				cout << " Notify:The ACS Handle is invalid" << endl << endl;
			} // end of if 
			else if (nRetCode == ACSERR_UBUFSMALL)
			{
				cout << " Passed event buffer size is smaller than the size of the"
					" next available event for this ACS Stream." << endl << endl;
				usEventBufSize = usEventBufSize + 500;

				continue;
			}// end of else if	
			else if (nRetCode == ACSERR_NOMESSAGE)
			{
				// The acsGetEventPoll()method return this value to indicate
				// there were no events available in the Client library queue.
				cout << " No events available at this time.";
				continue;
			}
			else
			{
				cout << " acsGetEventBlock()/acsGetEventPoll() failed with"
					" unknown error. " << endl;
				cout << " Error code: " << nRetCode;
				break;
			}
		}// end of if 
		else
		{
			// Setting true as we have successfully retrieved event
			isEventRetrived = true;

			// Checking for Confirmation event for the Open Stream request
			switch (cstaEvent->eventHeader.eventClass)
			{
			case ACSCONFIRMATION:
			{
									switch (cstaEvent->eventHeader.eventType)
									{
									case ACS_OPEN_STREAM_CONF:
									{
																 if (g_nOpenStreamInvokeID ==
																	 cstaEvent->event.acsConfirmation.invokeID)
																 {
																	 cout << endl << " acsOpenStremConfEvent received - Stream"
																		 " opened successfully." << endl;
																	 cout << "   API Version: " <<
																		 cstaEvent->event.acsConfirmation.u.acsopen.apiVer
																		 << endl;
																	 cout << "   Library Version: " <<
																		 cstaEvent->event.acsConfirmation.u.acsopen.libVer
																		 << endl << endl;

																	 // verify that Private Data is correctly negotiated.

																	 // 1st check the length of the Private Data received
																	 if (privateData.length <= 0)
																	 {
																		 // handle error condtion ( abort the Stream )
																		 // return error
																		 cout << endl << " Private Data length is zero"
																			 " in acsOpenStreamConf event. Private data"
																			 " is not sent as a part of this event.";

																		 PrintErrorAndExit(a_pAcsHandle);
																	 }

																	 // 2nd Check the vendor String
																	 if (strcmp(privateData.vendor, ECS_VENDOR_STRING) != 0)
																	 {
																		 // hanlde error condtion ( abort the Stream )
																		 // return error
																	 }

																	 // 3rd check the One byte descriminator
																	 if (privateData.data[0] != PRIVATE_DATA_ENCODING)
																	 {
																		 // handle error condtion ( abort the Stream )
																		 // return error
																	 }
																	 else
																	 {
																		 // Retrieving the Private Data 
																		 cout << " PrivateData = VENDOR: " <<
																			 privateData.vendor << endl;

																		 // Checking private data version, whether
																		 // it is same as requested or not.
																		 char cPDVReturned = privateData.data[1];

																		 // To hold returned PDV as number
																		 int nReturnedPDV = atoi(&cPDVReturned);

																		 if (strchr(g_szPrivateDataVersion, '-') == NULL)
																		 {
																			 // Requested version is specific i.e. does not contain '-'
																			 int nRequestedPDV = atoi(g_szPrivateDataVersion);

																			 if (nRequestedPDV == nReturnedPDV)
																			 {
																				 cout << " Private data version negotiation is " 																	"successful.";
																				 cout << " Negotiated private data version is: "
																					 << cPDVReturned << endl;
																			 }
																			 else
																			 {
																				 cout << " Private data version negotiation is failed.";
																				 // This is an error condition where AE Server does
																				 // not support the PDV requested.
																			 }
																		 }
																		 else
																		 {
																			 char* szFirst = _strdup(g_szPrivateDataVersion);
																			 // To store second part of requested PDV
																			 char* szSecond;
																			 strtok_s(szFirst, "-", &szSecond);

																			 int nMinVersion = atoi(szFirst);
																			 int nMaxVersion = atoi(szSecond);

																			 // compare value of m and n with
																			 // PDV returned.
																			 if (nReturnedPDV >= nMinVersion
																				 &&
																				 nReturnedPDV <= nMaxVersion
																				 )
																			 {
																				 cout << " Private data version negotiation is " 																	"successful.";
																				 cout << " Negotiated private data version is: "
																					 << cPDVReturned << endl;
																			 }
																			 else
																			 {
																				 cout << " Private data version negotiation is failed.";
																				 // This is an error condition where AE Server does
																				 // not support the PDV requested.
																			 }
																		 }
																	 }
																	 // Sets event object to signaled state.
																	 SetEvent(g_hOpenStreamConfEvent);
																 }
																 else
																 {
																	 // Confirmation event received for some other open 
																	 // stream request.
																	 cout << " A confirmation event received for an unknown open"
																		 " stream request.";
																 }
																 break;
									}
									case ACS_CLOSE_STREAM_CONF:
									{
																  if (g_nCloseStreamInvokeID ==
																	  cstaEvent->event.acsConfirmation.invokeID)
																  {
																	  // Sets event object to signaled state.
																	  SetEvent(g_hCloseStreamConfEvent);
																  }
																  else
																  {
																	  cout << " A confirmation event received for an unknown close"
																		  " stream request.";
																  }

																  break;
									}
									case ACS_UNIVERSAL_FAILURE_CONF:
									{
																	   // Checking for the Failure of Open Stream request
																	   nError = cstaEvent->event.acsConfirmation.u.failureEvent.error;
																	   cout << " ACS_UNIVERSAL_FAILURE_CONF event received" << endl;
																	   // Verifying error is for open stream that this
																	   // application has opened 
																	   if (g_nOpenStreamInvokeID ==
																		   cstaEvent->event.acsConfirmation.invokeID)
																	   {
																		   // Checking for the password of the loginID
																		   switch (nError)
																		   {
																		   case tserverBadPasswordOrLogin:
																		   {
																											 cout << " CTI login password is incorrect" << endl;
																											 break;
																		   }
																		   case tserverNoUserRecord:
																		   {
																									   cout << " No user object was found in the security"
																										   " database for the login specified in the"
																										   " ACSOpenStream request." << endl;
																									   break;
																		   }
																		   default:
																		   {
																					  cout << " ACS_UNIVERSAL_FAILURE_CONF event received"
																						  " with unknown error";
																					  cout << " Error Code: " << nError;
																		   }
																		   }
																	   }

																	   else
																	   {
																		   cout << " An ACS_UNIVERSAL_FAILURE_CONF event received"
																			   " for an unknown request." << endl;
																		   cout << " Error Code: " << nError;
																	   }
																	   break;
									}
									default:
									{
											   // Other application should add more cases as per need. 
											   cout << " ACS Confirmation event received"
												   << " with unknown event type." << endl;
											   cout << " Event Type: " << cstaEvent->eventHeader.eventType;
									}
									} // End of switch
									break;
			} // End of ACSCONFIRMATION case
			case CSTACONFIRMATION:
			{
									 switch (cstaEvent->eventHeader.eventType)
									 {
									 case CSTA_MONITOR_CONF:
									 {
															   // Matching the invokeID received in this event with invokeId
															   // received from invoked cstaMonitorDevice method.
															   if (g_nStartMonitorInvokeID1 == cstaEvent->event.cstaConfirmation.invokeID)
															   {
																   g_lMonitorCrossRefID1 = cstaEvent->event.cstaConfirmation.u.monitorStart.monitorCrossRefID;
																   cout << " g_nStartMonitorInvokeID1: " << g_nStartMonitorInvokeID1;
																   cout << " g_lMonitorCrossRefID1: " << g_lMonitorCrossRefID1;
																   SetEvent(g_hMonitorDeviceConfEvent);
															   }
															   else
															   {
																   cout << " A confirmation event received for an unknown"
																	   " monitor device request.";
															   }

															   break;
									 }

									 case CSTA_MONITOR_STOP_CONF:
									 {
																	// Matching the invokeID received in this event with invokeId
																	// received from invoked cstaMonitorDevice method.
																	if (g_nStopMonitorInvokeID1 == cstaEvent->event.cstaConfirmation.invokeID)
																	{
																		cout << endl << " Monitor deactivated successfully for... " << g_nStopMonitorInvokeID1 << endl;
																		SetEvent(g_hMonitorStopConfEvent);
																	}
																	else
																	{
																		cout << " A confirmation event received for an unknown"
																			" stop monitor device request.";
																	}
																	break;
									 }


									 }// end of CSTA Confirmation event type switch
									 break;
			}// end of CSTACONFIRMATION case
			case CSTAUNSOLICITED:
			{
									switch (cstaEvent->eventHeader.eventType)
									{

									case CSTA_DELIVERED:
									{
														   LocalConnectionState_t connectionState;

														   connectionState = cstaEvent->event.cstaUnsolicited.u.delivered.
															   localConnectionInfo;
														   CSTAEventCause_t eventCause; // To store the event cause
														   eventCause = cstaEvent->event.cstaUnsolicited.u.delivered.cause;
														   // check the connection state and cause for the event
														   //if (connectionState == csAlerting && eventCause == ecNewCall)
														   if (eventCause == ecNewCall || eventCause == ecRedirected)
														   {
															   //cout << " Incoming call Delivered" << eventCause << endl;
															   // Retrieving the information associated with this event
															   long lcallID = cstaEvent->event.cstaUnsolicited.u.delivered.
																   connection.callID;
															   char* szCallingDeviceID = cstaEvent->event.cstaUnsolicited.u.
																   delivered.callingDevice.deviceID;
															   char* alertingDevice = cstaEvent->event.cstaUnsolicited.u.
																   delivered.alertingDevice.deviceID;
															   char* staticDevice = cstaEvent->event.cstaUnsolicited.u.delivered.calledDevice.deviceID;
															   char* PP = cstaEvent->event.cstaUnsolicited.u.established.answeringDevice.deviceID;

															   int nlen = strlen(alertingDevice);
															   int nlenCallingDeviceID = strlen(szCallingDeviceID);

															   

															   if (privateData.length > 0)
															   {
																   // Event buffer that will contain the decoded private data 
																   // information.
																   ATTEvent_t attEvent;

																   // Check to ensure that private data is successfully decoded.
																   if (attPrivateData(&privateData, &attEvent) == ACSPOSITIVE_ACK)
																   {
																	   // check the event type					
																	   /* if (attEvent.eventType == ATT_DELIVERED)
																	   {*/

																	   char* UCID = attEvent.u.deliveredEvent.ucid;
																	   cout << " The UCID is: " << UCID;
																	   char* UEC = attEvent.u.deliveredEvent.userEnteredCode.data;
																	   cout << " UserEnteredCode is : " << UEC;

																	   if (nlen>0 && nlenCallingDeviceID>0)
																	   {
																		   InsertRecord((SQLINTEGER)lcallID, (SQLCHAR*)szCallingDeviceID, (SQLCHAR*)alertingDevice, (SQLCHAR*)UCID, (SQLCHAR*)UEC);
																		   cout << " An incoming Call with CallID " << lcallID << " received"
																			   << " from " << szCallingDeviceID << " to " << alertingDevice << " on " << staticDevice << endl;
																	   }

																	   // } 
																   } // End of if
																   else
																   {
																	   // Decoding Error.
																	   cout << " An error occured while decoding"
																		   << " private data." << endl;
																   }
															   }// End of outer if
															   else
															   {
																   // The event does not contain any private Data.
															   }

														   } // End of if
														   break;
									} // End of Case
									case CSTA_ESTABLISHED:
									{
															 LocalConnectionState_t connectionState;

															 connectionState = cstaEvent->event.cstaUnsolicited.u.established.localConnectionInfo;
															 CSTAEventCause_t eventCause; // To store the event cause
															 eventCause = cstaEvent->event.cstaUnsolicited.u.established.cause;
															 // Retrieving the information associated with this event
															 long lcallID = cstaEvent->event.cstaUnsolicited.u.established.establishedConnection.callID;
															 char* szCallingDeviceID = cstaEvent->event.cstaUnsolicited.u.established.establishedConnection.deviceID;

															 //UpdateEstablishedDateTime((SQLINTEGER)lcallID, (SQLCHAR*)szCallingDeviceID);
															 break;
									} // End of Case
									case CSTA_FAILED:
									{
														break;
									}
									case  CSTA_CONNECTION_CLEARED:
									{
												LocalConnectionState_t connectionState;

												connectionState = cstaEvent->event.cstaUnsolicited.u.connectionCleared.localConnectionInfo;
												CSTAEventCause_t eventCause; // To store the event cause
												eventCause = cstaEvent->event.cstaUnsolicited.u.connectionCleared.cause;
												// Retrieving the information associated with this event
												long lcallID = cstaEvent->event.cstaUnsolicited.u.connectionCleared.droppedConnection.callID;
												char* szDroppedCallDeviceID = cstaEvent->event.cstaUnsolicited.u.connectionCleared.droppedConnection.deviceID;
												char* szReleasingCallDeviceID = cstaEvent->event.cstaUnsolicited.u.connectionCleared.releasingDevice.deviceID;

												//UpdateRecord((SQLINTEGER)lcallID, (SQLCHAR*)szDroppedCallDeviceID);

												cout << endl << " Call cleared event is recived for- " << lcallID << " to " << szDroppedCallDeviceID << " to " << szReleasingCallDeviceID << endl;
												break;
									}

									} // End of switch
									break;
			}// end of CSTACONFIRMATION case

			}// End of event class switch
		}// end of else
	}// end of while loop

	if (NULL != cstaEvent)
	{
		//Free the buffer memory
		free(cstaEvent);
	}
} // end of Notify() method


ConnectionID_t* GetCurrentConnections(ACSHandle_t* a_pAcsHandle, char callingDevice[64])
{
	DeviceID_t szDeviceID = "2005";
	strcpy_s(szDeviceID, callingDevice);
	RetCode_t retCode = cstaSnapshotDeviceReq(*a_pAcsHandle,
		0,
		&szDeviceID,
		(PrivateData_t *)&privateData);

	if (retCode < 0)
	{
		return NULL;
	}
	cout << retCode;
	bool isEventRetrived = false;
	const int APP_DEF_DEFAULT_BUFFER_SIZE = 4096;
	unsigned short usEventBufSize = APP_DEF_DEFAULT_BUFFER_SIZE;
	CSTAEvent_t *cstaEvent = new CSTAEvent_t();
	unsigned short usNumEvents;
	int nError;
	
	privateData.length = ATT_MAX_PRIVATE_DATA;
	cout << privateData.length;
	retCode = acsGetEventBlock(*a_pAcsHandle,
		cstaEvent,
		&usEventBufSize,
		(PrivateData_t *)&privateData,
		&usNumEvents);
	cout << retCode;
	if (retCode != ACSPOSITIVE_ACK)
	{
		return NULL;
	}
	isEventRetrived = true;

	if (cstaEvent->eventHeader.eventClass != CSTACONFIRMATION || cstaEvent->eventHeader.eventType != CSTA_SNAPSHOT_DEVICE_CONF)
	{
		if (cstaEvent->eventHeader.eventClass == CSTACONFIRMATION && cstaEvent->eventHeader.eventType == CSTA_UNIVERSAL_FAILURE_CONF)
		{

		}
		return NULL;
	}

	int callCount = cstaEvent->event.cstaConfirmation.u.snapshotDevice.snapshotData.count;
	ConnectionID_t *conns = new ConnectionID_t[callCount];
	for (int i = 0; i < callCount; i++)
	{
		CSTASnapshotDeviceResponseInfo_t *info = (CSTASnapshotDeviceResponseInfo_t*)cstaEvent->event.cstaConfirmation.u.snapshotDevice.snapshotData.info;
		conns[i] = info[i].callIdentifier;
	}
	return conns;

}


void MakeCall(ACSHandle_t* a_pAcsHandle, char callingDevice[64], char calledDevice[64])
{
	ofstream MakeCall;
	MakeCall.open("E:\\ISMS\\MakeCall.txt");
	MakeCall << "DEvice Calling";
	DeviceID_t szDeviceID = "2005";
	strcpy_s(szDeviceID, callingDevice);
	DeviceID_t calDeviceID = "909871194303";
	strcpy_s(calDeviceID, calledDevice);
	// Store the return code of the method
	RetCode_t nRetCode = 0;

	CSTAMonitorFilter_t filter;	// Store the Monitor Filter setting	
	// Pass 0 for a specific filter category or pass NULL for the filter parameter.
	// Call filters are supported for station device.
	filter.call = cfQueued; // Settting filter for Call Queued event.
	// The Agent Filter is supported only for ACD Split devices.
	filter.agent = 0; // We are using a extension device in this example
	// The Feature Filter and Maintenance Filter are not supported.
	filter.feature = 0;
	filter.maintenance = 0;
	// A zero Private Filter means that the application wants to receive
	// the private events. If Private Filter is non-zero, private events 
	// will be filtered out.
	filter.privateFilter = 0;

	nRetCode = cstaMakeCall(*a_pAcsHandle, // ACS Stream handle
		0, // Invoke ID is ignored, as it is library generated
		&szDeviceID, // Calling DeviceID 
		&calDeviceID, // Called DeviceID
		NULL // Private data not passed with this request
		);

	if (nRetCode < 0)
	{
		MakeCall << " Failed to call device ID: " << calDeviceID << endl;
		MakeCall << " Error code: " << nRetCode;
	}
	else
	{
		// cstaMonitorDevice returned successfully
		MakeCall << "Make Call Successful.";
		g_nMakeCallInvokeID = nRetCode;
		MakeCall << g_nMakeCallInvokeID;

	}
}

void ClearCall(ACSHandle_t* a_pAcsHandle, char callingDevice[64])
{
	ofstream ClearCall;
	ClearCall.open("E:\\ISMS\\ClearCall.txt");
	ClearCall << "DEvice Call Clear";
	DeviceID_t szDeviceID = "2005";
	strcpy_s(szDeviceID, callingDevice);
	// Store the return code of the method
	RetCode_t nRetCode = 0;

	CSTAMonitorFilter_t filter;	// Store the Monitor Filter setting	
	// Pass 0 for a specific filter category or pass NULL for the filter parameter.
	// Call filters are supported for station device.
	filter.call = cfQueued; // Settting filter for Call Queued event.
	// The Agent Filter is supported only for ACD Split devices.
	filter.agent = 0; // We are using a extension device in this example
	// The Feature Filter and Maintenance Filter are not supported.
	filter.feature = 0;
	filter.maintenance = 0;
	// A zero Private Filter means that the application wants to receive
	// the private events. If Private Filter is non-zero, private events 
	// will be filtered out.
	filter.privateFilter = 0;

	ConnectionID_t *conns = GetCurrentConnections(a_pAcsHandle, callingDevice);

	/*if (conns == NULL || conns.Length == 0)
	{
	MessageBox.Show("No active calls");
	return;
	}*/

	nRetCode = cstaClearCall(*a_pAcsHandle, // ACS Stream handle
		0, // Invoke ID is ignored, as it is library generated
		&conns[0],
		NULL // Private data not passed with this request
		);

	if (nRetCode < 0)
	{
		ClearCall << " Failed to call device ID: " << callingDevice << endl;
		ClearCall << " Error code: " << nRetCode;
	}
	else
	{
		// cstaMonitorDevice returned successfully
		ClearCall << "Clear Call Successful.";
		ClearCall << g_nMakeCallInvokeID;

	}
}

void HoldCall(ACSHandle_t* a_pAcsHandle, char callingDevice[64])
{
	ofstream HoldCall;
	HoldCall.open("E:\\ISMS\\HoldCall.txt");
	HoldCall << "DEvice on Hold";
	DeviceID_t szDeviceID = "2005";
	strcpy_s(szDeviceID, callingDevice);
	// Store the return code of the method
	RetCode_t nRetCode = 0;

	CSTAMonitorFilter_t filter;	// Store the Monitor Filter setting	
	// Pass 0 for a specific filter category or pass NULL for the filter parameter.
	// Call filters are supported for station device.
	filter.call = cfQueued; // Settting filter for Call Queued event.
	// The Agent Filter is supported only for ACD Split devices.
	filter.agent = 0; // We are using a extension device in this example
	// The Feature Filter and Maintenance Filter are not supported.
	filter.feature = 0;
	filter.maintenance = 0;
	// A zero Private Filter means that the application wants to receive
	// the private events. If Private Filter is non-zero, private events 
	// will be filtered out.
	filter.privateFilter = 0;

	ConnectionID_t *conns = GetCurrentConnections(a_pAcsHandle, callingDevice);

	/*if (conns == NULL || conns.Length == 0)
	{
	MessageBox.Show("No active calls");
	return;
	}*/

	nRetCode = cstaHoldCall(*a_pAcsHandle, // ACS Stream handle
		0, // Invoke ID is ignored, as it is library generated
		&conns[0],
		false,
		NULL // Private data not passed with this request
		);

	if (nRetCode < 0)
	{
		HoldCall << " Failed to hold call device ID: " << callingDevice << endl;
		HoldCall << " Error code: " << nRetCode;
	}
	else
	{
		// cstaMonitorDevice returned successfully
		HoldCall << "Make Call Successful.";

	}
}
