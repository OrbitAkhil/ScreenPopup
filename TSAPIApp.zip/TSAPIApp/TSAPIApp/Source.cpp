#include "stdafx.h"
#include <iostream>
#include <ctime>
#include <fstream>
#include <conio.h>
#include <tchar.h>
#include <map>
#include <Windows.h>
#include <TlHelp32.h>
#include <string>
#include <sql.h>
#include <sqltypes.h>
#include <sql.h>
#include <sqlext.h>

using namespace std;

#include "ACS.H"
#include "CSTA.H"
#include "ATTPRIV.H"

enum WorkM;
enum talkmode;

CSTAMonitorCrossRefID_t g_lMonitorCrossRefID;
// To store InvokeID for open stream request
int g_nOpenStreamInvokeID = 0;
// To store InvokeID for close stream request
int g_nCloseStreamInvokeID = 0;
// To store InvokeID for Make Call request
int g_nMakeCallInvokeID = 0;
// To store InvokeID for start monitor device request
int g_nStartMonitorInvokeID = 0;
// To store InvokeID for stop monitor device request
int g_nStopMonitorInvokeID = 0;
// To store InvokeID for Get Agent State request
int g_nAgentStateInvokeID = 0;


// Handle object used to wait for acsOpenStreamConf Event
HANDLE g_hOpenStreamConfEvent;
// Handle object used to wait for acsCloseStreamConf Event
HANDLE g_hCloseStreamConfEvent;
// Handle object used to wait for Make Call Event
HANDLE g_hMakeCllConfEvent;
// Handle object used to wait for MonitorDeviceConf Event
HANDLE g_hMonitorDeviceConfEvent;
// Handle object used to wait for MonitorStopConf Event
HANDLE g_hMonitorStopConfEvent;
// Handle object used to wait for AgentStateConf Event
HANDLE g_hAgentStateConfEvent;

Version_t g_szPrivateDataVersion;

// Count for the available service names
static int nServicesCount = 0;

// Method to Open an ACS Stream
bool OpenACSStream();
ConnectionID_t* GetCurrentConnections(DeviceID_t callingDevice);
// Method to Make a Call
bool MakeCall(ACSHandle_t* a_pAcsHandle, char callingDevice[64], char calledDevice[64]);
bool ClearCall(ACSHandle_t* a_pAcsHandle, char callingDevice[64]);
bool HoldCall(ACSHandle_t* a_pAcsHandle, char callingDevice[64]);
// Method to Close an ACS stream
bool CloseStream(ACSHandle_t* a_pAcsHandle);
// Method to Abort an ACS Stream
bool AbortStream(ACSHandle_t* a_pAcsHandle);
// Method to monitor a device
bool MonitorDevice(ACSHandle_t* a_pAcsHandle, char AgentId[64], char Dev[64]);
// Method to stop monitoring
bool StopMonitor(ACSHandle_t* a_pAcsHandle, long refeID);

bool SetAgentState(ACSHandle_t* a_pAcsHandle, char AgentId[64], char Dev[64], AgentMode_t agentMode, ATTWorkMode_t workMode);
// Method to get Agent State
bool AgentState(ACSHandle_t* a_pAcsHandle, char DEvId[64]);
// Method to get Agent Mode
string AgentMod(ACSHandle_t* a_pAcsHandle);
//Insert in DB
//void InsertSQL(string CallId, string Caller, string Extn);

// Print error messages and exit the application
void PrintErrorAndExit(ACSHandle_t* a_pAcsHandle);

// Method to that retrieve the events from Client library event queue
// and process each event.
void Notify(ACSHandle_t* a_pAcsHandle);

// Callback function that will be called when an event
// is available in Client library event queue
void __stdcall ESRCallback(unsigned long esrParam);

// Initializes application variables
bool InitApplication();

// Enumerate service names registered with TSAPI Service.
//void EnumerateServiceNames();
// constants will be used in acsOpenStream method.
ACSHandle_t* a_pAcsHandle = new ACSHandle_t;

extern "C"
{
	__declspec(dllexport) bool OpenConnection()
	{
		InitApplication();
		if (OpenACSStream())
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	__declspec(dllexport) bool CloseConnection()
	{
		if (CloseStream(a_pAcsHandle))
			return true;
		else
			return false;
	}

	__declspec(dllexport) bool ClearDevice(char callingDevice[64])
	{
		if (ClearCall(a_pAcsHandle, callingDevice))
			return true;
		else
			return false;
	}
	__declspec(dllexport) bool HoldDevice(char callingDevice[64])
	{
		if (HoldCall(a_pAcsHandle, callingDevice))
			return true;
		else
			return false;
	}
	__declspec(dllexport) bool CallDevice(char callingDevice[64], char calledDevice[64])
	{
		if (MakeCall(a_pAcsHandle, callingDevice, calledDevice))
			return true;
		else
			return false;
	}

	__declspec(dllexport) bool MonitorStart(char AgentId[64],char Str[64])
	{
		if (MonitorDevice(a_pAcsHandle, AgentId, Str))
			return true;
		else
			return false;

	}

	__declspec(dllexport) bool MonitorStop(long REFID)
	{
		if (StopMonitor(a_pAcsHandle, REFID))
			return true;
		else
			return false;
	}

	__declspec(dllexport) bool SetAgentState(char AgentId[64], char Dev[64], AgentMode_t agentMode, ATTWorkMode_t workMode)
	{
		if (SetAgentState(a_pAcsHandle, AgentId, Dev, agentMode, workMode))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	__declspec(dllexport) bool GetAgentState(char Dev[64])
	{
		if (AgentState(a_pAcsHandle, Dev))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

}
//int _tmain(int argc, _TCHAR* argv[])
//{
//	InitApplication();
//
//	OpenACSStream();
//}


bool InitApplication()
{
	g_hOpenStreamConfEvent = CreateEvent(0, TRUE, FALSE, 0);
	g_hCloseStreamConfEvent = CreateEvent(0, TRUE, FALSE, 0);
	g_hMakeCllConfEvent = CreateEvent(0, TRUE, FALSE, 0);
	g_hMonitorDeviceConfEvent = CreateEvent(0, TRUE, FALSE, 0);
	g_hMonitorStopConfEvent = CreateEvent(0, TRUE, FALSE, 0);
	g_hAgentStateConfEvent = CreateEvent(0, TRUE, FALSE, 0);
	return true;
}

void InsertRecord(SQLINTEGER callerId, SQLCHAR custMobile[100], SQLCHAR extensionNo[20])
{
	ofstream InsertLog;
	InsertLog.open("E:\\ISMS\\InsertLog.txt");
	SQLRETURN ret;
#define SQL_RESULT_LEN 240
#define SQL_RETURN_CODE_LEN 1000
	//define handles and variables
	SQLHANDLE sqlConnHandle;
	SQLHANDLE sqlStmtHandle;
	SQLHANDLE sqlEnvHandle;
	SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];
	//initializations
	sqlConnHandle = NULL;
	sqlStmtHandle = NULL;
	//allocations
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle))
		goto COMPLETED;
	//output

	InsertLog << "Attempting connection to SQL Server...";
	InsertLog << "\n";
	//connect to SQL Server  
	//I am using a trusted connection and port 14808
	//it does not matter if you are using default or named instance
	//just make sure you define the server name and the port
	//You have the option to use a username/password instead of a trusted connection
	//but is more secure to use a trusted connection

	switch (SQLDriverConnect(sqlConnHandle,
		NULL,
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=master;UID=username;PWD=password;",
		(SQLWCHAR*)L"Driver={SQL Server};Server=172.18.13.35,52431;UID=Indigo;PWD=Interglobe001;Database=IndigoPopUp;",
		SQL_NTS,
		retconstring,
		1024,
		NULL,
		SQL_DRIVER_NOPROMPT)) {
	case SQL_SUCCESS:
		InsertLog << "Successfully connected to SQL Server";
		InsertLog << "\n";
		break;
	case SQL_SUCCESS_WITH_INFO:
		InsertLog << "Successfully connected to SQL Server";
		InsertLog << "\n";
		break;
	case SQL_INVALID_HANDLE:
		InsertLog << "Could not connect to SQL Server";
		InsertLog << "\n";
		goto COMPLETED;
	case SQL_ERROR:
		InsertLog << "Could not connect to SQL Server";
		InsertLog << "\n";
		goto COMPLETED;
	default:
		break;
	}
	//if there is a problem connecting then exit application
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle))
		goto COMPLETED;
	//output
	InsertLog << "\n";
	InsertLog << "Executing T-SQL query...";
	InsertLog << "\n";

	ret = SQLPrepare(sqlStmtHandle, (SQLTCHAR*)L"insert into tbl_AutoDial_Call_Diversion(CallerId,CallerName,ExtensionNo,CallStatus,CallerMobile) values(?,?,?,?,?)", SQL_NTS);
	if (!SQL_SUCCEEDED(ret)) {
		InsertLog << "Could not create prepared statement\n";
		SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
		SQLFreeHandle(SQL_HANDLE_DBC, sqlStmtHandle);
		SQLFreeHandle(SQL_HANDLE_ENV, sqlStmtHandle);
		SQLFreeHandle(SQL_HANDLE_ENV, sqlStmtHandle);
		SQLFreeHandle(SQL_HANDLE_ENV, sqlStmtHandle);
		SQLFreeHandle(SQL_HANDLE_ENV, sqlStmtHandle);
		exit(EXIT_FAILURE);
	}
	else {
		InsertLog << "Created prepared statement.\n";
	}

	SQLCHAR custName[100] = "Caller23";
	SQLCHAR callStatus[2] = "A";

	SQLLEN strFieldLen = SQL_NTS;
	SQLLEN custIDLen = 0;
	SQLLEN extensionLen = 0;
	// Bind the data arrays to the parameters in the prepared SQL 
	// statement
	ret = SQLBindParameter(sqlStmtHandle, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER,
		0, 0, &callerId, 0, &custIDLen);

	ret = SQLBindParameter(sqlStmtHandle, 2, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		100, 0, (SQLPOINTER)custName, 0, &strFieldLen);

	ret = SQLBindParameter(sqlStmtHandle, 3, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		20, 0, (SQLPOINTER)extensionNo, 0, &strFieldLen);


	ret = SQLBindParameter(sqlStmtHandle, 4, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		2, 0, (SQLPOINTER)callStatus, 0, &strFieldLen);


	ret = SQLBindParameter(sqlStmtHandle, 5, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		100, 0, (SQLPOINTER)custMobile, 0, &strFieldLen);


	// Execute the prepared statement.
	InsertLog << "Running prepared statement...";
	ret = SQLExecute(sqlStmtHandle);
	if (!SQL_SUCCEEDED(ret)) {
		InsertLog << "not successful!\n";
		goto COMPLETED;
	}
	else {
		InsertLog << "successful.\n";
		goto COMPLETED;
	}

	//close connection and free resources
COMPLETED:
	SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
	SQLDisconnect(sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
	//pause the console window - exit when key is pressed
}

void UpdateDeliveredRecord(SQLINTEGER callerId, SQLCHAR custMobile[100], SQLCHAR extensionNo[20])
{
	ofstream UpdateLog;
	UpdateLog.open("E:\\ISMS\\UpdateLog.txt");
	UpdateLog << "Call Delivered";
	SQLRETURN ret;
#define SQL_RESULT_LEN 240
#define SQL_RETURN_CODE_LEN 1000
	//define handles and variables
	SQLHANDLE sqlConnHandle;
	SQLHANDLE sqlStmtHandle;
	SQLHANDLE sqlEnvHandle;
	SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];
	//initializations
	sqlConnHandle = NULL;
	sqlStmtHandle = NULL;
	//allocations
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle))
		goto COMPLETED;
	//output

	/*cout << "Attempting connection to SQL Server...";
	cout << "\n";*/
	//connect to SQL Server  
	//I am using a trusted connection and port 14808
	//it does not matter if you are using default or named instance
	//just make sure you define the server name and the port
	//You have the option to use a username/password instead of a trusted connection
	//but is more secure to use a trusted connection

	switch (SQLDriverConnect(sqlConnHandle,
		NULL,
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=master;UID=username;PWD=password;",
		(SQLWCHAR*)L"Driver={SQL Server};Server=172.18.13.35,52431;UID=PMS;PWD=Pnterglobe100;Database=IndigoDB_DEV;",
		SQL_NTS,
		retconstring,
		1024,
		NULL,
		SQL_DRIVER_NOPROMPT)) {
	case SQL_SUCCESS:
		UpdateLog << "Successfully connected to SQL Server";
		UpdateLog << "\n";
		break;
	case SQL_SUCCESS_WITH_INFO:
		UpdateLog << "Successfully connected to SQL Server";
		UpdateLog << "\n";
		break;
	case SQL_INVALID_HANDLE:
		UpdateLog << "Could not connect to SQL Server";
		UpdateLog << "\n";
		goto COMPLETED;
	case SQL_ERROR:
		UpdateLog << "Could not connect to SQL Server";
		UpdateLog << "\n";
		goto COMPLETED;
	default:
		break;
	}
	//if there is a problem connecting then exit application
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle))
		goto COMPLETED;
	//output
	/*cout << "\n";
	cout << "Executing T-SQL query...";
	cout << "\n";*/
	//where CallerId = ? AND ExtensionNo=?
	ret = SQLPrepare(sqlStmtHandle, (SQLTCHAR*)_T("{call sp_UpdateCallToDelivered(?,?,?)}"), SQL_NTS);
	if (!SQL_SUCCEEDED(ret)) {
		UpdateLog << "Could not create prepared statement\n";
		SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
		exit(EXIT_FAILURE);
	}
	else {
		//printf("Created prepared statement.\n");
	}

	SQLLEN custIDLen = 0;
	SQLLEN extensionLen = 0;
	SQLLEN strFieldLen = SQL_NTS;
	// Bind the data arrays to the parameters in the prepared SQL 
	// statement
	ret = SQLBindParameter(sqlStmtHandle, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER,
		0, 0, &callerId, 0, &custIDLen);

	ret = SQLBindParameter(sqlStmtHandle, 2, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		20, 0, (SQLPOINTER)extensionNo, 0, &strFieldLen);

	ret = SQLBindParameter(sqlStmtHandle, 3, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		20, 0, (SQLPOINTER)custMobile, 0, &strFieldLen);

	UpdateLog << extensionNo;
	UpdateLog << custMobile;
	// Execute the prepared statement.
	//printf("Running prepared statement...");
	ret = SQLExecute(sqlStmtHandle);
	if (!SQL_SUCCEEDED(ret)) {
		UpdateLog << "not successful!\n";
		goto COMPLETED;
	}
	else {
		UpdateLog << "successful.\n";
		goto COMPLETED;
	}

	//close connection and free resources
COMPLETED:
	SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
	SQLDisconnect(sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
	//pause the console window - exit when key is pressed
}

void UpdateRecord(SQLINTEGER callerId, SQLCHAR extensionNo[20])
{
	ofstream UpdateLog;
	UpdateLog.open("E:\\ISMS\\UpdateLog.txt");
	UpdateLog << "Call Cleared";
	SQLRETURN ret;
#define SQL_RESULT_LEN 240
#define SQL_RETURN_CODE_LEN 1000
	//define handles and variables
	SQLHANDLE sqlConnHandle;
	SQLHANDLE sqlStmtHandle;
	SQLHANDLE sqlEnvHandle;
	SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];
	//initializations
	sqlConnHandle = NULL;
	sqlStmtHandle = NULL;
	//allocations
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle))
		goto COMPLETED;
	//output

	/*cout << "Attempting connection to SQL Server...";
	cout << "\n";*/
	//connect to SQL Server  
	//I am using a trusted connection and port 14808
	//it does not matter if you are using default or named instance
	//just make sure you define the server name and the port
	//You have the option to use a username/password instead of a trusted connection
	//but is more secure to use a trusted connection

	switch (SQLDriverConnect(sqlConnHandle,
		NULL,
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=master;UID=username;PWD=password;",
		(SQLWCHAR*)L"Driver={SQL Server};Server=172.18.13.35,52431;UID=PMS;PWD=Pnterglobe100;Database=IndigoDB_DEV;",
		SQL_NTS,
		retconstring,
		1024,
		NULL,
		SQL_DRIVER_NOPROMPT)) {
	case SQL_SUCCESS:
		UpdateLog << "Successfully connected to SQL Server";
		UpdateLog << "\n";
		break;
	case SQL_SUCCESS_WITH_INFO:
		UpdateLog << "Successfully connected to SQL Server";
		UpdateLog << "\n";
		break;
	case SQL_INVALID_HANDLE:
		UpdateLog << "Could not connect to SQL Server";
		UpdateLog << "\n";
		goto COMPLETED;
	case SQL_ERROR:
		UpdateLog << "Could not connect to SQL Server";
		UpdateLog << "\n";
		goto COMPLETED;
	default:
		break;
	}
	//if there is a problem connecting then exit application
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle))
		goto COMPLETED;
	//output
	/*cout << "\n";
	cout << "Executing T-SQL query...";
	cout << "\n";*/
	//where CallerId = ? AND ExtensionNo=?
	ret = SQLPrepare(sqlStmtHandle, (SQLTCHAR*)L"update tbl_AutoDial_Call_Diversion set CallStatus = 'C',CallEndDateTime=GETDATE() where CallerId = ?", SQL_NTS);
	if (!SQL_SUCCEEDED(ret)) {
		UpdateLog << "Could not create prepared statement\n";
		SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
		exit(EXIT_FAILURE);
	}
	else {
		//printf("Created prepared statement.\n");
	}

	SQLLEN custIDLen = 0;
	SQLLEN extensionLen = 0;
	SQLLEN strFieldLen = SQL_NTS;
	// Bind the data arrays to the parameters in the prepared SQL 
	// statement
	ret = SQLBindParameter(sqlStmtHandle, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER,
		0, 0, &callerId, 0, &custIDLen);
	/*ret = SQLBindParameter(sqlStmtHandle, 2, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
	20, 0, (SQLPOINTER)extensionNo, 0, &strFieldLen);*/
	// Execute the prepared statement.
	//printf("Running prepared statement...");
	ret = SQLExecute(sqlStmtHandle);
	UpdateLog << callerId;

	if (!SQL_SUCCEEDED(ret)) {
		UpdateLog << "not successful!\n";
		goto COMPLETED;
	}
	else {
		UpdateLog <<"successful.\n";
		goto COMPLETED;
	}

	//close connection and free resources
COMPLETED:
	SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
	SQLDisconnect(sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
	//pause the console window - exit when key is pressed
}

void UpdateCallToFailed(SQLINTEGER callerId, SQLCHAR extensionNo[20])
{
	ofstream UpdateLog;
	UpdateLog.open("E:\\ISMS\\UpdateLog.txt");
	UpdateLog << "Call Failed";
	SQLRETURN ret;
#define SQL_RESULT_LEN 240
#define SQL_RETURN_CODE_LEN 1000
	//define handles and variables
	SQLHANDLE sqlConnHandle;
	SQLHANDLE sqlStmtHandle;
	SQLHANDLE sqlEnvHandle;
	SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];
	//initializations
	sqlConnHandle = NULL;
	sqlStmtHandle = NULL;
	//allocations
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle))
		goto COMPLETED;
	//output

	/*cout << "Attempting connection to SQL Server...";
	cout << "\n";*/
	//connect to SQL Server  
	//I am using a trusted connection and port 14808
	//it does not matter if you are using default or named instance
	//just make sure you define the server name and the port
	//You have the option to use a username/password instead of a trusted connection
	//but is more secure to use a trusted connection

	switch (SQLDriverConnect(sqlConnHandle,
		NULL,
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=master;UID=username;PWD=password;",
		(SQLWCHAR*)L"Driver={SQL Server};Server=172.18.13.35,52431;UID=PMS;PWD=Pnterglobe100;Database=IndigoDB_DEV;",
		SQL_NTS,
		retconstring,
		1024,
		NULL,
		SQL_DRIVER_NOPROMPT)) {
	case SQL_SUCCESS:
		UpdateLog << "Successfully connected to SQL Server";
		UpdateLog << "\n";
		break;
	case SQL_SUCCESS_WITH_INFO:
		UpdateLog << "Successfully connected to SQL Server";
		UpdateLog << "\n";
		break;
	case SQL_INVALID_HANDLE:
		UpdateLog << "Could not connect to SQL Server";
		UpdateLog << "\n";
		goto COMPLETED;
	case SQL_ERROR:
		UpdateLog << "Could not connect to SQL Server";
		UpdateLog << "\n";
		goto COMPLETED;
	default:
		break;
	}
	//if there is a problem connecting then exit application
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle))
		goto COMPLETED;
	//output
	/*cout << "\n";
	cout << "Executing T-SQL query...";
	cout << "\n";*/
	//where CallerId = ? AND ExtensionNo=?
	ret = SQLPrepare(sqlStmtHandle, (SQLTCHAR*)L"update tbl_AutoDial_Call_Diversion set CallStatus = 'F',CallEndDateTime=GETDATE() where CallerId = ?", SQL_NTS);
	if (!SQL_SUCCEEDED(ret)) {
		UpdateLog << "Could not create prepared statement\n";
		SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
		exit(EXIT_FAILURE);
	}
	else {
		//printf("Created prepared statement.\n");
	}

	SQLLEN custIDLen = 0;
	SQLLEN extensionLen = 0;
	SQLLEN strFieldLen = SQL_NTS;
	// Bind the data arrays to the parameters in the prepared SQL 
	// statement
	ret = SQLBindParameter(sqlStmtHandle, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER,
		0, 0, &callerId, 0, &custIDLen);
	/*ret = SQLBindParameter(sqlStmtHandle, 2, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
	20, 0, (SQLPOINTER)extensionNo, 0, &strFieldLen);*/
	// Execute the prepared statement.
	//printf("Running prepared statement...");
	ret = SQLExecute(sqlStmtHandle);
	UpdateLog << callerId;

	if (!SQL_SUCCEEDED(ret)) {
		UpdateLog << "not successful!\n";
		goto COMPLETED;
	}
	else {
		UpdateLog << "successful.\n";
		goto COMPLETED;
	}

	//close connection and free resources
COMPLETED:
	SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
	SQLDisconnect(sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
	//pause the console window - exit when key is pressed
}


void UpdateEstablishedDateTime(SQLINTEGER callerId, SQLCHAR extensionNo[20])
{
	ofstream UpdateLog;
	UpdateLog.open("E:\\ISMS\\UpdateLog.txt");
	UpdateLog << "Established";
	SQLRETURN ret;
#define SQL_RESULT_LEN 240
#define SQL_RETURN_CODE_LEN 1000
	//define handles and variables
	SQLHANDLE sqlConnHandle;
	SQLHANDLE sqlStmtHandle;
	SQLHANDLE sqlEnvHandle;
	SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];
	//initializations
	sqlConnHandle = NULL;
	sqlStmtHandle = NULL;
	//allocations
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle))
		goto COMPLETED;
	//output

	/*cout << "Attempting connection to SQL Server...";
	cout << "\n";*/
	//connect to SQL Server  
	//I am using a trusted connection and port 14808
	//it does not matter if you are using default or named instance
	//just make sure you define the server name and the port
	//You have the option to use a username/password instead of a trusted connection
	//but is more secure to use a trusted connection

	switch (SQLDriverConnect(sqlConnHandle,
		NULL,
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=10.130.120.14,52431;UID=Indigo;PWD=Interglobe001;Database=IndigoPopUp;",
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=master;UID=username;PWD=password;",
		(SQLWCHAR*)L"Driver={SQL Server};Server=172.18.13.35,52431;UID=PMS;PWD=Pnterglobe100;Database=IndigoDB_DEV;",
		SQL_NTS,
		retconstring,
		1024,
		NULL,
		SQL_DRIVER_NOPROMPT)) {
	case SQL_SUCCESS:
		UpdateLog << "Successfully connected to SQL Server";
		UpdateLog << "\n";
		break;
	case SQL_SUCCESS_WITH_INFO:
		UpdateLog << "Successfully connected to SQL Server";
		UpdateLog << "\n";
		break;
	case SQL_INVALID_HANDLE:
		UpdateLog << "Could not connect to SQL Server";
		UpdateLog << "\n";
		goto COMPLETED;
	case SQL_ERROR:
		UpdateLog << "Could not connect to SQL Server";
		UpdateLog << "\n";
		goto COMPLETED;
	default:
		break;
	}
	//if there is a problem connecting then exit application
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle))
		goto COMPLETED;
	//output
	/*cout << "\n";
	cout << "Executing T-SQL query...";
	cout << "\n";*/
	//where CallerId = ? AND ExtensionNo=?
	ret = SQLPrepare(sqlStmtHandle, (SQLTCHAR*)L"update tbl_AutoDial_Call_Diversion set CallStatus='E', CallEstablishedDateTime=GETDATE() where CallerId = ? and ExtensionNo = ?", SQL_NTS);
	if (!SQL_SUCCEEDED(ret)) {
		UpdateLog << "Could not create prepared statement\n";
		SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
		exit(EXIT_FAILURE);
	}
	else {
		//printf("Created prepared statement.\n");
	}

	SQLLEN custIDLen = 0;
	SQLLEN extensionLen = 0;
	SQLLEN strFieldLen = SQL_NTS;
	// Bind the data arrays to the parameters in the prepared SQL 
	// statement
	ret = SQLBindParameter(sqlStmtHandle, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER,
		0, 0, &callerId, 0, &custIDLen);
	ret = SQLBindParameter(sqlStmtHandle, 2, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		20, 0, (SQLPOINTER)extensionNo, 0, &strFieldLen);
	// Execute the prepared statement.
	//printf("Running prepared statement...");
	ret = SQLExecute(sqlStmtHandle);

	UpdateLog << callerId;
	UpdateLog << extensionNo;
	if (!SQL_SUCCEEDED(ret)) {
		UpdateLog << "not successful!\n";
		goto COMPLETED;
	}
	else {
		UpdateLog << "successful.\n";
		goto COMPLETED;
	}

	//close connection and free resources
COMPLETED:
	SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
	SQLDisconnect(sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
	//pause the console window - exit when key is pressed
}

void UpdateMonitorInvokeId(SQLINTEGER invokeId, SQLCHAR agentId[20], SQLCHAR extensionNo[20])
{
	ofstream UpdateLog;
	UpdateLog.open("E:\\ISMS\\UpdateLog.txt");
	UpdateLog << "UpdateMonitorInvokeId";
	SQLRETURN ret;
#define SQL_RESULT_LEN 240
#define SQL_RETURN_CODE_LEN 1000
	//define handles and variables
	SQLHANDLE sqlConnHandle;
	SQLHANDLE sqlStmtHandle;
	SQLHANDLE sqlEnvHandle;
	SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];
	//initializations
	sqlConnHandle = NULL;
	sqlStmtHandle = NULL;
	//allocations
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle))
		goto COMPLETED;
	//output

	/*cout << "Attempting connection to SQL Server...";
	cout << "\n";*/
	//connect to SQL Server  
	//I am using a trusted connection and port 14808
	//it does not matter if you are using default or named instance
	//just make sure you define the server name and the port
	//You have the option to use a username/password instead of a trusted connection
	//but is more secure to use a trusted connection

	switch (SQLDriverConnect(sqlConnHandle,
		NULL,
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=10.130.120.14,52431;UID=Indigo;PWD=Interglobe001;Database=IndigoPopUp;",
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=master;UID=username;PWD=password;",
		(SQLWCHAR*)L"Driver={SQL Server};Server=172.18.13.35,52431;UID=PMS;PWD=Pnterglobe100;Database=IndigoDB_DEV;",
		SQL_NTS,
		retconstring,
		1024,
		NULL,
		SQL_DRIVER_NOPROMPT)) {
	case SQL_SUCCESS:
		UpdateLog << "Successfully connected to SQL Server";
		UpdateLog << "\n";
		break;
	case SQL_SUCCESS_WITH_INFO:
		UpdateLog << "Successfully connected to SQL Server";
		UpdateLog << "\n";
		break;
	case SQL_INVALID_HANDLE:
		UpdateLog << "Could not connect to SQL Server";
		UpdateLog << "\n";
		goto COMPLETED;
	case SQL_ERROR:
		UpdateLog << "Could not connect to SQL Server";
		UpdateLog << "\n";
		goto COMPLETED;
	default:
		break;
	}
	//if there is a problem connecting then exit application
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle))
		goto COMPLETED;
	//output
	/*cout << "\n";
	cout << "Executing T-SQL query...";
	cout << "\n";*/
	//where CallerId = ? AND ExtensionNo=?
	ret = SQLPrepare(sqlStmtHandle, (SQLTCHAR*)_T("{call sp_UpdateAgentMonitorInvokeId(?,?,?)}"), SQL_NTS);
	if (!SQL_SUCCEEDED(ret)) {
		UpdateLog << "Could not create prepared statement\n";
		SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
		exit(EXIT_FAILURE);
	}
	else {
		//printf("Created prepared statement.\n");
	}

	SQLLEN invokeIdLen = 0;
	SQLLEN strFieldLen = SQL_NTS;
	// Bind the data arrays to the parameters in the prepared SQL 
	
	ret = SQLBindParameter(sqlStmtHandle, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER,
		0, 0, &invokeId, 0, &invokeIdLen);
	ret = SQLBindParameter(sqlStmtHandle, 2, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		20, 0, (SQLPOINTER)agentId, 0, &strFieldLen);
	ret = SQLBindParameter(sqlStmtHandle, 3, SQL_PARAM_INPUT, SQL_C_CHAR, SQL_VARCHAR,
		20, 0, (SQLPOINTER)extensionNo, 0, &strFieldLen);

	// Execute the prepared statement.
	//printf("Running prepared statement...");
	ret = SQLExecute(sqlStmtHandle);
	
	if (!SQL_SUCCEEDED(ret)) {
		UpdateLog << "not successful!\n";
		goto COMPLETED;
	}
	else {
		UpdateLog << "successful.\n";
		goto COMPLETED;
	}

	//close connection and free resources
COMPLETED:
	SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
	SQLDisconnect(sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
	//pause the console window - exit when key is pressed
}


void UpdateMonitorCrossRefId(SQLINTEGER invokeId, SQLBIGINT crossRefId)
{
	ofstream UpdateLog;
	UpdateLog.open("E:\\ISMS\\UpdateLog.txt");
	UpdateLog << "UpdateMonitorCrossRefId";
	SQLRETURN ret;
#define SQL_RESULT_LEN 240
#define SQL_RETURN_CODE_LEN 1000
	//define handles and variables
	SQLHANDLE sqlConnHandle;
	SQLHANDLE sqlStmtHandle;
	SQLHANDLE sqlEnvHandle;
	SQLWCHAR retconstring[SQL_RETURN_CODE_LEN];
	//initializations
	sqlConnHandle = NULL;
	sqlStmtHandle = NULL;
	//allocations
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &sqlEnvHandle))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLSetEnvAttr(sqlEnvHandle, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, 0))
		goto COMPLETED;
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_DBC, sqlEnvHandle, &sqlConnHandle))
		goto COMPLETED;
	//output

	/*cout << "Attempting connection to SQL Server...";
	cout << "\n";*/
	//connect to SQL Server  
	//I am using a trusted connection and port 14808
	//it does not matter if you are using default or named instance
	//just make sure you define the server name and the port
	//You have the option to use a username/password instead of a trusted connection
	//but is more secure to use a trusted connection

	switch (SQLDriverConnect(sqlConnHandle,
		NULL,
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=10.130.120.14,52431;UID=Indigo;PWD=Interglobe001;Database=IndigoPopUp;",
		//(SQLWCHAR*)L"DRIVER={SQL Server};SERVER=localhost, 1433;DATABASE=master;UID=username;PWD=password;",
		(SQLWCHAR*)L"Driver={SQL Server};Server=172.18.13.35,52431;UID=PMS;PWD=Pnterglobe100;Database=IndigoDB_DEV;",
		SQL_NTS,
		retconstring,
		1024,
		NULL,
		SQL_DRIVER_NOPROMPT)) {
	case SQL_SUCCESS:
		UpdateLog << "Successfully connected to SQL Server";
		UpdateLog << "\n";
		break;
	case SQL_SUCCESS_WITH_INFO:
		UpdateLog << "Successfully connected to SQL Server";
		UpdateLog << "\n";
		break;
	case SQL_INVALID_HANDLE:
		UpdateLog << "Could not connect to SQL Server";
		UpdateLog << "\n";
		goto COMPLETED;
	case SQL_ERROR:
		UpdateLog << "Could not connect to SQL Server";
		UpdateLog << "\n";
		goto COMPLETED;
	default:
		break;
	}
	//if there is a problem connecting then exit application
	if (SQL_SUCCESS != SQLAllocHandle(SQL_HANDLE_STMT, sqlConnHandle, &sqlStmtHandle))
		goto COMPLETED;
	//output
	/*cout << "\n";
	cout << "Executing T-SQL query...";
	cout << "\n";*/
	//where CallerId = ? AND ExtensionNo=?
	UpdateLog << crossRefId;
	UpdateLog << "\n";
	UpdateLog << invokeId;
	UpdateLog << "\n";
	ret = SQLPrepare(sqlStmtHandle, (SQLTCHAR*)_T("{call sp_UpdateAgentMonitorCrossRefId(?,?)}"), SQL_NTS);
	if (!SQL_SUCCEEDED(ret)) {
		UpdateLog << "Could not create prepared statement\n";
		SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
		exit(EXIT_FAILURE);
	}
	else {
		//printf("Created prepared statement.\n");
	}

	SQLLEN invokeIdLen = 0;
	SQLLEN crossRefIdLen = 0;
	// Bind the data arrays to the parameters in the prepared SQL 
	// statement
	ret = SQLBindParameter(sqlStmtHandle, 1, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER,
		0, 0, &crossRefId, 0, &crossRefIdLen);
	ret = SQLBindParameter(sqlStmtHandle, 2, SQL_PARAM_INPUT, SQL_C_LONG, SQL_INTEGER,
		0, 0, &invokeId, 0, &invokeIdLen);
	// Execute the prepared statement.
	//printf("Running prepared statement...");
	ret = SQLExecute(sqlStmtHandle);

	UpdateLog << invokeId;
	UpdateLog << crossRefId;
	if (!SQL_SUCCEEDED(ret)) {
		UpdateLog << "not successful!\n";
		goto COMPLETED;
	}
	else {
		UpdateLog << "successful.\n";
		goto COMPLETED;
	}

	//close connection and free resources
COMPLETED:
	SQLFreeHandle(SQL_HANDLE_STMT, sqlStmtHandle);
	SQLDisconnect(sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_DBC, sqlConnHandle);
	SQLFreeHandle(SQL_HANDLE_ENV, sqlEnvHandle);
	//pause the console window - exit when key is pressed
}



void __stdcall ESRCallback(unsigned long esrParam)
{
	ACSHandle_t* A = (ACSHandle_t*)esrParam;

	Notify(A);
}

bool OpenACSStream()
{
	ofstream ErrorLog;
	ErrorLog.open("E:\\ISMS\\OpenStream.txt");


	const int SEND_QUEUE_SIZE = 0;
	const int RECEIVE_QUEUE_SIZE = 0;
	const int SEND_EXTRA_BUF_SIZE = 5;
	const int RECEIVE_EXTRA_BUF_SIZE = 5;
	const int MINIMUM_LENGTH = 3;

	// Store the Return code of the method
	RetCode_t nRetCode;
	// To hold the advertised service name
	ServerID_t szServiceName;
	// To hold CTI user login ID
	LoginID_t szLoginID;
	// To hold CTI user password
	Passwd_t szPassword;
	// To hold authentication information
	ACSAuthInfo_t authInfo;
	strcpy_s(szServiceName, "AVAYA#IGTGGN2AVPCM2#CSTA#IGTGGN2AAES2");

	nRetCode = acsQueryAuthInfo((ServerID_t*)szServiceName, &authInfo);
	if (nRetCode != ACSPOSITIVE_ACK)
	{
		ErrorLog << " Error: acsQueryAuthInfo method failed.";
	}

		strcpy_s(szLoginID, "phonon");
		// Default password for this application
		strcpy_s(szPassword, "phonon@123");

	AppName_t szAppName = "DeviceMonitor"; // Can be empty string

	Version_t szApiVersion = "TS1-2";

	InvokeID_t lInvokeID = 0;

	ATTPrivateData_t privateData;

	strcpy_s(privateData.vendor, "VERSION");

	privateData.data[0] = PRIVATE_DATA_ENCODING;

	strcpy_s(g_szPrivateDataVersion, "7");

	if ((attMakeVersionString(g_szPrivateDataVersion,
		&(privateData.data[1]))) > 0)
	{
		privateData.length = (unsigned short)strlen(&privateData.data[1]) + 2;
	}
	else
	{
		// Probably using TSAPI client library from the older version
		//ErrorLog << " PrivateData exit.";
		exit(-1);
	}
	
	bool bIsSuccess = false;
	while (!bIsSuccess)
	{
		
		nRetCode = acsOpenStream(a_pAcsHandle,
			LIB_GEN_ID,	// Library takes the control for generating InvokeID.
			lInvokeID,	// This param is ignored when the 2nd parameter is LIB_GEN_ID
			ST_CSTA,		// requesting CSTA stream type.
			&szServiceName,	// CTI Link name "AVAYA#SWITCH1#CSTA#SERVERNAME1" 
			&szLoginID,	    // CTI user login ID
			&szPassword,	// CTI user password
			&szAppName,	    // name of the application
			ACS_LEVEL1,	    // LIB Version, will be ignored 
			&szApiVersion,	// API Version
			SEND_QUEUE_SIZE,// send queue size using default 0
			SEND_EXTRA_BUF_SIZE, // send extra buf size
			RECEIVE_QUEUE_SIZE, // receive queue size using default 0
			RECEIVE_EXTRA_BUF_SIZE,	// receive extra bufs
			(PrivateData_t *)&privateData // buffer for Private Data
			);

		//ErrorLog << nRetCode;
		ErrorLog << a_pAcsHandle;
		if (nRetCode > 0) // acsOpenStream returned successfully
		{
			// storing invoke ID for future use
			g_nOpenStreamInvokeID = (int)nRetCode;
			bIsSuccess = true; // Stop the loop
			ErrorLog << g_nOpenStreamInvokeID;
		}
		else if (nRetCode < 0) // acsOpenStream failed
		{

			switch (nRetCode)
			{
			case ACSPOSITIVE_ACK:
			{
									// The function is successful
									bIsSuccess = true; // Stop the loop
									break;
			}
			case ACSERR_APIVERDENIED:
			{	
										ErrorLog << " Error: acsOpenStream method failed to"
											" open stream.." << endl;
										ErrorLog << " Error: API Version is incorrect. Trying again." << endl;

										bIsSuccess = false;
										break;
			}
			case ACSERR_BADPARAMETER:
			{
										break;
			}
			default:
			{
					   // Some unhandled error occured
					   const int SLEEP_TIME = 3000;
					   ErrorLog << " Error: acsOpenStream method failed to open stream..";
					   ErrorLog << " Error code: " << nRetCode;
					   Sleep(SLEEP_TIME);
					   return false;
			}
			}
		}
		else // case when nRetCode == 0
		{
			// Not possible as LIB_GEN_ID is used in this example.
		}
	}
	//commneted for testing
	nRetCode = acsSetESR(*a_pAcsHandle, ESRCallback, (unsigned long)a_pAcsHandle,
		FALSE);

	// Verification for the positive response
	if (nRetCode != ACSPOSITIVE_ACK)
	{
		ErrorLog << " ERROR: acsSetESR() method return with an error.";

		if (nRetCode == ACSERR_BADHDL)
		{
			ErrorLog << " ulAcsHandle being used is not a valid handle" << endl;
		}
		else
		{
			ErrorLog << " acsSetESR() failed with unknown error. " << endl;
			ErrorLog << " Error code: " << nRetCode;
		}

	}
	ErrorLog.close();

	return true;
}

string AgentMod(ACSHandle_t* a_pAcsHandle)
{
	string ABCD="0-ABCD";
	ofstream getAgentMode;
	ULONGLONG AGInvokeId = 0;

	getAgentMode.open("E:\\ISMS\\getAgentMode.txt", std::ios_base::app);
	bool isEventRetrived = false;
	const int APP_DEF_DEFAULT_BUFFER_SIZE = 512;
	unsigned short usEventBufSize = APP_DEF_DEFAULT_BUFFER_SIZE;
	CSTAEvent_t *cstaEvent = NULL;
	unsigned short usNumEvents = 1;
	while (!isEventRetrived || (usNumEvents > 0 && usEventBufSize > 0))
	{
		int nError;
		
		ATTPrivateData_t privateData;
		privateData.length = sizeof(privateData.data);
		if (NULL != cstaEvent)
		{
			//NotifyErrorFile << "this is called.";
			free(cstaEvent);
		}
		cstaEvent = (CSTAEvent_t*)malloc((SIZE_T)usEventBufSize);
		RetCode_t nRetCode;
#ifdef BLOCKING_MODE
		{

			nRetCode = acsGetEventBlock(*a_pAcsHandle,
				(void *)cstaEvent,
				&usEventBufSize,
				(PrivateData_t *)&privateData,
				&usNumEvents);
			NotifyErrorFile << "acsGetEventBlock.";
		}
#else
		{
			nRetCode = acsGetEventPoll(*a_pAcsHandle,
				(void *)cstaEvent,
				&usEventBufSize,
				(PrivateData_t *)&privateData,
				&usNumEvents);
			//NotifyErrorFile << "acsGetEventPoll.";
		}
#endif
		if (nRetCode != ACSPOSITIVE_ACK)
		{
			if (nRetCode == ACSERR_BADHDL)
			{
				getAgentMode << " The ACS Handle is invalid" << endl << endl;
			} // end of if 
			else if (nRetCode == ACSERR_UBUFSMALL)
			{
				getAgentMode << " Passed event buffer size is smaller than the size of the"
					" next available event for this ACS Stream." << endl << endl;
				continue;
			}// end of else if	
			else if (nRetCode == ACSERR_NOMESSAGE)
			{
				//getAgentMode << " No events available at this time.";
			}
			else
			{
				getAgentMode << " acsGetEventBlock()/acsGetEventPoll() failed with"
					" unknown error. " << endl;
				getAgentMode << " Error code: " << nRetCode;
				break;
			}
		}// end of if 
		else
		{
			// Setting true as we have successfully retrieved event
			isEventRetrived = true;
			//NotifyErrorFile << "True.";
			// Checking for Confirmation event for the Open Stream request
			switch (cstaEvent->eventHeader.eventClass)
			{
			case ACSCONFIRMATION:
			{
			}
			case CSTACONFIRMATION:
			{
									 switch (cstaEvent->eventHeader.eventType)
									 {
									 case CSTA_QUERY_AGENT_STATE_CONF:
									 {
																		 /*ofstream AgentMode;
																		 AgentMode.open("E:\\ISMS\\AgentMode.txt", std::ios_base::app);*/
																		/* if (g_nAgentStateInvokeID == cstaEvent->event.cstaConfirmation.invokeID)
																		 {*/
																			 SetEvent(g_hAgentStateConfEvent);
																			 getAgentMode << cstaEvent->event.cstaConfirmation.invokeID;
																			 AGInvokeId = cstaEvent->event.cstaConfirmation.invokeID;
																			 //getAgentMode << "AGInvokeId-" << AGInvokeId;
																			 AgentState_t AG;
																			 AG = cstaEvent->event.cstaConfirmation.u.queryAgentState.agentState;
																			 getAgentMode << AG;

																			 ATTEvent_t mm;
																			 ATTWorkMode_t WMode;
																			 ATTTalkState_t TState;
																			 if (attPrivateData(&privateData, &mm) == ACSPOSITIVE_ACK)
																			 {
																				 WMode = mm.u.queryAgentState.workMode;
																				 getAgentMode << WMode;
																				 TState = mm.u.queryAgentState.talkState;
																				 getAgentMode << TState;
																			 }
																			 // Add Work Mode in string
																			 if (AG == 0)
																			 {
																				 ABCD = std::to_string(AGInvokeId) + "-NotReady";
																				 
																			 }
																			 else if (AG == 1)
																			 {
																				 ABCD = std::to_string(AGInvokeId) + "-NULL";
																			 }
																			 else if (AG == 2)
																			 {
																				 ABCD = std::to_string(AGInvokeId) + "-Ready";
																			 }
																			 else if (AG == 3)
																			 {
																				 ABCD = std::to_string(AGInvokeId) + "-WorkNotReady";
																			 }
																			 else if (AG == 4)
																			 {
																				 ABCD = std::to_string(AGInvokeId) + "-WorkReady";
																			 }
																			 else
																			 {
																				 ABCD = std::to_string(AGInvokeId) + "-Undefined";
																			 }

																			 // Add Work Mode in string
																			 if (WMode == -1)
																			 {
																				 ABCD = ABCD + "-None";
																			 }
																			 else if (WMode == 1)
																			 {
																				 ABCD = ABCD + "-Aux";
																			 }
																			 else if (WMode == 2)
																			 {
																				 ABCD = ABCD + "-AftCalWork";
																			 }
																			 else if (WMode == 3)
																			 {
																				 ABCD = ABCD + "-AutoIn";
																			 }
																			 else if (WMode == 4)
																			 {
																				 ABCD = ABCD + "-ManualIn";
																			 }
																			 else
																			 {
																				 ABCD = ABCD + "NoWorkMode";
																			 }

																			 // Add Talk Mode in string
																			 if (TState == 0)
																			 {
																				 ABCD = ABCD + "-OnCall";
																			 }
																			 else if (TState == 1)
																			 {
																				 ABCD = ABCD + "-Idle";
																			 }
																			 else
																			 {
																				 ABCD = ABCD + "NoTalkState";
																			 }
										
																		 //}
																		 break;
									 }

									 case CSTA_UNIVERSAL_FAILURE_CONF:
									 {
																		 // Checking for the Failure of Monitor Request
																		 nError =
																			 cstaEvent->event.cstaConfirmation.u.universalFailure.error;
																		 getAgentMode << " CSTA_UNIVERSAL_FAILURE_CONF event received." << endl;
																		 // Verifying error is for monitor start or stop request
																		 /*if (g_nStartMonitorInvokeID ==
																		 cstaEvent->event.cstaConfirmation.invokeID ||
																		 g_nStopMonitorInvokeID ==
																		 cstaEvent->event.cstaConfirmation.invokeID)
																		 {*/
																		 // Checking the cause of the error received 
																		 // for the monitor request
																		 switch (nError)
																		 {
																		 case invalidCstaDeviceIdentifier:
																		 {
																											 getAgentMode << "	Error: Invalid Device Identifier." << endl;
																											 break;
																		 }
																		 case resourceBusy:
																		 {
																							  getAgentMode << " Error: Resource is busy." << endl;
																							  break;
																		 }
																		 case genericOperationRejection:
																		 {
																										   getAgentMode << " Error: GENERIC_OPERATION_REJECTION" << endl;
																										   break;
																		 }
																		 default:
																		 {
																					getAgentMode << " Error: CSTA_UNIVERSAL_FAILURE_CONF event "
																						<< " received with unknown error code." << endl;
																					getAgentMode << " Error Code: " << nError;
																		 }
																		 }// end of inner switch

																		 break;
									 }// end of case

									 default:
									 {
												// Other application should add more cases as per need. 
												getAgentMode << " CSTA Confirmation event received"
													<< " with unknown event type." << endl;
												getAgentMode << " Event Type: " << cstaEvent->eventHeader.eventType;
									 }
									 }// end of CSTA Confirmation event type switch
									 break;
			}// end of CSTACONFIRMATION case
			case CSTAUNSOLICITED:
			{
			}
			default:
			{
					   getAgentMode << " An event received with unknown event class." << endl;
					   getAgentMode << " Event Class: " << cstaEvent->eventHeader.eventClass;
			}
			}// End of event class switch
		}// end of else
	}// end of while loop
	getAgentMode.close();

	if (NULL != cstaEvent)
	{
		//Free the buffer memory
		free(cstaEvent);
	}
	return ABCD;
} // end of Notify() method

void Notify(ACSHandle_t* a_pAcsHandle)
{
	ofstream NotifyErrorFile;
	// This loop run until user press X or x on console, till that  
	// time we will continue receiving monitor event.


	NotifyErrorFile.open("E:\\ISMS\\NotifyErrorFile.txt", std::ios_base::app);
	NotifyErrorFile.clear();
	NotifyErrorFile << "Notify Called.";
	bool isEventRetrived = false;
	const int APP_DEF_DEFAULT_BUFFER_SIZE = 512;
	unsigned short usEventBufSize = APP_DEF_DEFAULT_BUFFER_SIZE;
	CSTAEvent_t *cstaEvent = NULL;
	unsigned short usNumEvents = 1;
	while (!isEventRetrived || (usNumEvents > 0 && usEventBufSize > 0))
	{
		int nError;
		ATTPrivateData_t privateData;
		privateData.length = sizeof(privateData.data);
		if (NULL != cstaEvent)
		{
			//NotifyErrorFile << "this is called.";
			free(cstaEvent);
		}
		cstaEvent = (CSTAEvent_t*)malloc((SIZE_T)usEventBufSize);
		RetCode_t nRetCode;
#ifdef BLOCKING_MODE
		{
			nRetCode = acsGetEventBlock(*a_pAcsHandle,
				(void *)cstaEvent,
				&usEventBufSize,
				(PrivateData_t *)&privateData,
				&usNumEvents);
			NotifyErrorFile << "acsGetEventBlock.";
		}
#else
		{
			nRetCode = acsGetEventPoll(*a_pAcsHandle,
				(void *)cstaEvent,
				&usEventBufSize,
				(PrivateData_t *)&privateData,
				&usNumEvents);
			//NotifyErrorFile << "acsGetEventPoll.";
		}
#endif
		if (nRetCode != ACSPOSITIVE_ACK)
		{
			if (nRetCode == ACSERR_BADHDL)
			{
				NotifyErrorFile << " The ACS Handle is invalid" << endl << endl;
			} // end of if 
			else if (nRetCode == ACSERR_UBUFSMALL)
			{
				NotifyErrorFile << " Passed event buffer size is smaller than the size of the"
					" next available event for this ACS Stream." << endl << endl;
				continue;
			}// end of else if	
			else if (nRetCode == ACSERR_NOMESSAGE)
			{
				//NotifyErrorFile << " No events available at this time.";
				//continue;
			}
			else
			{
				NotifyErrorFile << " acsGetEventBlock()/acsGetEventPoll() failed with"
					" unknown error. " << endl;
				NotifyErrorFile << " Error code: " << nRetCode;
				break;
			}  
		}// end of if 
		else
		{
			// Setting true as we have successfully retrieved event
			isEventRetrived = true;
			//NotifyErrorFile << "True.";
			// Checking for Confirmation event for the Open Stream request
			switch (cstaEvent->eventHeader.eventClass)
			{
			case ACSCONFIRMATION:
			{
									switch (cstaEvent->eventHeader.eventType)
									{
									case ACS_OPEN_STREAM_CONF:
									{
																 //NotifyErrorFile << cstaEvent->event.acsConfirmation.invokeID;
																 if (g_nOpenStreamInvokeID ==
																	 cstaEvent->event.acsConfirmation.invokeID)
																 {
																	 NotifyErrorFile << " acsOpenStremConfEvent received - Stream"
																		 " opened successfully." << endl;
																	 NotifyErrorFile << "   API Version: " <<
																		 cstaEvent->event.acsConfirmation.u.acsopen.apiVer
																		 << endl;
																	 NotifyErrorFile << "   Library Version: " <<
																		 cstaEvent->event.acsConfirmation.u.acsopen.libVer
																		 << endl << endl;

																	 if (privateData.length <= 0)
																	 {
																		 NotifyErrorFile << " Private Data length is zero"
																			 " in acsOpenStreamConf event. Private data"
																			 " is not sent as a part of this event.";
																		 //NotifyErrorFile.close();
																		// PrintErrorAndExit(a_pAcsHandle);
																	 }

																	 // 2nd Check the vendor String
																	 if (strcmp(privateData.vendor, ECS_VENDOR_STRING) != 0)
																	 {
																		 // hanlde error condtion ( abort the Stream )
																		 // return error
																	 }

																	 // 3rd check the One byte descriminator
																	 if (privateData.data[0] != PRIVATE_DATA_ENCODING)
																	 {
																		 // handle error condtion ( abort the Stream )
																		 // return error
																	 }
																	 else
																	 {
																		 // Retrieving the Private Data 
																		 NotifyErrorFile << " PrivateData = VENDOR: " <<
																			 privateData.vendor << endl;

																		 // Checking private data version, whether
																		 // it is same as requested or not.
																		 char cPDVReturned = privateData.data[1];

																		 // To hold returned PDV as number
																		 int nReturnedPDV = atoi(&cPDVReturned);

																		 if (strchr(g_szPrivateDataVersion, '-') == NULL)
																		 {
																			 // Requested version is specific i.e. does not contain '-'
																			 int nRequestedPDV = atoi(g_szPrivateDataVersion);

																			 if (nRequestedPDV == nReturnedPDV)
																			 {
																				 NotifyErrorFile << " Private data version negotiation is " 																	"successful.";
																				 NotifyErrorFile << " Negotiated private data version is: "
																					 << cPDVReturned << endl;
																			 }
																			 else
																			 {
																				 NotifyErrorFile << " Private data version negotiation is failed.";
																				 // This is an error condition where AE Server does
																				 // not support the PDV requested.
																			 }
																		 }
																		 else
																		 {
																			 char* szFirst = _strdup(g_szPrivateDataVersion);
																			 // To store second part of requested PDV
																			 char* szSecond;
																			 strtok_s(szFirst, "-", &szSecond);

																			 int nMinVersion = atoi(szFirst);
																			 int nMaxVersion = atoi(szSecond);

																			 if (nReturnedPDV >= nMinVersion
																				 &&
																				 nReturnedPDV <= nMaxVersion
																				 )
																			 {
																				 NotifyErrorFile << " Private data version negotiation is " 																	"successful.";
																				 NotifyErrorFile << " Negotiated private data version is: "
																					 << cPDVReturned << endl;
																			 }
																			 else
																			 {
																				 NotifyErrorFile << " Private data version negotiation is failed.";
																			 }
																		 }
																	 }
																	 // Sets event object to signaled state.
																	 SetEvent(g_hOpenStreamConfEvent);
																 }
																 else
																 {
																	 NotifyErrorFile << " A confirmation event received for an unknown open"
																		 " stream request.";
																 }
																 break;
									}
									case ACS_CLOSE_STREAM_CONF:
									{
																 /* if (g_nCloseStreamInvokeID ==
																	  cstaEvent->event.acsConfirmation.invokeID)
																  {
																	  SetEvent(g_hCloseStreamConfEvent);
																  }
																  else
																  {
																	  NotifyErrorFile << " A confirmation event received for an unknown close"
																		  " stream request.";
																  }
*/
																  break;
									}
									case ACS_UNIVERSAL_FAILURE_CONF:
									{
																	   // Checking for the Failure of Open Stream request
																	   nError = cstaEvent->event.acsConfirmation.u.failureEvent.error;
																	   NotifyErrorFile << " ACS_UNIVERSAL_FAILURE_CONF event received" << endl; 
																	   if (g_nOpenStreamInvokeID ==
																		   cstaEvent->event.acsConfirmation.invokeID)
																	   {
																		   // Checking for the password of the loginID
																		   switch (nError)
																		   {
																		   case tserverBadPasswordOrLogin:
																		   {
																											 NotifyErrorFile << " CTI login password is incorrect" << endl;
																											 break;
																		   }
																		   case tserverNoUserRecord:
																		   {
																									   NotifyErrorFile << " No user object was found in the security"
																										   " database for the login specified in the"
																										   " ACSOpenStream request." << endl;
																									   break;
																		   }
																		   default:
																		   {
																					  NotifyErrorFile << " ACS_UNIVERSAL_FAILURE_CONF event received"
																						  " with unknown error";
																					  NotifyErrorFile << " Error Code: " << nError;
																		   }
																		   }
																	   }
																	   
																	   else
																	   {
																		   NotifyErrorFile << " An ACS_UNIVERSAL_FAILURE_CONF event received"
																			   " for an unknown request." << endl;
																		   NotifyErrorFile << " Error Code: " << nError;
																	   }
																	   break;
									}
									default:
									{
											   // Other application should add more cases as per need. 
											   NotifyErrorFile << " ACS Confirmation event received"
												   << " with unknown event type." << endl;
											   NotifyErrorFile << " Event Type: " << cstaEvent->eventHeader.eventType;
									}
									} // End of switch
									break;
			} // End of ACSCONFIRMATION case
			case CSTACONFIRMATION:
						{
									switch (cstaEvent->eventHeader.eventType)
									{
										//NotifyErrorFile << cstaEvent->eventHeader.eventType;

									case CSTA_QUERY_AGENT_STATE_CONF:
									{
															ofstream AgentMode;
															AgentMode.open("E:\\ISMS\\AgentMode.txt", std::ios_base::app);
															SetEvent(g_hAgentStateConfEvent);
															AgentMode << cstaEvent->event.cstaConfirmation.invokeID;
															AgentState_t AG;
															AG = cstaEvent->event.cstaConfirmation.u.queryAgentState.agentState;
															AgentMode << AG;
															
															ATTEvent_t mm;
															if (attPrivateData(&privateData, &mm) == ACSPOSITIVE_ACK)
															{
																
																ATTWorkMode_t DD = mm.u.queryAgentState.workMode;
																AgentMode << DD;
																ATTTalkState_t TT = mm.u.queryAgentState.talkState;
																AgentMode << TT;
																AgentMode << mm.u.queryDeviceName.device;
																

																/*if (AG == 0 && DD == 1 && TT == 1)
																{
																	MakeCall(a_pAcsHandle,"909871194303");
																}*/
															}
															
															break;
									}
									case CSTA_MONITOR_CONF:
									{
														// Matching the invokeID received in this event with invokeId
														//// received from invoked cstaMonitorDevice method.
														//if (g_nStartMonitorInvokeID ==
														//	cstaEvent->event.cstaConfirmation.invokeID)
														//{
														//	// Sets event object to signaled state.

															SetEvent(g_hMonitorDeviceConfEvent);

															g_lMonitorCrossRefID =
																cstaEvent->event.cstaConfirmation.u.
																monitorStart.monitorCrossRefID;

															
															UpdateMonitorCrossRefId((SQLINTEGER)g_nStartMonitorInvokeID, (SQLBIGINT)g_lMonitorCrossRefID);

															NotifyErrorFile << " csatMonitorDeviceConfEvent received - "
																" Monitoring started..." << endl << endl;
															NotifyErrorFile << " g_nStartMonitorInvokeID: " << g_nStartMonitorInvokeID;
															NotifyErrorFile << " g_lMonitorCrossRefID: " << g_lMonitorCrossRefID;
														//}
														//else
														//{
														//	// Confirmation event received for some other monitor 
														//	// device request.
														//	NotifyErrorFile << " A confirmation event received for an unknown"
														//		" monitor device request.";
														//}

														break;
								}
							case CSTA_UNIVERSAL_FAILURE_CONF:
							{
																// Checking for the Failure of Monitor Request
																nError =
																	cstaEvent->event.cstaConfirmation.u.universalFailure.error;
																NotifyErrorFile << " CSTA_UNIVERSAL_FAILURE_CONF event received." << endl;
																// Verifying error is for monitor start or stop request
																/*if (g_nStartMonitorInvokeID ==
																	cstaEvent->event.cstaConfirmation.invokeID ||
																	g_nStopMonitorInvokeID ==
																	cstaEvent->event.cstaConfirmation.invokeID)
																{*/
																	// Checking the cause of the error received 
																	// for the monitor request
																	switch (nError)
																	{
																	case invalidCstaDeviceIdentifier:
																	{
																										NotifyErrorFile << "	Error: Invalid Device Identifier." << endl;
																										break;
																	}
																	case resourceBusy:
																	{
																						 NotifyErrorFile << " Error: Resource is busy." << endl;
																						break;
																	}
																	case genericOperationRejection:
																	{
																									  NotifyErrorFile << " Error: GENERIC_OPERATION_REJECTION" << endl;
																									break;
																	}
																	default:
																	{
																			   NotifyErrorFile << " Error: CSTA_UNIVERSAL_FAILURE_CONF event "
																				<< " received with unknown error code." << endl;
																			   NotifyErrorFile << " Error Code: " << nError;
																	}
																	}// end of inner switch
																//}
																/*else
																{
																	NotifyErrorFile << " Error: CSTA_UNIVERSAL_FAILURE_CONF event "
																		<< " received with unknown error code." << endl;
																	NotifyErrorFile << " Error Code: " << nError;
																}*/
																break;
							}// end of case
							case CSTA_MONITOR_STOP_CONF:
							{
														// Matching the invokeID received in this event with invokeId
														// received from invoked cstaMonitorDevice method.
														//if (g_nStopMonitorInvokeID ==
														//	cstaEvent->event.cstaConfirmation.invokeID)
														//{
														//	// Sets event object to signaled state.
															SetEvent(g_hMonitorStopConfEvent);
															NotifyErrorFile << " Monitor deactivated successfully... " << endl;
														//}
														//else
														//{
														//	// Confirmation event received for some other stop monitor 
														//	// device request.
														//	NotifyErrorFile << " A confirmation event received for an unknown"
														//		" stop monitor device request.";
														//}
														break;
							}
							case CSTA_MAKE_CALL_CONF:
							{
														NotifyErrorFile << cstaEvent->event.cstaConfirmation.invokeID;
														if (g_nMakeCallInvokeID == cstaEvent->event.cstaConfirmation.invokeID)
														{
															SetEvent(g_hMakeCllConfEvent);
															NotifyErrorFile << "Make Call successfully..." << endl;
														}
														else
														{
															NotifyErrorFile << "Make call event unsuccessful";
														}
														break;
							}
							default:
							{
									// Other application should add more cases as per need. 
									   NotifyErrorFile << " CSTA Confirmation event received"
										<< " with unknown event type." << endl;
									   NotifyErrorFile << " Event Type: " << cstaEvent->eventHeader.eventType;
							}
							}// end of CSTA Confirmation event type switch
							break;
						}// end of CSTACONFIRMATION case
						case CSTAUNSOLICITED:
						{
												switch (cstaEvent->eventHeader.eventType)
												{
													//NotifyErrorFile << "CSTAUNSOLICITED CALLED.";
													//ATTEvent_t attEvent;
													//NotifyErrorFile << "CSTAUnsolicited : " << cstaEvent->eventHeader.eventType;
												case CSTA_QUERY_AGENT_STATE:
												{
																		NotifyErrorFile << "__AgentReady: " << cstaEvent->event.cstaUnsolicited.u.ready.agentDevice.deviceID;
																		NotifyErrorFile << "__AgentID: " << cstaEvent->event.cstaUnsolicited.u.notReady.agentID;

																		ATTEvent_t eve;
																		ATTWorkMode_t work;
																		
																		if (attPrivateData(&privateData, &eve) == ACSPOSITIVE_ACK)
																		{
																			NotifyErrorFile << "Inside this section";
																			ATTWorkMode_t DD = eve.u.queryAgentState.workMode;
																			NotifyErrorFile << DD;
																		}
																		break;
												}
												case CSTA_SERVICE_INITIATED:
												{
																			   NotifyErrorFile << " A Service Initiated event is received. ";
																			   break;
												}
													
												case CSTA_ORIGINATED:
												{
																	   // Delivered event received

																	   // To store the connection state
																	   ofstream CallDetails;
																	   CallDetails.open("E:\\ISMS\\CallDetails.txt", std::ios_base::app);
																	   LocalConnectionState_t connectionState;

																	   connectionState = cstaEvent->event.cstaUnsolicited.u.delivered.
																		   localConnectionInfo;
																	   CSTAEventCause_t eventCause; // To store the event cause
																	   eventCause = cstaEvent->event.cstaUnsolicited.u.delivered.cause;
																	 
																		   //NotifyErrorFile << " Incoming call detected" << endl;

																		   // Retrieving the information associated with this event
																	   long lcallID = cstaEvent->event.cstaUnsolicited.u.originated.
																			   originatedConnection.callID;
																		   char* szCallingDeviceID = cstaEvent->event.cstaUnsolicited.u.
																			   originated.callingDevice.deviceID;
																		   char* staticDevice = cstaEvent->event.cstaUnsolicited.u.originated.calledDevice.deviceID;
																		   CallDetails << szCallingDeviceID;
																		   CallDetails << staticDevice;

																		   UpdateDeliveredRecord((SQLINTEGER)lcallID, (SQLCHAR*)staticDevice, (SQLCHAR*)szCallingDeviceID);
																		   CallDetails << " An incoming Call with CallID " << lcallID << " received"
																			   << " from " << szCallingDeviceID  << " on " << staticDevice << endl;

																		   // check the privateData length
																		   if (privateData.length > 0)
																		   {
																			   // Event buffer that will contain the decoded private data 
																			   // information.
																			   ATTEvent_t attEvent;

																			   // Check to ensure that private data is successfully decoded.
																			   if (attPrivateData(&privateData, &attEvent) == ACSPOSITIVE_ACK)
																			   {
																				   // check the event type					
																				  /* if (attEvent.eventType == ATT_DELIVERED)
																				   {*/

																					   char* UCID = attEvent.u.deliveredEvent.ucid;
																					   CallDetails << " The UCID is: " << UCID;
																					   char* UEC = attEvent.u.deliveredEvent.userEnteredCode.data;
																					   CallDetails << " UserEnteredCode is : " << UEC;

																				   // } 
																			   } // End of if
																			   else
																			   {
																				   // Decoding Error.
																				   NotifyErrorFile << " An error occured while decoding"
																					   " private data." << endl;
																			   }
																		   }// End of outer if
																		   else
																		   {
																			   // The event does not contain any private Data.
																		   }
																	   //} // End of if
																	   break;
												} // End of Case
												case CSTA_ESTABLISHED:
												{
																		 LocalConnectionState_t connectionState;

																		 connectionState = cstaEvent->event.cstaUnsolicited.u.established.localConnectionInfo;
																		 CSTAEventCause_t eventCause; // To store the event cause
																		 eventCause = cstaEvent->event.cstaUnsolicited.u.established.cause;
																		 // Retrieving the information associated with this event
																		 long lcallID = cstaEvent->event.cstaUnsolicited.u.established.establishedConnection.callID;
																		 char* szCallingDeviceID = cstaEvent->event.cstaUnsolicited.u.established.callingDevice.deviceID;

																		 UpdateEstablishedDateTime((SQLINTEGER)lcallID, (SQLCHAR*)szCallingDeviceID);

																		 // Extract information included in this event here
																		 NotifyErrorFile << " A Established event is received. " << endl;
																		 break;
												} // End of Case
												case CSTA_CONNECTION_CLEARED:
												{
																		  LocalConnectionState_t connectionState;

																		  connectionState = cstaEvent->event.cstaUnsolicited.u.connectionCleared.localConnectionInfo;
																		  CSTAEventCause_t eventCause; // To store the event cause
																		  eventCause = cstaEvent->event.cstaUnsolicited.u.callCleared.cause;
																		  // Retrieving the information associated with this event
																		  long lcallID = cstaEvent->event.cstaUnsolicited.u.callCleared.clearedCall.callID;
																		  char* szCallingDeviceID = cstaEvent->event.cstaUnsolicited.u.callCleared.clearedCall.deviceID;
																		  if (connectionState == csNull)
																		  {
																			  UpdateRecord((SQLINTEGER)lcallID, (SQLCHAR*)szCallingDeviceID);
																		  }
																		  

																		  NotifyErrorFile << endl << " A Connection cleared event is recived for- " << " Connection State " << connectionState << " call Id " << lcallID << endl;
																		  break;
												}
												case CSTA_FAILED:
												{
													LocalConnectionState_t connectionState;

													connectionState = cstaEvent->event.cstaUnsolicited.u.failed.localConnectionInfo;
													CSTAEventCause_t eventCause; // To store the event cause
													eventCause = cstaEvent->event.cstaUnsolicited.u.failed.cause;
													// Retrieving the information associated with this event
													long lcallID = cstaEvent->event.cstaUnsolicited.u.failed.failedConnection.callID;
													char* szCallingDeviceID = cstaEvent->event.cstaUnsolicited.u.failed.failingDevice.deviceID;

													UpdateCallToFailed((SQLINTEGER)lcallID, (SQLCHAR*)szCallingDeviceID);

													cout << endl << " A Connection Failed event is recived for- " << lcallID << endl;
													break;
												}
												default:
												{
														   // Other application should add more cases as per need. 
														   NotifyErrorFile << " An event of type CSTAUNSOLICITED is received with"
															   " unknown event class." << endl;
														   NotifyErrorFile << " Event Type: " << cstaEvent->eventHeader.eventType;
												}
												} // End of switch
												break;
						}// end of CSTAUNSOLICITED case
			default:
			{
					   NotifyErrorFile << " An event received with unknown event class." << endl;
					   NotifyErrorFile << " Event Class: " << cstaEvent->eventHeader.eventClass;
			}
			}// End of event class switch
		}// end of else
	}// end of while loop
	NotifyErrorFile.close();
	if (NULL != cstaEvent)
	{
		//Free the buffer memory
		free(cstaEvent);
	}
} // end of Notify() method

void PrintErrorAndExit(ACSHandle_t* a_pAcsHandle)
{
// Abort the opened stream
	ofstream PrintExit;
	PrintExit.open("E:\\ISMS\\PrintExit.txt", std::ios_base::app);
	PrintExit << "Print and Exit called.";
	AbortStream(a_pAcsHandle);

	exit(-1);
}

bool CloseStream(ACSHandle_t* a_pAcsHandle)
{
	ofstream clStrFile;
	clStrFile.open("E:\\ISMS\\CloseStream.txt");


	RetCode_t nRetCode = acsCloseStream(*a_pAcsHandle, 0, NULL);
	clStrFile << nRetCode;
	// Checking for the negative response
	if (nRetCode < 0)
	{
		// Vrifying for the ACS handle
		if (nRetCode == ACSERR_BADHDL)
		{
			return false;
		}
		else
		{
			clStrFile << " acsCloseStream() failed with unknown error. " << endl;
			clStrFile << " Error code: " << nRetCode;
		}
	}
	else
	{
		clStrFile << " ACS Stream close request sent successfully... " << endl;
		//g_nCloseStreamInvokeID = nRetCode;
	}
	clStrFile.close();
	return true;
}

bool AbortStream(ACSHandle_t* a_pAcsHandle)
{
	ofstream AbrtFile;
	AbrtFile.open("E:\\ISMS\\AbortStream.txt");

	RetCode_t nRetCode = acsAbortStream(*a_pAcsHandle, NULL);

	// Checking for the negative response
	if (nRetCode<0)
	{
		if (nRetCode == ACSERR_BADHDL)
		{
			AbrtFile << " The ACS Handle is invalid " << endl << endl;
		}
		else
		{
			AbrtFile << " acsAbortStream() failed with unknown error. " << endl;
			AbrtFile << " Error code: " << nRetCode;
		}
	}
	else
	{
		AbrtFile << " ACS Stream aborted successfully... " << endl << endl;
	}
	AbrtFile.close();
}

bool MakeCall(ACSHandle_t* a_pAcsHandle, char callingDevice[64], char calledDevice[64])
{
	ofstream MakeCall;
	MakeCall.open("E:\\ISMS\\MakeCall.txt");
	
	DeviceID_t szDeviceID = "2005";
	strcpy_s(szDeviceID, callingDevice);
	DeviceID_t calDeviceID = "909871194303";
	strcpy_s(calDeviceID, calledDevice);
	// Store the return code of the method
	RetCode_t nRetCode = 0;
	MakeCall << "DEvice Calling: " << calDeviceID << " from " << szDeviceID << endl;;
	CSTAMonitorFilter_t filter;	// Store the Monitor Filter setting	
	// Pass 0 for a specific filter category or pass NULL for the filter parameter.
	// Call filters are supported for station device.
	filter.call = cfQueued; // Settting filter for Call Queued event.
	// The Agent Filter is supported only for ACD Split devices.
	filter.agent = 0; // We are using a extension device in this example
	// The Feature Filter and Maintenance Filter are not supported.
	filter.feature = 0;
	filter.maintenance = 0;
	// A zero Private Filter means that the application wants to receive
	// the private events. If Private Filter is non-zero, private events 
	// will be filtered out.
	filter.privateFilter = 0;

	nRetCode = cstaMakeCall(*a_pAcsHandle, // ACS Stream handle
		0, // Invoke ID is ignored, as it is library generated
		&szDeviceID, // Calling DeviceID 
		&calDeviceID, // Called DeviceID
		NULL // Private data not passed with this request
		);
	
	if (nRetCode < 0)
	{
		MakeCall << " Failed to call device ID: " << calDeviceID << endl;
		MakeCall << " Error code: " << nRetCode;
		
		if (nRetCode == ACSERR_BADHDL)
			return false;
	}
	else
	{
		// cstaMonitorDevice returned successfully
		MakeCall << "Make Call Successful.";
		g_nMakeCallInvokeID = nRetCode;
		MakeCall << g_nMakeCallInvokeID;
	}
	return true;
}

bool ClearCall(ACSHandle_t* a_pAcsHandle, char callingDevice[64])
{
	ofstream ClearCall;
	ClearCall.open("E:\\ISMS\\ClearCall.txt");
	ClearCall << "DEvice Call Clear";
	DeviceID_t szDeviceID = "2005";
	strcpy_s(szDeviceID, callingDevice);
	// Store the return code of the method
	RetCode_t nRetCode = 0;

	CSTAMonitorFilter_t filter;	// Store the Monitor Filter setting	
	// Pass 0 for a specific filter category or pass NULL for the filter parameter.
	// Call filters are supported for station device.
	filter.call = cfQueued; // Settting filter for Call Queued event.
	// The Agent Filter is supported only for ACD Split devices.
	filter.agent = 0; // We are using a extension device in this example
	// The Feature Filter and Maintenance Filter are not supported.
	filter.feature = 0;
	filter.maintenance = 0;
	// A zero Private Filter means that the application wants to receive
	// the private events. If Private Filter is non-zero, private events 
	// will be filtered out.
	filter.privateFilter = 0;

	ConnectionID_t *conns = GetCurrentConnections(callingDevice);

	/*if (conns == NULL || conns.Length == 0)
	{
		MessageBox.Show("No active calls");
		return;
	}*/
	
	nRetCode = cstaClearCall(*a_pAcsHandle, // ACS Stream handle
		0, // Invoke ID is ignored, as it is library generated
		&conns[0],
		NULL // Private data not passed with this request
		);

	if (nRetCode < 0)
	{
		ClearCall << " Failed to call device ID: " << callingDevice << endl;
		ClearCall << " Error code: " << nRetCode;

		if (nRetCode == ACSERR_BADHDL)
			return false;
	}
	else
	{
		// cstaMonitorDevice returned successfully
		ClearCall << "Clear Call Successful.";
		ClearCall << g_nMakeCallInvokeID;

	}
	return true;
}

bool HoldCall(ACSHandle_t* a_pAcsHandle, char callingDevice[64])
{
	ofstream HoldCall;
	HoldCall.open("E:\\ISMS\\HoldCall.txt");
	HoldCall << "DEvice on Hold";
	DeviceID_t szDeviceID = "2005";
	strcpy_s(szDeviceID, callingDevice);
	// Store the return code of the method
	RetCode_t nRetCode = 0;

	CSTAMonitorFilter_t filter;	// Store the Monitor Filter setting	
	// Pass 0 for a specific filter category or pass NULL for the filter parameter.
	// Call filters are supported for station device.
	filter.call = cfQueued; // Settting filter for Call Queued event.
	// The Agent Filter is supported only for ACD Split devices.
	filter.agent = 0; // We are using a extension device in this example
	// The Feature Filter and Maintenance Filter are not supported.
	filter.feature = 0;
	filter.maintenance = 0;
	// A zero Private Filter means that the application wants to receive
	// the private events. If Private Filter is non-zero, private events 
	// will be filtered out.
	filter.privateFilter = 0;

	ConnectionID_t *conns = GetCurrentConnections(callingDevice);

	/*if (conns == NULL || conns.Length == 0)
	{
	MessageBox.Show("No active calls");
	return;
	}*/

	nRetCode = cstaHoldCall(*a_pAcsHandle, // ACS Stream handle
		0, // Invoke ID is ignored, as it is library generated
		&conns[0],
		false,
		NULL // Private data not passed with this request
		);

	if (nRetCode < 0)
	{
		HoldCall << " Failed to hold call device ID: " << callingDevice << endl;
		HoldCall << " Error code: " << nRetCode;

		if (nRetCode == ACSERR_BADHDL)
			return false;
	}
	else
	{
		// cstaMonitorDevice returned successfully
		HoldCall << "Make Call Successful.";

	}

	return true;
}

//Monitoring Device/////////////////////////////////////////////
bool MonitorDevice(ACSHandle_t* a_pAcsHandle, char AgentId[64], char Dev[64])
{
	ofstream mDevice;
	mDevice.open("E:\\ISMS\\MonitorDevice.txt", std::ios_base::app);
	mDevice << "Device Monitoring Started.";
	// Set the DeviceID of the Deivce to be monitored
	DeviceID_t szDeviceID = "5900"; // Default device ID	
	//string abc = "2005";
	//mDevice << DevID;
	//abc = DevID;

	//char A[64];
	//strcpy_s(A, abc.c_str());

	//char A[64] = "2005";
	//szDeviceID = DevID;
	strcpy_s(szDeviceID, Dev);

	//mDevice << szDeviceID;
	// Store the return code of the method
	RetCode_t nRetCode = 0;
	RetCode_t sRetCode = 0;

	CSTAMonitorFilter_t filter;	// Store the Monitor Filter setting	

	// Pass 0 for a specific filter category or pass NULL for the filter parameter.

	// Call filters are supported for station device.
	filter.call = cfQueued; // Settting filter for Call Queued event.

	// The Agent Filter is supported only for ACD Split devices.
	filter.agent = 0; // We are using a extension device in this example

	// The Feature Filter and Maintenance Filter are not supported.
	filter.feature = 0;
	filter.maintenance = 0;

	filter.privateFilter = 0;

	nRetCode = cstaMonitorDevice(*a_pAcsHandle, // ACS Stream handle
		0, // Invoke ID is ignored, as it is library generated
		&szDeviceID, // ID of the device to be monitored
		&filter, // Filter setting that will apply on monitor
		NULL // Private data not passed with this request
		);

	if (nRetCode < 0)
	{
		mDevice << "_Failed to monitor device ID: " << szDeviceID << endl;
		mDevice << "_Error code: " << nRetCode;
		
		if (nRetCode == ACSERR_BADHDL)
			return false;
		//PrintErrorAndExit(a_pAcsHandle);


	}
	else
	{
		// cstaMonitorDevice returned successfully
		mDevice << "_Device Monitoring done successfully";
		g_nStartMonitorInvokeID = nRetCode;

		UpdateMonitorInvokeId((SQLINTEGER)g_nStartMonitorInvokeID, (SQLCHAR*)AgentId, (SQLCHAR*)Dev);

	}
	return true;
}

bool SetAgentState(ACSHandle_t* a_pAcsHandle, char AgentId[64], char Dev[64], AgentMode_t agentMode, ATTWorkMode_t workMode)
{
	string DevInvkID;
	ofstream AgentStatus;
	AgentStatus.open("E:\\ISMS\\AgentStatus.txt", std::ios_base::app);
	ofstream Agent;
	Agent.open("E:\\ISMS\\AgentMode.txt", std::ios_base::app);

	DeviceID_t DeviceID = "2005";
	strcpy_s(DeviceID, Dev);
	AgentID_t agentID = "12047";
	strcpy_s(agentID, AgentId);
	RetCode_t nRetCode = 0;

	AgentGroup_t agentGroup = "2000"; /* ACD split to log Agent into */
	
	AgentPassword_t *agentPassword = NULL; /* No password */
	RetCode_t rc; /* Return code for service
				  * requests */
	CSTAEvent_t cstaEvent; /* CSTA event buffer */
	unsigned short eventBufSize; /* CSTA event buffer size */
	unsigned short numEvents; /* Number of events queued */
	ATTPrivateData_t privateData; /* ATT service request private
								  * data buffer */
	ATTEvent_t attEvent; /* Private data event structure */

	rc = attV6SetAgentState(&privateData, workMode, 0, TRUE);
	if (rc < 0)
	{
		AgentStatus << "Agent attV6SetAgentState method failed";
		AgentStatus << nRetCode;
		return false;
		/* Some kind of failure, handle error here. */
	}

	nRetCode = cstaSetAgentState(*a_pAcsHandle, 0, &DeviceID, agentMode, &agentID, &agentGroup, (AgentPassword_t *)&agentPassword, (PrivateData_t *)&privateData);
	
	if (rc != ACSPOSITIVE_ACK)
	{
		AgentStatus << "Agent cstaSetAgentState method failed";
		AgentStatus << nRetCode;
		return false;
	}
	/* cstaSetAgentState() succeeded. Wait for the confirmation event. */
	/* Initialize buffer sizes before calling acsGetEventBlock() */
	eventBufSize = sizeof(cstaEvent);
	privateData.length = ATT_MAX_PRIVATE_DATA;
	rc = acsGetEventBlock(*a_pAcsHandle, (void *)&cstaEvent, &eventBufSize, (PrivateData_t *)&privateData, &numEvents);

	if (rc != ACSPOSITIVE_ACK)
	{
		AgentStatus << "Agent acsGetEventBlock method failed";
		AgentStatus << nRetCode;
		return false;
	}
	/* Is this the event that we are waiting for? */
	if ((cstaEvent.eventHeader.eventClass == CSTACONFIRMATION) &&
		(cstaEvent.eventHeader.eventType == CSTA_SET_AGENT_STATE_CONF))
	{
		if (cstaEvent.event.cstaConfirmation.invokeID == 1)
		{
			/* Invoke ID matches, cstaSetAgentState() is confirmed. */
			/* See if the confirmation event includes private data. */
			if (privateData.length > 0)
			{
				return true;
				/*
				* The confirmation event contains private data.
				* Decode it.
				*/
				if (attPrivateData(&privateData, &attEvent) !=
					ACSPOSITIVE_ACK)
				{
					/* Handle decoding error here. */
				}
				
			}
		}
	}
	return false;

}

bool AgentState(ACSHandle_t* a_pAcsHandle, char Dev[64])
{
	string DevInvkID;
	ofstream AgentStatus;
	AgentStatus.open("E:\\ISMS\\AgentStatus.txt", std::ios_base::app);
	ofstream Agent;
	Agent.open("E:\\ISMS\\AgentMode.txt", std::ios_base::app);

	DeviceID_t DeviceID = "2005";
	strcpy_s(DeviceID, Dev);
	RetCode_t nRetCode = 0;

	nRetCode = cstaQueryAgentState(*a_pAcsHandle, 0, &DeviceID, 0);
	if (nRetCode < 0)
	{
		AgentStatus << "Agent Status method failed";
		AgentStatus << nRetCode;
		return false;
	}
	else
	{
		AgentStatus << "Agent status successful";
		g_nAgentStateInvokeID = nRetCode;
		Agent << Dev << nRetCode;
		Agent << g_nAgentStateInvokeID;
		DevInvkID = AgentMod(a_pAcsHandle);


		int A = DevInvkID.find('-');
		string B = DevInvkID.substr(0, A);

		int C = 0;
		C = atoi(B.c_str());
		Agent << C;
		while (C != g_nAgentStateInvokeID)
		{
			
			DevInvkID = "";
			DevInvkID = AgentMod(a_pAcsHandle);
			break;
		}

		Agent << DevInvkID;
		int lstr = DevInvkID.find('-');
		string Status = DevInvkID.substr(lstr+1, 17);
		if (Status == "NotReady-Aux-Idle")
		{
			
			AgentStatus << Status;
			return true;			
		}
		else if (Status == "Ready-AutoIn-Idle")
		{
			AgentStatus << Status;
			return true;
		}
		else
		{
			
			AgentStatus << Status;
			return false;			
		}
		//string Status = std::to_string(g_nAgentStateInvokeID) + "-NotReady-"
		//return true;
	}
}
/// Monitoring Stop Meethod
bool StopMonitor(ACSHandle_t* a_pAcsHandle, long RefId)
{
	ofstream clsDevice;
	clsDevice.open("E:\\ISMS\\CloseMonitoring.txt", std::ios_base::app);
	clsDevice << "Device monitoring Stopped.";

	CSTAMonitorCrossRefID_t RID = 0;
	
	//strcpy_s(RID, RefId);

	RetCode_t nRetCode;
	if (g_lMonitorCrossRefID == RefId)
	{
		clsDevice << "RefId working";
		nRetCode = cstaMonitorStop(*a_pAcsHandle,
			0,
			RefId,
			0);
	}
	else
	{
		clsDevice << "RefId didnt worked";
		nRetCode = cstaMonitorStop(*a_pAcsHandle,0,g_lMonitorCrossRefID,0);
	}

	// Checking for the negative response	
	if (nRetCode < 0)
	{
		clsDevice << "_Failed to stop monitor" << endl;
		clsDevice << "_Error Code :" << nRetCode;

		if (nRetCode == ACSERR_BADHDL)
			return false;

		//PrintErrorAndExit(a_pAcsHandle);
		
	}
	else
	{
		// Request is successful.	
		clsDevice << "_Monitoring Stopped successfully.";
		g_nStopMonitorInvokeID = nRetCode;
	}

	return true;

}

ConnectionID_t* GetCurrentConnections(char callingDevice[64])
{
	DeviceID_t szDeviceID = "2005";
	strcpy_s(szDeviceID, callingDevice);
	RetCode_t retCode = cstaSnapshotDeviceReq(*a_pAcsHandle,
		0,
		&szDeviceID,
		NULL);

	if (retCode < 0)
	{
		return NULL;
	}
	bool isEventRetrived = false;
	const int APP_DEF_DEFAULT_BUFFER_SIZE = 512;
	unsigned short usEventBufSize = APP_DEF_DEFAULT_BUFFER_SIZE;
	CSTAEvent_t *cstaEvent = NULL;
	unsigned short usNumEvents = 1;
	while (!isEventRetrived || (usNumEvents > 0 && usEventBufSize > 0))
	{
		int nError;
		ATTPrivateData_t privateData;
		privateData.length = sizeof(privateData.data);
		if (NULL != cstaEvent)
		{
			//NotifyErrorFile << "this is called.";
			free(cstaEvent);
		}
		cstaEvent = (CSTAEvent_t*)malloc((SIZE_T)usEventBufSize);
		RetCode_t retCode;
		retCode = acsGetEventBlock(*a_pAcsHandle,
			(void *)cstaEvent,
			&usEventBufSize,
			(PrivateData_t *)&privateData,
			&usNumEvents);

		if (retCode != ACSPOSITIVE_ACK)
		{
			return NULL;
		}

		
		if (cstaEvent->eventHeader.eventClass != CSTACONFIRMATION || cstaEvent-> eventHeader.eventType != CSTA_SNAPSHOT_DEVICE_CONF)
		{
			if (cstaEvent->eventHeader.eventClass == CSTACONFIRMATION && cstaEvent->eventHeader.eventType == CSTA_UNIVERSAL_FAILURE_CONF)
			{
				
			}
			return NULL;
		}

		int callCount = cstaEvent->event.cstaConfirmation.u.snapshotDevice.snapshotData.count;
		ConnectionID_t *conns = new ConnectionID_t[callCount];
		for (int i = 0; i < callCount; i++)
		{
			CSTASnapshotDeviceResponseInfo_t *info = (CSTASnapshotDeviceResponseInfo_t*)cstaEvent->event.cstaConfirmation.u.snapshotDevice.snapshotData.info;
			conns[i] = info[i].callIdentifier;
		}
		return conns;
	}
	
}

