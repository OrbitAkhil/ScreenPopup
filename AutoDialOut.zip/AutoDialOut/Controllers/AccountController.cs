﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security;
using AutoDialOut.Models;
using AutoDialOut.Repository;
using AutoDialOut.App_Classes;
using Tsapi;
using System.Configuration;
using System.Runtime.InteropServices;
using NLog;

namespace AutoDialOut.Controllers
{

   
    [Authorize]
    [ErrorHandle]
    public class AccountController : ApplicationController<LoggedInAgentViewModel>
    {
        private static NLog.Logger logger = LogManager.GetLogger("databaseLogger");
        [DllImport("TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool MonitorStart(string AgentId,string DEvId);
        [DllImport("TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool MonitorStop(long RefId);
        [DllImport("TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool SetAgentState(string agentId, string deviceId, Tsapi.Csta.AgentMode_t agentMode, Tsapi.Att.ATTWorkMode_t workMode);
        [DllImport("TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool OpenConnection();
        [DllImport("TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern bool CloseConnection();

        public AccountController()
            : this(new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(new ApplicationDbContext())))
        {
        }

        public AccountController(UserManager<ApplicationUser> userManager)
        {
            UserManager = userManager;
        }

        public UserManager<ApplicationUser> UserManager { get; private set; }

        //
        // GET: /Account/Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            this.AbandonSession();
            ViewBag.ReturnUrl = returnUrl;
            return View(new LoginViewModel() { ShowLogoutPopup = "false" });
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                if(Simulator.Instance.CheckAgentLoggedIn(model.AgentId.ToString()))
                {
                    AgentRepository agentRepository = new AgentRepository();
                    ExtensionRepository extensionRepository = new ExtensionRepository();
                    LoginRepository loginRepository = new LoginRepository();
                     
                
                    var agent =  agentRepository.Find(Convert.ToInt32(model.AgentId), model.Password);
                    var extension = extensionRepository.Find(Convert.ToInt32(model.ExtensionNo));

                    if(agent == null)
                    {
                        agentRepository.AddAgent(Convert.ToInt32(model.AgentId),model.Password);                
                    }

                    if(extension == null)
                    {
                        extensionRepository.AddExtension(Convert.ToInt32(model.ExtensionNo));    
                    }

                
                    if (!loginRepository.CheckExtensionAvailability(Convert.ToInt32(model.AgentId), Convert.ToInt32(model.ExtensionNo)))
                    {
                        TelephonyRepository telephonyRepository = new TelephonyRepository();
                        telephonyRepository.UpdateAgentUnprocessedCalls(Convert.ToInt32(model.AgentId), Convert.ToInt32(model.ExtensionNo));

                        string unqiueIdentifier = Guid.NewGuid().ToString();
                        loginRepository.AddLoginRecord(Convert.ToInt32(model.AgentId), Convert.ToInt32(model.ExtensionNo),model.AgentLoggedInType, unqiueIdentifier);
                       Simulator.Instance.SetAgentState(model.AgentId.ToString(), model.ExtensionNo.ToString(), Csta.AgentMode_t.AM_LOG_IN, Att.ATTWorkMode_t.WM_NONE);
                        if (!MonitorStart(model.AgentId.ToString(), model.ExtensionNo.ToString()))
                        {
                            logger.Info("Re-Open stream from check session in account controller");
                            Simulator.Instance.ReOpenStream();
                        }
                        LoggedInAgentViewModel loggedInAgentViewModel = new LoggedInAgentViewModel();
                        loggedInAgentViewModel.AgentId = Convert.ToInt32(model.AgentId);
                        loggedInAgentViewModel.ExtensionNo = Convert.ToInt32(model.ExtensionNo);
                        loggedInAgentViewModel.UniqueIdentifier = unqiueIdentifier;
                        loggedInAgentViewModel.LoginDateTime = DateTime.Now;
                        SetLogOnSessionModel(loggedInAgentViewModel);
                        return RedirectToLocal(returnUrl);
                    }
                    else
                    {
                        model.ShowLogoutPopup = "true";
                        TempData["LoginViewModel"] = model;
                        //ModelState.AddModelError("Error", "Agent is already login by other Extension.");
                    }
                }
                else
                {
                    ModelState.AddModelError("OneXLoggedIn", "Please log-in into Avaya phone.");
                }
            }


            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Account/Register
        [AllowAnonymous]
        public ActionResult Register()
        {
            //LoginRepository loginRepository = new LoginRepository();
            //loginRepository.LogoutAgentExistingSession();
            return View();
        }


        //
        // GET: /Account/Register
        [AllowAnonymous]
        public ActionResult CheckSession()
        {
            LoginRepository loginRepository = new LoginRepository();
            LoginViewModel model = TempData["LoginViewModel"] as LoginViewModel;
            if (model != null)
            {
                AgentRepository agentRepository = new AgentRepository();
                var agent = agentRepository.Find(Convert.ToInt32(model.AgentId), model.Password);
                loginRepository.LogoutAgentExistingSession(Convert.ToInt32(model.AgentId));
                if (agent != null){
                    if (!loginRepository.CheckExtensionAvailability(Convert.ToInt32(model.AgentId), Convert.ToInt32(model.ExtensionNo)))
                    {
                        string unqiueIdentifier = Guid.NewGuid().ToString();
                        loginRepository.AddLoginRecord(Convert.ToInt32(model.AgentId), Convert.ToInt32(model.ExtensionNo),model.AgentLoggedInType, unqiueIdentifier);

                        Simulator.Instance.SetAgentState(model.AgentId.ToString(), model.ExtensionNo.ToString(), Csta.AgentMode_t.AM_LOG_IN, Att.ATTWorkMode_t.WM_NONE);
                        if (!MonitorStart(model.AgentId.ToString(), model.ExtensionNo.ToString()))
                        {
                            logger.Info("Re-Open Stream from Check Session in account controller");
                            Simulator.Instance.ReOpenStream();
                        }

                        LoggedInAgentViewModel loggedInAgentViewModel = new LoggedInAgentViewModel();
                        loggedInAgentViewModel.AgentId = Convert.ToInt32(model.AgentId);
                        loggedInAgentViewModel.ExtensionNo = Convert.ToInt32(model.ExtensionNo);
                        loggedInAgentViewModel.UniqueIdentifier = unqiueIdentifier;
                        loggedInAgentViewModel.AgentName = string.IsNullOrEmpty(agent.AgentName) ? "Hello Agent" : agent.AgentName ;
                        loggedInAgentViewModel.LoginDateTime = DateTime.Now;
                        SetLogOnSessionModel(loggedInAgentViewModel);

                        return RedirectToAction("Index","Home");
                    }
                }
            }
           
            return RedirectToAction("Login");
        }
       
        //
        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AllowAnonymous]
        public ActionResult LogOff()
        {
            var sessionViewModel = GetLogOnSessionModel();
            if (sessionViewModel != null)
            {
                var loginRepo = new LoginRepository();
               Simulator.Instance.SetAgentState(sessionViewModel.AgentId.ToString(), sessionViewModel.ExtensionNo.ToString(), Csta.AgentMode_t.AM_LOG_OUT, Att.ATTWorkMode_t.WM_NONE);
                long monitorCrossRefId = loginRepo.GetAgentMonitorCrossRefId(sessionViewModel.AgentId, sessionViewModel.ExtensionNo);
                MonitorStop(monitorCrossRefId);
                loginRepo.DeActivateLogin(sessionViewModel.AgentId, sessionViewModel.ExtensionNo, sessionViewModel.UniqueIdentifier);
            }
            
            this.AbandonSession();
            //MonitorStop(sessionViewModel.ExtensionNo.ToString());

            return RedirectToAction("Login", "Account");
        }

        [HttpGet]
        [AllowAnonymous]
        public ActionResult CloseStream()
        {
            CloseConnection();
            Simulator.Instance.AbortStream();
            return Content("Closed Connection Successfully");
        }

        [HttpGet]
        [AllowAnonymous]
        public ActionResult OpenStream()
        {
            OpenConnection();
            Simulator.Instance.OpenStream();
            return Content("Open Connection Successfully");
        }

        [HttpGet]
        [AllowAnonymous]
        public ActionResult ReOpenConnection()
        {
            OpenConnection();
            Simulator.Instance.OpenStream();

            //Start Monitoring
            var loggedInUsers =  new LoginRepository().GetActiveAgents();
            foreach (var user in loggedInUsers)
            {
                MonitorStart(user.AgentId.ToString(),user.ExtensionNo.ToString());
            }
            return Content("Open Connection Successfully");
        }
        

        protected override void Dispose(bool disposing)
        {
            if (disposing && UserManager != null)
            {
                UserManager.Dispose();
                UserManager = null;
            }
            base.Dispose(disposing);
        }

        #region Helpers
       
        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        
        #endregion
    }
}