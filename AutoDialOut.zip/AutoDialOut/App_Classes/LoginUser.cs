﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AutoDialOut.App_Classes
{
    public class LoginUser
    {
        public int AgentId { get; set; }
        public int ExtensionNo { get; set; }
        public string Status { get; set; }
    }
}