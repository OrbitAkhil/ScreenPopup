﻿using Microsoft.AspNet.SignalR;
using AutoDialOut.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Web;
using System.Data.Entity;
using NLog;
using Microsoft.AspNet.SignalR.Hubs;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using AutoDialOut;
using AutoDialOut.App_Classes;
using System.Runtime.InteropServices;

namespace AutoDialOut.Hubs
{

    public class TelephonyHub : Hub
    {
        private static NLog.Logger logger = LogManager.GetCurrentClassLogger();
        //[DllImport(@"\\172.18.16.140\Indigo\DropOut Callback\TSAPIApp\Debug\TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        //public static extern void ClearDevice(string callingDevice);
        //[DllImport(@"\\172.18.16.140\Indigo\DropOut Callback\TSAPIApp\Debug\TSAPIApp.dll", CallingConvention = CallingConvention.Cdecl)]
        //public static extern void HoldDevice(string callingDevice);
        private readonly TsapiService _tsapiService;

        public TelephonyHub()
            : this(TsapiService.Instance)
        {
        }

        public TelephonyHub(TsapiService tsapiService)
        {
            _tsapiService = tsapiService;
        }

        public OutgoingCall GetActiveCall(string extensionNo)
        {
            if (string.IsNullOrEmpty(extensionNo))
                return null;
            //Create an instance of the Repository class
            TelephonyRepository objRepository = new TelephonyRepository();
            return objRepository.GetAgentActiveOutgoingCall(Convert.ToInt32(extensionNo));
            
        }

       
        public void ClearCall(string extensionNo)
        {
            Simulator.Instance.ClearCall(extensionNo);
        }

        public void HoldCall(string extensionNo)
        {
            if(!Simulator.Instance.HoldCall(extensionNo))
            {
                Simulator.Instance.ReOpenStream();
            }
        }

        public void AnswerCall(string extensionNo)
        {
            if(!Simulator.Instance.AnswerCall(extensionNo))
            {
                Simulator.Instance.ReOpenStream();
            }
        }

        public void TransferCall(string extensionNo)
        {
           if(!Simulator.Instance.TransferCall(extensionNo))
           {
               Simulator.Instance.ReOpenStream();
           }
        }

        public void DisconnectUser(string agentId, string extensionNo, string uniqueIdentifier)
        {
            LoginRepository objRepository = new LoginRepository();
            objRepository.DeActivateLogin(Convert.ToInt32(agentId), Convert.ToInt32(extensionNo), uniqueIdentifier);

        }


        public override System.Threading.Tasks.Task OnConnected()
        {
            //Create an instance of the Repository class
            TelephonyRepository objRepository = new TelephonyRepository();
            int agentId, extensionNo;
            string uniqueIdentifier;
            Int32.TryParse(this.Context.QueryString["agentId"], out agentId);
            Int32.TryParse(this.Context.QueryString["extensionNo"], out extensionNo);
            uniqueIdentifier = Convert.ToString(this.Context.QueryString["uniqueIdentifier"]);
            new LoginRepository().ReActivateLogin(agentId, extensionNo, uniqueIdentifier);
            
            return base.OnConnected();

        }

        public override Task OnReconnected()
        {
            //_userCount++;
            //Clients.All.online(_userCount);
            return base.OnReconnected();
        }
        public override Task OnDisconnected(bool stopCalled)
        {
            //_userCount--;
            //Clients.All.online(_userCount);

            int agentId, extensionNo;
            string uniqueIdentifier;
            Int32.TryParse(this.Context.QueryString["agentId"], out agentId);
            Int32.TryParse(this.Context.QueryString["extensionNo"], out extensionNo);
            uniqueIdentifier = Convert.ToString(this.Context.QueryString["uniqueIdentifier"]);
            if (agentId > 0)
            {
                new LoginRepository().DeActivateLogin(agentId, extensionNo, uniqueIdentifier);
            }
            return base.OnDisconnected(stopCalled);
        }

    }

    public static class Extensions
    {
        public static string GetDomain(this IIdentity identity)
        {
            string s = identity.Name;
            int stop = s.IndexOf("\\");
            return (stop > -1) ? s.Substring(0, stop) : string.Empty;
        }

        public static int GetLogin(this IIdentity identity)
        {
            string s = identity.Name;
            int stop = s.IndexOf("\\");
            return 0;// (stop > -1) ? s.Substring(stop + 1, s.Length - stop - 1) : string.Empty;
        }
    }
}