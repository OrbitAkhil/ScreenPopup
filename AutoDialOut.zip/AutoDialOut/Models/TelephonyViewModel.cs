﻿using AutoDialOut.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AutoDialOut.Models
{
    public class TelephonyViewModel : ViewModelBase
    {
        public int UnAllocatedCallCount
        {
            get 
            {   
                TelephonyRepository telephonyRepository = new TelephonyRepository();
                return telephonyRepository.GetUnAllocatedCallCount();
            }
        }
    }
}