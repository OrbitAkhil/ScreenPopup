﻿using System.ComponentModel.DataAnnotations;
using System;

namespace AutoDialOut.Models
{
    public class ExternalLoginConfirmationViewModel
    {
        [Required]
        [Display(Name = "User name")]
        public string UserName { get; set; }
    }

    public class ManageUserViewModel
    {
        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Current password")]
        public string OldPassword { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "New password")]
        public string NewPassword { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm new password")]
        [Compare("NewPassword", ErrorMessage = "The new password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }

    public class ViewModelBase
    {
        public int AgentId { get; set; }

        public string AgentName { get; set; }

        public string ExtensionNo { get; set; }

        public string Password { get; set; }

        public string UniqueIdentifier { get; set; } 

        public bool IsAuthenticated()
        {
            if (AgentId > 0)
                return true;
            else
                return false;
        }
    }


    public class LoginViewModel
    {
        public string ShowLogoutPopup { get; set; }
        [Required]
        [Display(Name = "Agent Id")]
        public string AgentId { get; set; }

        [Required]
        [Display(Name = "Extension")]
        public string ExtensionNo { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Display(Name = "Agent Password")]
        public string Password { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Agent Type")]
        public string AgentLoggedInType { get; set; }

        
    }

    public class RegisterViewModel
    {
        [Required]
        [Display(Name = "User name")]
        public string UserName { get; set; }

        [Required]
        [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [DataType(DataType.Password)]
        [Display(Name = "Confirm password")]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }


    public class LoggedInAgentViewModel
    {
        public int AgentId { get; set; }

        public int ExtensionNo { get; set; }

        public string AgentName { get; set; }

        public string AgentType { get; set; }

        public string UniqueIdentifier { get; set; }

        public DateTime LoginDateTime { get; set; }

    }
}
