﻿using AutoDialOut.App_Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoDialOut.SessionManager;
using AutoDialOut.BookingManager;
using System.Net;
using System.Configuration;
using NLog;
using System.Data;
using System.Threading.Tasks;


namespace AutoDialOut.Repository
{
    public class BookingRepository
    {
        private static string _signature = "";
        SessionManagerClient objSessionManagerClient = new SessionManagerClient();
        NLog.Logger logger = LogManager.GetLogger("databaseLogger");

        public async Task<List<CallerBookingInfo>> GetCustomerBookings(string customerPhoneNumber)
        {
            List<CallerBookingInfo> callerDetails = null;
            try
            {
                //PreClientService1.PreClientServiceSoapClient client = new PreClientService1.PreClientServiceSoapClient();
                //var ds_bookingInfo = client.FindBookingResponseData(customerPhoneNumber);

                //if (ds_bookingInfo.Rows.Count > 0)
                //{
                //    callerDetails = new List<CallerBookingInfo>();
                //    for (int ctr = 0; ctr < ds_bookingInfo.Rows.Count; ctr++)
                //    {
                //        CallerBookingInfo customerDetail = new CallerBookingInfo();
                //        //customerDetail. = customerPhoneNumber;

                //        customerDetail.PaxName = ds_bookingInfo.Rows[ctr]["PaxName"] == null ? "No Data Available" : ds_bookingInfo.Rows[ctr]["PaxName"].ToString();
                //        customerDetail.RecordLocator = ds_bookingInfo.Rows[ctr]["RecordLocator"] == null ? "-" : ds_bookingInfo.Rows[ctr]["RecordLocator"].ToString();
                //        customerDetail.PnrStatus = ds_bookingInfo.Rows[ctr]["BookingStatus"] == null ? "-" : ds_bookingInfo.Rows[ctr]["BookingStatus"].ToString();
                //        customerDetail.FlightNumber = ds_bookingInfo.Rows[ctr]["FlightNumber"] == null ? "-" : ds_bookingInfo.Rows[ctr]["FlightNumber"].ToString();
                //        customerDetail.FlightDate = ds_bookingInfo.Rows[ctr]["FlightDate"] == null ? "-" : Convert.ToDateTime(ds_bookingInfo.Rows[ctr]["FlightDate"]).ToString("dd-MM-yyyy hh:mm");
                //        customerDetail.Market = ds_bookingInfo.Rows[ctr]["FromCity"] == null ? "-" : ds_bookingInfo.Rows[ctr]["FromCity"].ToString() + "-" + ds_bookingInfo.Rows[ctr]["ToCity"].ToString();

                //        callerDetails.Add(customerDetail);
                //    }
                //}
                return await FindBooking(customerPhoneNumber);
            }
            catch (ProtocolViolationException ex)
            {
                logger.Error(ex, "Invalid Protocol");
            }
            catch (TimeoutException ex)
            {
                logger.Error(ex, "Sql Timeout Exception");
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                //throw;
            }
            return callerDetails;
        }

        public string NavSignature()
        {
            string strSignature = string.Empty;
            try
            {
                if (bool.Parse(ConfigurationManager.AppSettings["IsProxyEnabled"]))
                {
                    WebProxy objWebProxy = new WebProxy(ConfigurationManager.AppSettings["ProxyURI"]);
                    objWebProxy.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["ProxyUserID"], ConfigurationManager.AppSettings["ProxyPassword"], "Interglobe");
                    WebRequest.DefaultWebProxy = objWebProxy;
                }


                SessionManagerClient objSessionClient = new SessionManagerClient();
                LogonRequestData objLogonData = new LogonRequestData();

                objLogonData.DomainCode = ConfigurationManager.AppSettings["NavitaireDomain"];
                objLogonData.AgentName = ConfigurationManager.AppSettings["NavitaireAgentName"];
                objLogonData.Password = ConfigurationManager.AppSettings["NavitaireAgentPassword"];
                strSignature = objSessionClient.Logon(340, objLogonData);

            }
            catch (Exception ex)
            {
                logger.Error(ex);
                // throw ex;
            }
            return strSignature;

        }

        private async Task<List<CallerBookingInfo>> FindBooking(string contactNo)
        {
            List<CallerBookingInfo> callerDetails = null;
            //Following objects are required to get the customer data using Navitare Service
            BookingManagerClient objBookingManageClient = null;
            FindBookingRequestData findbookingrequestData = null;
            FindBookingResponseData findbookingresponseData = null;

            try
            {
                objBookingManageClient = new BookingManagerClient();
                findbookingrequestData = new FindBookingRequestData();
                findbookingresponseData = new FindBookingResponseData();

                //=========== Removing first place 0 digit from input contact number ======================
                contactNo = contactNo.StartsWith("0") == true ? contactNo.TrimStart('0') : contactNo;

                _signature = await GetSignature();


                //objSessionManagerClient.KeepAlive(340, _signature);
                //Here cli is the mobile number and this number will be passed to the FindBooking method to get the PNR details corresponding to that number.
                findbookingrequestData.FindBookingBy = new FindBookingBy();
                findbookingrequestData.FindBookingBy = FindBookingBy.Contact;
                findbookingrequestData.FindByContact = new FindByContact();

                for (int OuterLoop = 0; OuterLoop <= 1; OuterLoop++)
                {

                    if (OuterLoop == 1)
                        contactNo = "91" + contactNo;

                    findbookingrequestData.FindByContact.PhoneNumber = contactNo;

                    var response = await objBookingManageClient.FindBookingAsync(340, _signature, findbookingrequestData);
                    findbookingresponseData = response.FindBookingRespData;

                    if (findbookingresponseData.Records > 0)
                    {
                        callerDetails = new List<CallerBookingInfo>();
                        for (int intLoopCounter = 0; intLoopCounter < findbookingresponseData.Records; intLoopCounter++)
                        {
                            var currentResponse = findbookingresponseData.FindBookingDataList[intLoopCounter];
                            CallerBookingInfo customerDetail = new CallerBookingInfo();
                            if (currentResponse.Name == null)
                                customerDetail.PaxName = "No Data Available";
                            else
                                customerDetail.PaxName = currentResponse.Name.FirstName + " " + currentResponse.Name.MiddleName + " " + currentResponse.Name.LastName;
                            customerDetail.RecordLocator = currentResponse.RecordLocator;
                            customerDetail.PnrStatus = currentResponse.BookingStatus.ToString();
                            customerDetail.FlightNumber = currentResponse.FlightNumber;
                            if (currentResponse.FlightDate == null)
                            {
                                customerDetail.FlightDate = "-";
                            }
                            else
                            {
                                DateTime flightDate = Convert.ToDateTime(currentResponse.FlightDate);
                                if (flightDate.Date == DateTime.MaxValue.Date || flightDate.Date == DateTime.MinValue.Date)
                                {
                                    customerDetail.FlightDate = "-";
                                }
                                else
                                {
                                    customerDetail.FlightDate = flightDate.ToString("dd-MMM-yyyy HH:mm");
                                }
                            }
                            customerDetail.Market = currentResponse.FromCity == null ? "-" : currentResponse.FromCity + "-" + currentResponse.ToCity;

                            callerDetails.Add(customerDetail);
                        }
                        break;
                    }
                    //return tblRecords;
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            finally
            {
                if (objSessionManagerClient != null && _signature != "")
                    objSessionManagerClient.Logout(340, _signature);

                objBookingManageClient = null;
                objSessionManagerClient = null;
            }
            return callerDetails;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private async Task<string> GetSignature()
        {
            string Signature = string.Empty;

            try
            {
                LogonRequestData LD = new LogonRequestData();

                //Test Environment credentials
                LD.DomainCode = ConfigurationManager.AppSettings["DomainCode"].ToString();
                LD.AgentName = ConfigurationManager.AppSettings["AgentName"].ToString();
                LD.Password = ConfigurationManager.AppSettings["Password"].ToString();

                //Create session token (i.e. Signature).  This token will be used by us for every transaction
                var result = await objSessionManagerClient.LogonAsync(340, LD);
                return result.Signature;
                //SM.KeepAlive(340, Signature);

            }
            catch (Exception ex)
            {
                logger.Error(ex);
            }
            return Signature;
        }
    }
}